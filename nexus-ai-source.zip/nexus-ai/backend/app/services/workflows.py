"""Workflow lifecycle service shared by the API and the demo scripts."""
from __future__ import annotations

from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..graph import runtime
from ..models import User, Workflow, new_id
from ..rbac import requester_permissions
from ..services import audit
from ..tools.definitions import INTEGRATION_DEFINITIONS  # noqa: F401  (keeps catalog import warm)


def create_workflow(
    db: Session,
    *,
    user: User,
    request_text: str,
    category: str | None = None,
    start: bool = True,
) -> Workflow:
    text = request_text.strip()
    if len(text) < 8:
        raise ValueError("A business request needs at least a short sentence describing the goal")
    workflow = Workflow(
        id=new_id("WF-"),
        user_id=user.id,
        request_text=text,
        category=category or "pending_planning",
        status="queued",
        title=text[:120],
        current_stage="AI Command Center",
        active_agent="Web App",
        langgraph_thread_id="",
    )
    db.add(workflow)
    audit.record(
        db,
        event_type="workflow_requested",
        message=f"{user.email} submitted a {workflow.category} request",
        workflow_id=workflow.id,
        actor=user.email,
        agent_name="gateway",
        input_summary=text[:500],
    )
    db.commit()
    workflow.langgraph_thread_id = workflow.id
    db.commit()
    if start:
        launch(db, workflow, user)
    return workflow


def build_launch_payload(workflow: Workflow, user: User) -> dict[str, Any]:
    return {
        "workflow_id": workflow.id,
        "request_text": workflow.request_text,
        "category_hint": None if workflow.category == "pending_planning" else workflow.category,
        "requester_email": user.email,
        "requester_name": user.full_name,
        "requester_permissions": requester_permissions(user),
        "tasks": [],
        "attempt": 1,
        "progress": 0.0,
        "status": "queued",
    }


def launch(db: Session, workflow: Workflow, user: User) -> bool:
    return runtime.start_workflow(build_launch_payload(workflow, user))


def workflow_snapshot(db: Session, workflow: Workflow) -> dict[str, Any]:
    from ..models import Approval, WorkflowTask

    tasks = list(db.scalars(select(WorkflowTask).where(WorkflowTask.workflow_id == workflow.id).order_by(WorkflowTask.seq)))
    approvals = list(db.scalars(select(Approval).where(Approval.workflow_id == workflow.id)))
    return {
        "id": workflow.id,
        "status": workflow.status,
        "progress": workflow.progress,
        "current_stage": workflow.current_stage,
        "active_agent": workflow.active_agent,
        "pending_approvals": [a.id for a in approvals if a.status == "pending"],
        "tasks": [{"task_id": t.task_id, "status": t.status} for t in tasks],
    }
