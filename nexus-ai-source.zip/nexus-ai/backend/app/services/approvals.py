"""Approval decisions - the only way a paused checkpoint can be released."""
from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import Approval, User, Workflow, utcnow
from ..rbac import role_allows
from ..services import audit
from ..tools.definitions import get_tool_definition


class ApprovalError(RuntimeError):
    pass


def pending(db: Session) -> list[Approval]:
    return list(
        db.scalars(
            select(Approval).where(Approval.status == "pending").order_by(Approval.requested_at.desc())
        )
    )


def for_workflow(db: Session, workflow_id: str) -> list[Approval]:
    return list(db.scalars(select(Approval).where(Approval.workflow_id == workflow_id).order_by(Approval.id)))


def decide(
    db: Session,
    *,
    approval_id: str,
    user: User,
    action: str,
    comment: str = "",
) -> Approval:
    """Record a human decision.

    An approver may only release a checkpoint whose capability they themselves
    hold, so approving a payment requires a role that can order payments.
    """
    if action not in ("approve", "reject"):
        raise ApprovalError("action must be 'approve' or 'reject'")
    approval = db.get(Approval, approval_id)
    if approval is None:
        raise ApprovalError(f"Approval {approval_id} not found")
    if approval.status != "pending":
        raise ApprovalError(f"Approval {approval_id} was already {approval.status}")
    permissions = list(user.role.permissions) if user.role else []
    if not role_allows(permissions, "approvals.decide"):
        raise ApprovalError("Your role cannot decide approval requests")
    definition = get_tool_definition(approval.details.get("tool", ""))
    if action == "approve" and definition and not role_allows(permissions, definition.required_permission):
        raise ApprovalError(
            f"Approving '{approval.action}' requires the '{definition.required_permission}' capability, "
            "which your role does not hold"
        )

    approval.status = "approved" if action == "approve" else "rejected"
    approval.decided_at = utcnow()
    approval.decided_by_id = user.id
    approval.decided_by = f"{user.full_name} <{user.email}>"
    approval.comment = comment.strip()
    db.commit()

    workflow = db.get(Workflow, approval.workflow_id)
    audit.record(
        db,
        event_type="approval_granted" if action == "approve" else "approval_rejected",
        message=f"{user.email} {action}d {approval.action} for task {approval.task_id}",
        workflow_id=approval.workflow_id,
        task_id=approval.task_id,
        agent_name="approval",
        actor=user.email,
        severity="info" if action == "approve" else "warning",
        input_summary=approval.policy_reason,
        output_summary=comment or ("approved" if action == "approve" else "rejected"),
        payload={"approval_id": approval.id, "risk_level": approval.risk_level},
    )
    if workflow is not None:
        audit.record(
            db,
            event_type="workflow_resumed" if action == "approve" else "workflow_resumed",
            message=f"Workflow {workflow.id} released from the checkpoint by {user.email} ({action})",
            workflow_id=workflow.id,
            task_id=approval.task_id,
            agent_name="orchestrator",
            actor=user.email,
        )
    return approval
