"""Append-only audit trail helpers."""
from __future__ import annotations

from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import AuditLog

EVENT_TYPES = {
    "workflow_requested",
    "workflow_planned",
    "workflow_started",
    "workflow_paused",
    "workflow_resumed",
    "workflow_completed",
    "workflow_failed",
    "workflow_cancelled",
    "workflow_escalated",
    "agent_decision",
    "tool_invoked",
    "tool_failed",
    "tool_replayed",
    "task_started",
    "task_completed",
    "task_failed",
    "task_skipped",
    "task_retry",
    "task_rolled_back",
    "approval_requested",
    "approval_granted",
    "approval_rejected",
    "document_generated",
    "notification_sent",
    "user_login",
    "user_created",
    "tool_registered",
    "tool_updated",
    "integration_updated",
    "access_denied",
}


def record(
    db: Session,
    *,
    event_type: str,
    message: str,
    workflow_id: str | None = None,
    task_id: str = "",
    agent_name: str = "",
    actor: str = "system",
    tool_name: str = "",
    input_summary: str = "",
    output_summary: str = "",
    severity: str = "info",
    payload: dict[str, Any] | None = None,
    commit: bool = True,
) -> AuditLog:
    entry = AuditLog(
        workflow_id=workflow_id,
        task_id=task_id,
        agent_name=agent_name,
        event_type=event_type,
        actor=actor,
        message=message,
        tool_name=tool_name,
        input_summary=input_summary[:2000],
        output_summary=output_summary[:2000],
        severity=severity,
        payload=payload or {},
    )
    db.add(entry)
    if commit:
        db.commit()
    return entry


def history(db: Session, workflow_id: str) -> list[AuditLog]:
    return list(db.scalars(select(AuditLog).where(AuditLog.workflow_id == workflow_id).order_by(AuditLog.id)))
