"""Authentication endpoints."""
from __future__ import annotations

from fastapi import APIRouter, HTTPException, status
from sqlalchemy import select

from ..config import settings
from ..deps import CurrentUser, DbSession
from ..models import Role, User
from ..schemas import LoginRequest, RoleOut, TokenResponse, UserOut
from ..security import create_access_token, verify_password
from ..services import audit

router = APIRouter(prefix="/api/auth", tags=["auth"])


@router.post("/login", response_model=TokenResponse)
def login(payload: LoginRequest, db: DbSession) -> TokenResponse:
    user = db.scalar(select(User).where(User.email == payload.email.lower()))
    if user is None or not verify_password(payload.password, user.hashed_password):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Incorrect email or password")
    if not user.is_active:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "This account has been deactivated")
    token = create_access_token(user.email, claims={"role": user.role.name})
    audit.record(db, event_type="user_login", message=f"{user.email} signed in", actor=user.email)
    return TokenResponse(
        access_token=token,
        expires_in_minutes=settings.access_token_expire_minutes,
        user=_user_out(db, user),
    )


@router.get("/me", response_model=UserOut)
def me(user: CurrentUser, db: DbSession) -> UserOut:
    return _user_out(db, user)


def _user_out(db, user: User) -> UserOut:
    role = db.scalar(select(Role).where(Role.id == user.role_id))
    return UserOut(
        id=user.id,
        email=user.email,
        full_name=user.full_name,
        department=user.department,
        role=RoleOut(name=role.name, description=role.description, permissions=role.permissions)
        if role
        else RoleOut(name="unknown"),
    )


@router.get("/demo-accounts")
def demo_accounts(db: DbSession) -> dict:
    """Non-secret hints so a fresh sandbox is usable without reading source."""
    from ..seed import demo_password

    users = list(db.scalars(select(User).order_by(User.id)))
    return {
        "password": demo_password(),
        "accounts": [
            {"email": user.email, "name": user.full_name, "role": user.role.name if user.role else ""}
            for user in users
        ],
    }
