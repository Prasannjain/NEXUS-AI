"""Dashboard statistics, activity feeds and notifications."""
from __future__ import annotations

from collections import Counter
from datetime import timedelta
from typing import Any

from fastapi import APIRouter, HTTPException, Query, status
from sqlalchemy import func, select

from ..agents.catalog import AGENTS
from ..deps import CurrentUser, DbSession, has_permission
from ..models import (
    AgentExecution,
    Approval,
    AuditLog,
    GeneratedDocument,
    Notification,
    Tool,
    Workflow,
    WorkflowTask,
    utcnow,
)

router = APIRouter(tags=["dashboard"])

ACTIVE_STATUSES = ("queued", "running", "awaiting_approval")


@router.get("/api/dashboard/stats")
def stats(user: CurrentUser, db: DbSession, days: int = Query(default=14, ge=1, le=90)) -> dict[str, Any]:
    status_counts = dict(
        db.execute(select(Workflow.status, func.count()).group_by(Workflow.status)).all()
    )
    total = sum(status_counts.values())
    completed = status_counts.get("completed", 0) + status_counts.get("completed_with_exceptions", 0)
    failed = status_counts.get("failed", 0)
    rejected = status_counts.get("rejected", 0)
    active = sum(status_counts.get(key, 0) for key in ACTIVE_STATUSES)
    settled = completed + failed + rejected + status_counts.get("cancelled", 0)
    pending_approvals = db.scalar(select(func.count(Approval.id)).where(Approval.status == "pending")) or 0

    categories = dict(db.execute(select(Workflow.category, func.count()).group_by(Workflow.category)).all())
    since = utcnow() - timedelta(days=days)
    rows = list(db.scalars(select(Workflow).where(Workflow.created_at >= since)))
    buckets: Counter[str] = Counter()
    for offset in range(days - 1, -1, -1):
        buckets[(utcnow() - timedelta(days=offset)).date().isoformat()] = 0
    for workflow in rows:
        key = (workflow.created_at or utcnow()).date().isoformat()
        if key in buckets:
            buckets[key] += 1

    agent_activity = []
    for spec in AGENTS:
        count = db.scalar(
            select(func.count(AgentExecution.id)).where(
                AgentExecution.agent_name == spec.name, AgentExecution.created_at >= since
            )
        ) or 0
        agent_activity.append({"agent": spec.display_name, "name": spec.name, "steps": count})

    recent_workflows = list(
        db.scalars(select(Workflow).order_by(Workflow.created_at.desc()).limit(8))
    )
    recent_audit = list(db.scalars(select(AuditLog).order_by(AuditLog.id.desc()).limit(12)))
    tool_counts = dict(
        db.execute(select(WorkflowTask.tool_name, func.count()).group_by(WorkflowTask.tool_name)).all()
    )
    risk_counts = dict(
        db.execute(select(WorkflowTask.risk_level, func.count()).group_by(WorkflowTask.risk_level)).all()
    )
    enabled_tools = db.scalar(select(func.count(Tool.id)).where(Tool.enabled.is_(True))) or 0
    total_tools = db.scalar(select(func.count(Tool.id))) or 0

    return {
        "counters": {
            "total_workflows": total,
            "active_workflows": active,
            "completed_workflows": completed,
            "failed_workflows": failed,
            "rejected_workflows": rejected,
            "pending_approvals": pending_approvals,
            "total_agents": len(AGENTS),
            "active_agents": sum(1 for item in agent_activity if item["steps"]),
            "enabled_tools": enabled_tools,
            "total_tools": total_tools,
            "success_rate": round(completed / settled * 100, 1) if settled else None,
            "avg_duration_seconds": round(
                sum(workflow.duration_seconds or 0 for workflow in recent_workflows) / max(1, len(recent_workflows)), 1
            ),
            "audit_entries": db.scalar(select(func.count(AuditLog.id))) or 0,
            "generated_documents": db.scalar(select(func.count(GeneratedDocument.id))) or 0,
        },
        "status_breakdown": [{"name": key, "value": value} for key, value in sorted(status_counts.items())],
        "category_breakdown": [{"name": key, "value": value} for key, value in sorted(categories.items())],
        "daily_trend": [
            {"date": day, "workflows": count} for day, count in sorted(buckets.items())
        ],
        "agent_activity": agent_activity,
        "tool_usage": [{"name": name or "unassigned", "value": value} for name, value in sorted(tool_counts.items())],
        "risk_distribution": [{"name": name or "low", "value": value} for name, value in sorted(risk_counts.items())],
        "recent_workflows": [
            {
                "id": workflow.id,
                "title": workflow.title,
                "category": workflow.category,
                "status": workflow.status,
                "stage": workflow.current_stage,
                "active_agent": workflow.active_agent,
                "progress": workflow.progress,
                "requester": workflow.user.email if workflow.user else "",
                "created_at": workflow.created_at,
                "duration_seconds": workflow.duration_seconds,
            }
            for workflow in recent_workflows
        ],
        "recent_audit": [
            {
                "id": entry.id,
                "workflow_id": entry.workflow_id,
                "agent_name": entry.agent_name,
                "event_type": entry.event_type,
                "message": entry.message,
                "severity": entry.severity,
                "created_at": entry.created_at,
            }
            for entry in recent_audit
        ],
    }


@router.get("/api/notifications")
def list_notifications(
    user: CurrentUser, db: DbSession, unread_only: bool = False, limit: int = Query(default=30, le=200)
) -> dict[str, Any]:
    statement = select(Notification).where(Notification.user_id == user.id).order_by(Notification.id.desc())
    if unread_only:
        statement = statement.where(Notification.read.is_(False))
    rows = list(db.scalars(statement.limit(limit)))
    return {
        "total": len(rows),
        "unread": sum(1 for row in rows if not row.read),
        "items": [
            {
                "id": row.id,
                "title": row.title,
                "message": row.message,
                "level": row.level,
                "workflow_id": row.workflow_id,
                "read": row.read,
                "created_at": row.created_at,
            }
            for row in rows
        ],
    }


@router.post("/api/notifications/{notification_id}/read")
def mark_read(notification_id: int, user: CurrentUser, db: DbSession) -> dict[str, Any]:
    row = db.get(Notification, notification_id)
    if row is None or row.user_id != user.id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Notification not found")
    row.read = True
    db.commit()
    return {"id": row.id, "read": True}


@router.post("/api/notifications/read-all")
def mark_all_read(user: CurrentUser, db: DbSession) -> dict[str, Any]:
    rows = db.scalars(select(Notification).where(Notification.user_id == user.id, Notification.read.is_(False)))
    count = 0
    for row in rows:
        row.read = True
        count += 1
    db.commit()
    return {"marked": count}
