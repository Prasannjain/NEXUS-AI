"""Runtime settings: LLM provider switching, policy summary, platform health."""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException, status
from sqlalchemy import func, select

from ..agents.catalog import AGENTS
from ..config import settings
from ..deps import CurrentUser, DbSession, has_permission
from ..llm.provider import LLMClient, llm_client
from ..models import Approval, Role, Tool, Workflow
from ..rbac import ROLE_DEFINITIONS
from ..services import audit
from ..tools.definitions import TOOL_DEFINITIONS

router = APIRouter(prefix="/api/settings", tags=["settings"])


def _platform_state() -> dict[str, Any]:
    return {
        "app_name": settings.app_name,
        "environment": settings.environment,
        "database": {
            "dialect": settings.database_url.split("://", 1)[0],
            "postgres": settings.database_url.startswith("postgres"),
            "redis": settings.redis_enabled,
            "redis_note": (
                "REDIS_URL is set - this build still drives workflows with the in-process "
                "worker pool, Redis is not required to run a workflow"
                if settings.redis_enabled
                else "REDIS_URL is unset - the in-process worker pool is used instead"
            ),
        },
        "orchestration": {
            "engine": "LangGraph",
            "checkpoint_store": settings.checkpoint_database_path,
            "max_task_attempts": settings.max_task_attempts,
            "retry_base_delay_seconds": settings.retry_base_delay_seconds,
            "retry_backoff_factor": settings.retry_backoff_factor,
            "escalation_email": settings.workflow_escalation_email,
        },
        "approval_policy": {
            "rule": "A checkpoint is raised for any tool marked requires_approval or with high/critical risk",
            "gated_tools": sorted(
                {tool.name for tool in TOOL_DEFINITIONS if tool.requires_approval or tool.risk_level in ("high", "critical")}
            ),
            "never_auto_retried": sorted({tool.name for tool in TOOL_DEFINITIONS if not tool.retry_safe}),
            "irreversible": sorted({tool.name for tool in TOOL_DEFINITIONS if not tool.reversible}),
        },
        "security": {
            "token_type": "JWT bearer",
            "token_expiry_minutes": settings.access_token_expire_minutes,
            "password_hash": "PBKDF2-SHA256, 240000 rounds",
            "secrets_source": "environment variables only",
            "audit_append_only": True,
            "roles": [role["name"] for role in ROLE_DEFINITIONS],
        },
    }


@router.get("")
def read_settings(user: CurrentUser, db: DbSession) -> dict[str, Any]:
    providers = llm_client.available_providers()
    for provider in providers:
        provider["active"] = provider["name"] == llm_client.provider
    return {
        "llm": {
            "provider": llm_client.provider,
            "providers": providers,
            "note": "API keys are read from the environment (GEMINI_API_KEY / OPENAI_API_KEY / OLLAMA_BASE_URL) "
                    "and are never returned by this API.",
        },
        "platform": _platform_state(),
        "counts": {
            "agents": len(AGENTS),
            "tools": len(TOOL_DEFINITIONS),
            "registered_tools": db.scalar(select(func.count(Tool.id))) or 0,
            "workflows": db.scalar(select(func.count(Workflow.id))) or 0,
            "pending_approvals": db.scalar(select(func.count(Approval.id)).where(Approval.status == "pending")) or 0,
        },
    }


@router.get("/roles")
def role_matrix(user: CurrentUser, db: DbSession) -> list[dict[str, Any]]:
    """The matrix holds no secrets, so any signed-in role may read it."""
    rows = list(db.scalars(select(Role).order_by(Role.id)))
    return [
        {
            "name": role.name,
            "description": role.description,
            "permissions": role.permissions,
            "user_count": len(role.users),
        }
        for role in rows
    ]


@router.put("/llm/provider")
def switch_provider(payload: dict[str, Any], user: CurrentUser, db: DbSession) -> dict[str, Any]:
    """Switch the planner's provider for this process.

    The provider must already have its credentials in the environment; nothing
    here accepts or stores a key.
    """
    if not has_permission(user, "settings.manage"):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Only administrators may change the LLM provider")
    provider = str(payload.get("provider", "")).lower()
    if provider not in {"gemini", "openai", "ollama", "none", "auto"}:
        raise HTTPException(422, "provider must be gemini, openai, ollama, none or auto")
    if provider != "none" and not settings.provider_available(provider):
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            f"{provider} has no credentials in this environment; set its environment variable first",
        )
    settings.llm_provider = provider  # type: ignore[misc]
    audit.record(
        db,
        event_type="integration_updated",
        message=f"{user.email} switched the LLM provider to {provider}",
        actor=user.email,
        severity="warning",
    )
    return {"provider": provider, "providers": [
        {**item, "active": item["name"] == provider} for item in llm_client.available_providers()
    ]}


@router.post("/llm/test")
async def test_provider(user: CurrentUser, payload: dict[str, Any] | None = None) -> dict[str, Any]:
    provider = str((payload or {}).get("provider") or llm_client.provider)
    if provider == "none":
        return {
            "provider": "none",
            "status": "offline_fallback",
            "detail": "The deterministic rule planner is active, so workflows still run without any API key.",
        }
    client = LLMClient()
    client.settings = settings.model_copy(update={"llm_provider": provider})
    return {"requested": provider, **(await client.health())}
