"""Workflow endpoints: submission, planning preview, monitoring, reports."""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException, Query, status
from fastapi.responses import PlainTextResponse
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from ..agents.planner import CATEGORIES, build_plan
from ..deps import CurrentUser, DbSession, has_permission
from ..graph import runtime
from ..models import GeneratedDocument, User, Workflow, WorkflowTask
from ..schemas import PlanPreviewRequest, WorkflowCreateRequest
from ..serializers import workflow_detail, workflow_out
from ..services import audit
from ..services.reports import render_markdown
from ..services.workflows import create_workflow, launch

router = APIRouter(prefix="/api/workflows", tags=["workflows"])


@router.get("/categories")
def categories() -> dict[str, Any]:
    return {
        "categories": [
            {
                "key": key,
                "label": label,
                "examples": _EXAMPLES[key],
            }
            for key, label in CATEGORIES.items()
        ]
    }


_EXAMPLES = {
    "employee_onboarding": [
        "Onboard Rahul Sharma as a Software Engineer in the Engineering Department.",
        "Onboard Anita Verma as a Senior Data Analyst in the Finance Department starting 2026-11-16.",
        "Hire Marcus Lin as a DevOps Engineer for the Operations team.",
    ],
    "invoice_processing": [
        "Process invoice INV-88214 from Acme Office Supplies for EUR 1,290.50.",
        "Validate and pay invoice INV-88213 raised by Northwind Cloud Services.",
        "Check invoice INV-88215 from Helios Data Ltd for duplicates before payment.",
    ],
    "customer_request": [
        "Customer Beacon Retail Group asks where order ORD-77301 is; ticket TCK-44102 is late.",
        "Vertex Logistics reports a damaged delivery on ticket TCK-44120 and wants a refund.",
        "Lumen Studios needs the status of order ORD-77303 for ticket TCK-44131.",
    ],
}


@router.post("/preview-plan")
async def preview_plan(payload: PlanPreviewRequest, user: CurrentUser) -> dict[str, Any]:
    """Dry-run the Planner Agent so the plan can be shown before submitting."""
    if not has_permission(user, "workflows.create"):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Your role cannot start workflows")
    hint = payload.category if payload.category in CATEGORIES else None
    plan = await build_plan(payload.request_text, hint)
    data = plan.to_dict()
    data["task_count"] = len(data["tasks"])
    data["approval_checkpoints"] = [task["task_id"] for task in data["tasks"] if task["requires_approval"]]
    data["agents"] = sorted({task["agent"] for task in data["tasks"]})
    return data


@router.post("", status_code=status.HTTP_201_CREATED)
def submit_workflow(
    payload: WorkflowCreateRequest,
    user: CurrentUser,
    db: DbSession,
) -> dict[str, Any]:
    if not has_permission(user, "workflows.create"):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Your role cannot start workflows")
    category = None if payload.category in (None, "auto") else payload.category
    try:
        workflow = create_workflow(
            db, user=user, request_text=payload.request_text, category=category, start=False
        )
    except ValueError as error:
        raise HTTPException(422, str(error)) from error
    started = launch(db, workflow, user)
    return {
        **workflow_out(db, workflow),
        "queued": started,
        "message": (
            "Workflow accepted and handed to the Planner Agent"
            if started
            else "Workflow accepted; another run is still active for this workflow"
        ),
    }


@router.get("")
def list_workflows(
    user: CurrentUser,
    db: DbSession,
    status_filter: str | None = Query(default=None, alias="status"),
    category: str | None = None,
    search: str | None = None,
    limit: int = Query(default=50, le=200),
    offset: int = 0,
) -> dict[str, Any]:
    statement = select(Workflow)
    if status_filter:
        statement = statement.where(Workflow.status == status_filter)
    if category:
        statement = statement.where(Workflow.category == category)
    if search:
        pattern = f"%{search}%"
        statement = statement.where(
            or_(Workflow.request_text.ilike(pattern), Workflow.id.ilike(pattern), Workflow.title.ilike(pattern))
        )
    total = db.scalar(select(func.count()).select_from(statement.subquery())) or 0
    rows = list(db.scalars(statement.order_by(Workflow.created_at.desc()).limit(limit).offset(offset)))
    return {"total": total, "items": [workflow_out(db, workflow) for workflow in rows]}


@router.get("/{workflow_id}")
def get_workflow(workflow_id: str, user: CurrentUser, db: DbSession) -> dict[str, Any]:
    workflow = _owned_or_404(db, user, workflow_id)
    detail = workflow_detail(db, workflow)
    detail["checkpoint"] = runtime.checkpoint_state(workflow_id)
    detail["running"] = runtime.is_running(workflow_id)
    return detail


@router.get("/{workflow_id}/events")
def workflow_events(workflow_id: str, user: CurrentUser, db: DbSession) -> dict[str, Any]:
    """Lightweight polling feed for the live monitor."""
    workflow = _owned_or_404(db, user, workflow_id)
    tasks = list(
        db.scalars(select(WorkflowTask).where(WorkflowTask.workflow_id == workflow_id).order_by(WorkflowTask.seq))
    )
    return {
        "id": workflow.id,
        "status": workflow.status,
        "stage": workflow.current_stage,
        "active_agent": workflow.active_agent,
        "progress": workflow.progress,
        "duration_seconds": workflow.duration_seconds,
        "tasks": [
            {
                "task_id": task.task_id,
                "description": task.description,
                "agent_name": task.agent_name,
                "tool_name": task.tool_name,
                "status": task.status,
                "attempts": task.attempts,
                "risk_level": task.risk_level,
                "requires_approval": task.requires_approval,
                "output_summary": task.output_summary,
                "error": task.error,
            }
            for task in tasks
        ],
        "timeline": workflow_detail(db, workflow)["timeline"],
        "running": runtime.is_running(workflow_id),
    }


@router.post("/{workflow_id}/resume")
def resume_workflow(workflow_id: str, user: CurrentUser, db: DbSession) -> dict[str, Any]:
    """Re-arm a workflow parked at a checkpoint whose decision was already recorded."""
    workflow = _owned_or_404(db, user, workflow_id)
    if workflow.status != "awaiting_approval":
        raise HTTPException(status.HTTP_409_CONFLICT, f"Workflow is {workflow.status}, not awaiting approval")
    pending = [
        approval
        for approval in workflow_detail(db, workflow)["approvals"]
        if approval["status"] == "pending"
    ]
    if pending:
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            "The workflow is waiting on a human decision that has not been recorded yet",
        )
    started = runtime.resume_workflow(workflow_id, {"source": "manual_resume", "by": user.email})
    audit.record(
        db,
        event_type="workflow_resumed",
        message=f"{user.email} re-armed a checkpoint that had already been decided",
        workflow_id=workflow_id,
        actor=user.email,
        agent_name="orchestrator",
    )
    return {"resumed": started, "workflow": workflow_out(db, workflow)}


@router.post("/{workflow_id}/cancel")
def cancel_workflow(workflow_id: str, user: CurrentUser, db: DbSession) -> dict[str, Any]:
    workflow = _owned_or_404(db, user, workflow_id)
    if workflow.status in ("completed", "completed_with_exceptions", "rejected", "failed", "cancelled"):
        raise HTTPException(status.HTTP_409_CONFLICT, f"Workflow already {workflow.status}")
    workflow.status = "cancelled"
    workflow.current_stage = "Final Report"
    workflow.finished_at = workflow.finished_at or None
    from ..models import utcnow

    workflow.finished_at = utcnow()
    workflow.result_summary = f"Cancelled by {user.email}; in-flight checkpoints were not resumed."
    db.commit()
    for approval in [a for a in workflow.approvals if a.status == "pending"]:
        approval.status = "cancelled"
        approval.decided_by = f"{user.full_name} <{user.email}>"
        approval.decided_at = utcnow()
        approval.comment = "Workflow cancelled"
    for task in workflow.tasks:
        if task.status not in ("completed", "failed", "rejected"):
            task.status = "cancelled"
    db.commit()
    audit.record(
        db,
        event_type="workflow_cancelled",
        message=f"{user.email} cancelled workflow {workflow_id}",
        workflow_id=workflow_id,
        actor=user.email,
        severity="warning",
    )
    return {"cancelled": True, "workflow": workflow_out(db, workflow)}


@router.get("/{workflow_id}/report")
def get_report(workflow_id: str, user: CurrentUser, db: DbSession) -> dict[str, Any]:
    workflow = _owned_or_404(db, user, workflow_id)
    if not workflow.final_report:
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            f"The final report is produced when the workflow settles; it is currently {workflow.status}",
        )
    return workflow.final_report


@router.get("/{workflow_id}/report.md", response_class=PlainTextResponse)
def download_report(workflow_id: str, user: CurrentUser, db: DbSession) -> PlainTextResponse:
    workflow = _owned_or_404(db, user, workflow_id)
    if not workflow.final_report:
        raise HTTPException(status.HTTP_409_CONFLICT, f"Workflow is still {workflow.status}")
    content = render_markdown(workflow.final_report)
    return PlainTextResponse(
        content,
        media_type="text/markdown; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="nexus-report-{workflow_id}.md"'},
    )


@router.get("/{workflow_id}/documents/{document_id}")
def download_document(
    workflow_id: str, document_id: str, user: CurrentUser, db: DbSession
) -> PlainTextResponse:
    workflow = _owned_or_404(db, user, workflow_id)
    document = db.get(GeneratedDocument, document_id)
    if document is None or document.workflow_id != workflow.id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Document not found for this workflow")
    return PlainTextResponse(
        document.content,
        media_type="text/markdown; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{document.title.replace(" ", "_")}.md"'},
    )


def _owned_or_404(db: Session, user: User, workflow_id: str) -> Workflow:
    workflow = db.get(Workflow, workflow_id)
    if workflow is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"Workflow {workflow_id} not found")
    # Viewers and approvers legitimately inspect other people's workflows; the
    # audit trail records the access either way.
    if workflow.user_id != user.id and not has_permission(user, "workflows.view"):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "You cannot view this workflow")
    return workflow
