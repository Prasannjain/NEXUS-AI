"""Human-in-the-loop approval endpoints."""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException, Query, status
from sqlalchemy import select

from ..deps import CurrentUser, DbSession, has_permission
from ..graph import runtime
from ..models import Approval, Workflow
from ..schemas import ApprovalDecisionRequest
from ..services import audit
from ..services.approvals import ApprovalError, decide
from ..tools.definitions import get_tool_definition

router = APIRouter(prefix="/api/approvals", tags=["approvals"])


def _serialize(db, approval: Approval, user: CurrentUser | None = None) -> dict[str, Any]:
    workflow = db.get(Workflow, approval.workflow_id)
    definition = get_tool_definition((approval.details or {}).get("tool", ""))
    role_permissions = list(user.role.permissions) if user and user.role else []
    can_decide = (
        approval.status == "pending"
        and user is not None
        and has_permission(user, "approvals.decide")
        and (
            "*" in role_permissions
            or definition is None
            or has_permission(user, definition.required_permission)
        )
    )
    return {
        "id": approval.id,
        "workflow_id": approval.workflow_id,
        "workflow_title": (workflow.title if workflow else "") or "",
        "request_text": workflow.request_text if workflow else "",
        "requester": workflow.user.email if workflow and workflow.user else "",
        "task_id": approval.task_id,
        "agent_name": approval.agent_name,
        "action": approval.action,
        "details": approval.details or {},
        "risk_level": approval.risk_level,
        "policy_reason": approval.policy_reason,
        "status": approval.status,
        "requested_at": approval.requested_at,
        "decided_at": approval.decided_at,
        "decided_by": approval.decided_by,
        "comment": approval.comment,
        "tool": definition.name if definition else "",
        "required_permission": definition.required_permission if definition else "",
        "side_effect": definition.side_effect if definition else "",
        "retry_safe": definition.retry_safe if definition else True,
        "can_decide": can_decide,
    }


@router.get("")
def list_approvals(
    user: CurrentUser,
    db: DbSession,
    status_filter: str = Query(default="all", alias="status"),
    limit: int = Query(default=100, le=500),
) -> dict[str, Any]:
    if not has_permission(user, "approvals.view"):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Your role cannot view approvals")
    statement = select(Approval).order_by(Approval.requested_at.desc())
    if status_filter != "all":
        statement = statement.where(Approval.status == status_filter)
    rows = list(db.scalars(statement.limit(limit)))
    items = [_serialize(db, approval, user) for approval in rows]
    return {
        "total": len(items),
        "pending": sum(1 for item in items if item["status"] == "pending"),
        "items": items,
    }


@router.get("/history")
def approval_history(
    user: CurrentUser, db: DbSession, workflow_id: str | None = None
) -> list[dict[str, Any]]:
    if not has_permission(user, "approvals.view"):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Your role cannot view approvals")
    statement = select(Approval).where(Approval.status != "pending").order_by(Approval.decided_at.desc())
    if workflow_id:
        statement = statement.where(Approval.workflow_id == workflow_id)
    return [_serialize(db, approval, user) for approval in db.scalars(statement.limit(200))]


@router.get("/{approval_id}")
def get_approval(approval_id: str, user: CurrentUser, db: DbSession) -> dict[str, Any]:
    approval = db.get(Approval, approval_id)
    if approval is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"Approval {approval_id} not found")
    if not has_permission(user, "approvals.view"):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Your role cannot view approvals")
    return _serialize(db, approval, user)


@router.post("/{approval_id}/decide")
def decide_approval(
    approval_id: str,
    payload: ApprovalDecisionRequest,
    user: CurrentUser,
    db: DbSession,
) -> dict[str, Any]:
    try:
        approval = decide(
            db, approval_id=approval_id, user=user, action=payload.action, comment=payload.comment
        )
    except ApprovalError as error:
        audit.record(
            db,
            event_type="access_denied",
            message=f"{user.email} was refused at approval {approval_id}: {error}",
            actor=user.email,
            agent_name="approval",
            severity="warning",
        )
        raise HTTPException(status.HTTP_403_FORBIDDEN, str(error)) from error

    resumed = runtime.resume_workflow(approval.workflow_id, {"source": "approval_api", "decision": approval.status})
    audit.record(
        db,
        event_type="workflow_resumed",
        message=(
            f"LangGraph continued {approval.workflow_id} from its checkpoint"
            if resumed
            else f"Decision recorded; {approval.workflow_id} resumes once the current run releases"
        ),
        workflow_id=approval.workflow_id,
        task_id=approval.task_id,
        agent_name="orchestrator",
        actor=user.email,
    )
    return {"approval": _serialize(db, approval, user), "resumed": resumed}
