"""Reports and analytics endpoints backing the Reports & Analytics page."""
from __future__ import annotations

from collections import Counter
from datetime import timedelta
from typing import Any

from fastapi import APIRouter, HTTPException, Query, status
from sqlalchemy import func, select

from ..deps import CurrentUser, DbSession, has_permission
from ..models import AgentExecution, Approval, AuditLog, GeneratedDocument, ToolCall, Workflow, WorkflowTask, utcnow
from ..services.reports import render_markdown
from fastapi.responses import PlainTextResponse

router = APIRouter(prefix="/api/reports", tags=["reports"])


@router.get("")
def list_reports(
    user: CurrentUser,
    db: DbSession,
    category: str | None = None,
    status_filter: str | None = Query(default=None, alias="status"),
    days: int = Query(default=30, ge=1, le=365),
) -> dict[str, Any]:
    if not has_permission(user, "reports.view"):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Your role cannot read reports")
    statement = select(Workflow).where(Workflow.final_report.is_not(None))
    statement = statement.where(Workflow.created_at >= utcnow() - timedelta(days=days))
    if category:
        statement = statement.where(Workflow.category == category)
    if status_filter:
        statement = statement.where(Workflow.status == status_filter)
    workflows = list(db.scalars(statement.order_by(Workflow.finished_at.desc().nullslast()).limit(200)))

    durations = [workflow.duration_seconds or 0 for workflow in workflows if workflow.duration_seconds]
    statuses = Counter(workflow.status for workflow in workflows)
    categories = Counter(workflow.category for workflow in workflows)
    approval_total = sum(len(workflow.approvals) for workflow in workflows)
    approval_rejected = sum(
        1 for workflow in workflows for approval in workflow.approvals if approval.status == "rejected"
    )
    return {
        "summary": {
            "reports": len(workflows),
            "completed": statuses.get("completed", 0),
            "with_exceptions": statuses.get("completed_with_exceptions", 0),
            "rejected": statuses.get("rejected", 0),
            "failed": statuses.get("failed", 0),
            "success_rate": round(
                statuses.get("completed", 0) / max(1, sum(statuses.values())) * 100, 1
            ),
            "avg_duration_seconds": round(sum(durations) / len(durations), 1) if durations else 0,
            "approvals_decided": approval_total,
            "approvals_rejected": approval_rejected,
            "by_category": [{"name": name, "value": value} for name, value in sorted(categories.items())],
            "by_status": [{"name": name, "value": value} for name, value in sorted(statuses.items())],
        },
        "items": [
            {
                "workflow_id": workflow.id,
                "title": workflow.title,
                "category": workflow.category,
                "status": workflow.status,
                "requester": workflow.user.email if workflow.user else "",
                "finished_at": workflow.finished_at,
                "duration_seconds": workflow.duration_seconds,
                "headline": (workflow.final_report or {}).get("headline", ""),
                "tasks_completed": len((workflow.final_report or {}).get("completed_tasks", [])),
                "tasks_total": len((workflow.final_report or {}).get("tasks", [])),
                "tool_calls": len((workflow.final_report or {}).get("tool_executions", [])),
                "documents": len((workflow.final_report or {}).get("documents", [])),
            }
            for workflow in workflows
        ],
    }


@router.get("/platform")
def platform_analytics(user: CurrentUser, db: DbSession, days: int = Query(default=30, ge=1, le=365)) -> dict[str, Any]:
    if not has_permission(user, "reports.view"):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Your role cannot read reports")
    since = utcnow() - timedelta(days=days)
    task_status = dict(db.execute(select(WorkflowTask.status, func.count()).group_by(WorkflowTask.status)).all())
    agent_load = dict(
        db.execute(
            select(AgentExecution.agent_name, func.count())
            .where(AgentExecution.created_at >= since)
            .group_by(AgentExecution.agent_name)
        ).all()
    )
    tool_load = dict(
        db.execute(
            select(ToolCall.tool_name, func.count())
            .where(ToolCall.created_at >= since)
            .group_by(ToolCall.tool_name)
        ).all()
    )
    risk_load = dict(db.execute(select(WorkflowTask.risk_level, func.count()).group_by(WorkflowTask.risk_level)).all())
    severities = dict(
        db.execute(
            select(AuditLog.severity, func.count())
            .where(AuditLog.created_at >= since)
            .group_by(AuditLog.severity)
        ).all()
    )
    return {
        "window_days": days,
        "task_status": [{"name": name or "pending", "value": value} for name, value in sorted(task_status.items())],
        "agent_load": [{"name": name or "unknown", "value": value} for name, value in sorted(agent_load.items())],
        "tool_load": [{"name": name or "unknown", "value": value} for name, value in sorted(tool_load.items())],
        "risk_load": [{"name": name or "low", "value": value} for name, value in sorted(risk_load.items())],
        "audit_severity": [
            {"name": name or "info", "value": value} for name, value in sorted(severities.items())
        ],
        "totals": {
            "tasks": sum(task_status.values()),
            "agent_steps": db.scalar(
                select(func.count(AgentExecution.id)).where(AgentExecution.created_at >= since)
            ) or 0,
            "tool_calls": db.scalar(select(func.count(ToolCall.id))) or 0,
            "documents": db.scalar(select(func.count(GeneratedDocument.id))) or 0,
            "approvals": db.scalar(select(func.count(Approval.id))) or 0,
            "audit_entries": db.scalar(
                select(func.count(AuditLog.id)).where(AuditLog.created_at >= since)
            ) or 0,
        },
    }


@router.get("/{workflow_id}.md", response_class=PlainTextResponse)
def report_markdown(workflow_id: str, user: CurrentUser, db: DbSession) -> PlainTextResponse:
    workflow = db.get(Workflow, workflow_id)
    if workflow is None or not workflow.final_report:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "No final report is available for this workflow")
    if not has_permission(user, "reports.view"):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Your role cannot read reports")
    return PlainTextResponse(render_markdown(workflow.final_report), media_type="text/markdown; charset=utf-8")
