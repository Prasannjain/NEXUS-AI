"""Agents, tool registry and enterprise integration endpoints."""
from __future__ import annotations

import json
from typing import Any

from fastapi import APIRouter, HTTPException, status
from jsonschema import Draft202012Validator
from sqlalchemy import func, select

from ..agents.catalog import AGENT_INDEX, AGENTS
from ..deps import CurrentUser, DbSession, has_permission
from ..models import Agent, AgentExecution, Integration, Tool, WorkflowTask
from ..schemas import IntegrationUpdateRequest, ToolRegisterRequest, ToolUpdateRequest
from ..services import audit
from ..tools.definitions import get_tool_definition
from ..tools.registry import ToolValidationError, registry, sync_catalog
from ..tools.adapters import HANDLERS

router = APIRouter(tags=["catalog"])


# ---------------------------------------------------------------------------
# Agents
# ---------------------------------------------------------------------------


@router.get("/api/agents")
def list_agents(user: CurrentUser, db: DbSession) -> list[dict[str, Any]]:
    rows = {agent.name: agent for agent in db.scalars(select(Agent))}
    payload = []
    for spec in AGENTS:
        row = rows.get(spec.name)
        task_count = db.scalar(
            select(func.count(WorkflowTask.id)).where(WorkflowTask.agent_name == spec.name)
        ) or 0
        completed = db.scalar(
            select(func.count(WorkflowTask.id)).where(
                WorkflowTask.agent_name == spec.name, WorkflowTask.status == "completed"
            )
        ) or 0
        failed = db.scalar(
            select(func.count(WorkflowTask.id)).where(
                WorkflowTask.agent_name == spec.name, WorkflowTask.status.in_(["failed", "rejected"])
            )
        ) or 0
        steps = db.scalar(
            select(func.count(AgentExecution.id)).where(AgentExecution.agent_name == spec.name)
        ) or 0
        last = db.scalar(
            select(func.max(AgentExecution.created_at)).where(AgentExecution.agent_name == spec.name)
        )
        payload.append(
            {
                "name": spec.name,
                "display_name": spec.display_name,
                "description": spec.description,
                "capabilities": spec.capabilities,
                "allowed_tools": spec.allowed_tools,
                "icon": spec.icon,
                "color": spec.color,
                "status": (row.status if row else "idle") or "idle",
                "tasks_owned": task_count,
                "tasks_completed": completed,
                "tasks_failed": failed,
                "executions": steps,
                "success_rate": round(completed / task_count * 100, 1) if task_count else None,
                "last_activity": last,
            }
        )
    return payload


@router.get("/api/agents/{agent_name}")
def agent_detail(agent_name: str, user: CurrentUser, db: DbSession) -> dict[str, Any]:
    spec = AGENT_INDEX.get(agent_name)
    if spec is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"Unknown agent '{agent_name}'")
    executions = list(
        db.scalars(
            select(AgentExecution)
            .where(AgentExecution.agent_name == agent_name)
            .order_by(AgentExecution.id.desc())
            .limit(50)
        )
    )
    tools = []
    for tool_name in spec.allowed_tools:
        definition = get_tool_definition(tool_name)
        if definition:
            tools.append(
                {
                    "name": definition.name,
                    "display_name": definition.display_name,
                    "risk_level": definition.risk_level,
                    "required_permission": definition.required_permission,
                    "requires_approval": definition.requires_approval,
                }
            )
    return {
        "name": spec.name,
        "display_name": spec.display_name,
        "description": spec.description,
        "capabilities": spec.capabilities,
        "tools": tools,
        "recent_executions": [
            {
                "id": execution.id,
                "workflow_id": execution.workflow_id,
                "task_id": execution.task_id,
                "node": execution.node,
                "status": execution.status,
                "decision": execution.decision,
                "output_summary": execution.output_summary,
                "error": execution.error,
                "duration_ms": execution.duration_ms,
                "created_at": execution.created_at,
            }
            for execution in executions
        ],
    }


# ---------------------------------------------------------------------------
# Tool registry
# ---------------------------------------------------------------------------


def _tool_out(db, tool: Tool) -> dict[str, Any]:
    return {
        "id": tool.id,
        "name": tool.name,
        "display_name": tool.display_name,
        "description": tool.description,
        "integration": tool.integration.key if tool.integration else None,
        "integration_id": tool.integration_id,
        "agent_scope": tool.agent_scope or [],
        "required_permission": tool.required_permission,
        "input_schema": tool.input_schema or {},
        "side_effect": tool.side_effect,
        "risk_level": tool.risk_level,
        "requires_approval": tool.requires_approval,
        "retry_safe": tool.retry_safe,
        "reversible": tool.reversible,
        "produces_documents": tool.produces_documents,
        "enabled": tool.enabled,
        "connection_status": tool.connection_status,
        "has_adapter": tool.name in HANDLERS,
        "last_used_at": tool.last_used_at,
        "created_at": tool.created_at,
    }


@router.get("/api/tools")
def list_tools(user: CurrentUser, db: DbSession) -> list[dict[str, Any]]:
    if not has_permission(user, "tools.view"):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Your role cannot view the tool registry")
    return [_tool_out(db, tool) for tool in db.scalars(select(Tool).order_by(Tool.name))]


@router.post("/api/tools", status_code=status.HTTP_201_CREATED)
def register_tool(
    payload: ToolRegisterRequest, user: CurrentUser, db: DbSession
) -> dict[str, Any]:
    if not has_permission(user, "tools.manage"):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Only administrators may register tools")
    if db.scalar(select(Tool).where(Tool.name == payload.name)):
        raise HTTPException(status.HTTP_409_CONFLICT, f"Tool '{payload.name}' already exists")
    try:
        Draft202012Validator.check_schema(payload.input_schema or {"type": "object"})
    except Exception as error:  # noqa: BLE001 - jsonschema raises many types
        raise HTTPException(422, f"Invalid input schema: {error}") from error
    integration = db.scalar(select(Integration).where(Integration.key == payload.integration_key))
    if integration is None:
        raise HTTPException(422, "Unknown integration_key")
    tool = Tool(
        name=payload.name,
        display_name=payload.display_name,
        description=payload.description,
        integration_id=integration.id,
        agent_scope=payload.agent_scope,
        required_permission=payload.required_permission,
        input_schema=payload.input_schema,
        side_effect=payload.side_effect,
        risk_level=payload.risk_level,
        requires_approval=payload.requires_approval,
        retry_safe=payload.retry_safe,
        reversible=payload.reversible,
        enabled=payload.enabled,
        connection_status="not_configured",
    )
    db.add(tool)
    db.commit()
    db.refresh(tool)
    audit.record(
        db,
        event_type="tool_registered",
        message=f"{user.email} registered tool '{tool.name}'",
        actor=user.email,
        tool_name=tool.name,
        severity="warning" if tool.risk_level in ("high", "critical") else "info",
    )
    return _tool_out(db, tool)


@router.patch("/api/tools/{tool_name}")
def update_tool(
    tool_name: str, payload: ToolUpdateRequest, user: CurrentUser, db: DbSession
) -> dict[str, Any]:
    tool = db.scalar(select(Tool).where(Tool.name == tool_name))
    if tool is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"Tool '{tool_name}' not found")
    if not has_permission(user, "tools.manage"):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Only administrators may change the registry")
    changes = {key: value for key, value in payload.model_dump().items() if value is not None}
    if not changes:
        raise HTTPException(422, "No changes supplied")
    for key, value in changes.items():
        setattr(tool, key, value)
    db.commit()
    audit.record(
        db,
        event_type="tool_updated",
        message=f"{user.email} updated '{tool_name}': {json.dumps(changes, default=str)}",
        actor=user.email,
        tool_name=tool_name,
        severity="warning" if changes.get("enabled") is False or tool.risk_level in ("high", "critical") else "info",
    )
    return _tool_out(db, tool)


@router.post("/api/tools/{tool_name}/validate")
def validate_tool(tool_name: str, user: CurrentUser, db: DbSession) -> dict[str, Any]:
    """Validate a sample payload against the tool's input schema."""
    tool = db.scalar(select(Tool).where(Tool.name == tool_name))
    if tool is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"Tool '{tool_name}' not found")
    sample = _sample_arguments(tool)
    try:
        registry.definition(tool_name)
        known = True
    except Exception:  # noqa: BLE001 - operator-registered tools have no code definition
        known = False
    errors: list[str] = []
    try:
        Draft202012Validator(tool.input_schema or {"type": "object"}).validate(sample)
    except Exception as error:  # noqa: BLE001
        errors.append(str(error))
    return {
        "tool": tool_name,
        "schema_valid": not errors,
        "errors": errors,
        "catalog_definition": known,
        "adapter_available": tool_name in HANDLERS,
        "sample_payload": sample,
        "required_fields": (tool.input_schema or {}).get("required", []),
    }


def _sample_arguments(tool: Tool) -> dict[str, Any]:
    properties = (tool.input_schema or {}).get("properties") or {}
    sample: dict[str, Any] = {}
    for key in (tool.input_schema or {}).get("required", []):
        declared = (properties.get(key) or {}).get("type", "string")
        sample[key] = {"string": "sample", "number": 100, "integer": 1, "boolean": True, "array": []}.get(
            declared, "sample"
        )
    return sample


@router.post("/api/tools/sync")
def resync_catalog(user: CurrentUser, db: DbSession) -> dict[str, Any]:
    if not has_permission(user, "tools.manage"):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Only administrators may resync the registry")
    counts = sync_catalog(db)
    audit.record(
        db,
        event_type="tool_updated",
        message=f"{user.email} resynchronised the tool catalog ({counts['tools']} tools)",
        actor=user.email,
    )
    return counts


# ---------------------------------------------------------------------------
# Integrations
# ---------------------------------------------------------------------------


def _integration_out(db, integration: Integration) -> dict[str, Any]:
    tools = list(integration.tools)
    return {
        "id": integration.id,
        "key": integration.key,
        "name": integration.name,
        "description": integration.description,
        "system_type": integration.system_type,
        "connection_status": integration.connection_status,
        "available_operations": integration.available_operations or [],
        "required_permissions": integration.required_permissions or [],
        "base_url": integration.base_url,
        "is_simulated": integration.is_simulated,
        "config": integration.config or {},
        "last_activity_at": integration.last_activity_at,
        "tool_count": len(tools),
        "enabled_tools": sum(1 for tool in tools if tool.enabled),
        "tools": [
            {
                "name": tool.name,
                "display_name": tool.display_name,
                "enabled": tool.enabled,
                "risk_level": tool.risk_level,
                "side_effect": tool.side_effect,
                "requires_approval": tool.requires_approval,
            }
            for tool in tools
        ],
    }


@router.get("/api/integrations")
def list_integrations(user: CurrentUser, db: DbSession) -> list[dict[str, Any]]:
    if not has_permission(user, "integrations.view"):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Your role cannot view integrations")
    return [_integration_out(db, row) for row in db.scalars(select(Integration).order_by(Integration.name))]


@router.patch("/api/integrations/{key}")
def update_integration(
    key: str, payload: IntegrationUpdateRequest, user: CurrentUser, db: DbSession
) -> dict[str, Any]:
    integration = db.scalar(select(Integration).where(Integration.key == key))
    if integration is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"Integration '{key}' not found")
    if not has_permission(user, "integrations.manage"):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Only administrators may reconfigure integrations")
    integration.connection_status = payload.connection_status
    if payload.config is not None:
        integration.config = payload.config
    db.commit()
    for tool in integration.tools:
        tool.connection_status = "online" if payload.connection_status == "connected" else payload.connection_status
    db.commit()
    audit.record(
        db,
        event_type="integration_updated",
        message=f"{user.email} set {integration.name} to {payload.connection_status}",
        actor=user.email,
        severity="warning" if payload.connection_status != "connected" else "info",
    )
    return _integration_out(db, integration)


@router.post("/api/integrations/{key}/test")
def test_integration(key: str, user: CurrentUser, db: DbSession) -> dict[str, Any]:
    """Ping the sandbox adapter for every tool on this integration."""
    integration = db.scalar(select(Integration).where(Integration.key == key))
    if integration is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"Integration '{key}' not found")
    results = []
    for tool in integration.tools:
        definition = get_tool_definition(tool.name)
        results.append(
            {
                "tool": tool.name,
                "enabled": tool.enabled,
                "adapter_available": tool.name in HANDLERS,
                "schema_declared": bool(definition or tool.input_schema),
                "reachable": integration.connection_status == "connected",
                "simulated": True,
            }
        )
    audit.record(
        db,
        event_type="integration_updated",
        message=f"{user.email} ran connectivity checks against {integration.name} (sandbox)",
        actor=user.email,
    )
    return {
        "integration": integration.key,
        "status": integration.connection_status,
        "simulated": True,
        "note": "Sandbox connectivity check only. No production endpoint was contacted.",
        "tools": results,
    }
