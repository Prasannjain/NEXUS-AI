"""Audit log endpoints: search, filter, per-workflow history and CSV export."""
from __future__ import annotations

import csv
import io
import json
from datetime import datetime

from fastapi import APIRouter, HTTPException, Query, status
from fastapi.responses import StreamingResponse
from sqlalchemy import func, or_, select

from ..deps import CurrentUser, DbSession, has_permission
from ..models import AuditLog
from ..services.audit import EVENT_TYPES

router = APIRouter(prefix="/api/audit", tags=["audit"])

MAX_EXPORT_ROWS = 20000


def _filters(
    q: str | None,
    workflow_id: str | None,
    agent_name: str | None,
    event_type: str | None,
    severity: str | None,
    date_from: datetime | None,
    date_to: datetime | None,
):
    conditions = []
    if q:
        pattern = f"%{q}%"
        conditions.append(
            or_(
                AuditLog.message.ilike(pattern),
                AuditLog.actor.ilike(pattern),
                AuditLog.tool_name.ilike(pattern),
                AuditLog.workflow_id.ilike(pattern),
                AuditLog.input_summary.ilike(pattern),
                AuditLog.output_summary.ilike(pattern),
            )
        )
    if workflow_id:
        conditions.append(AuditLog.workflow_id == workflow_id)
    if agent_name:
        conditions.append(AuditLog.agent_name == agent_name)
    if event_type:
        conditions.append(AuditLog.event_type == event_type)
    if severity:
        conditions.append(AuditLog.severity == severity)
    if date_from:
        conditions.append(AuditLog.created_at >= date_from)
    if date_to:
        conditions.append(AuditLog.created_at <= date_to)
    return conditions


def _query(conditions):
    statement = select(AuditLog)
    for condition in conditions:
        statement = statement.where(condition)
    return statement


def _row(entry: AuditLog) -> dict:
    return {
        "id": entry.id,
        "workflow_id": entry.workflow_id,
        "task_id": entry.task_id,
        "agent_name": entry.agent_name,
        "event_type": entry.event_type,
        "actor": entry.actor,
        "message": entry.message,
        "tool_name": entry.tool_name,
        "input_summary": entry.input_summary,
        "output_summary": entry.output_summary,
        "severity": entry.severity,
        "payload": entry.payload or {},
        "created_at": entry.created_at,
    }


@router.get("")
def search_audit(
    user: CurrentUser,
    db: DbSession,
    q: str | None = None,
    workflow_id: str | None = None,
    agent_name: str | None = None,
    event_type: str | None = None,
    severity: str | None = None,
    date_from: datetime | None = None,
    date_to: datetime | None = None,
    limit: int = Query(default=100, le=500),
    offset: int = 0,
) -> dict:
    if not has_permission(user, "audit.view"):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Your role cannot read the audit trail")
    conditions = _filters(q, workflow_id, agent_name, event_type, severity, date_from, date_to)
    total = db.scalar(select(func.count()).select_from(_query(conditions).subquery())) or 0
    entries = db.scalars(_query(conditions).order_by(AuditLog.id.desc()).limit(limit).offset(offset))
    return {"total": total, "limit": limit, "offset": offset, "items": [_row(entry) for entry in entries]}


@router.get("/facets")
def facets(user: CurrentUser, db: DbSession) -> dict:
    if not has_permission(user, "audit.view"):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Your role cannot read the audit trail")
    agents = db.execute(select(AuditLog.agent_name, func.count()).group_by(AuditLog.agent_name)).all()
    events = db.execute(select(AuditLog.event_type, func.count()).group_by(AuditLog.event_type)).all()
    return {
        "agents": [{"name": name, "count": count} for name, count in agents if name],
        "event_types": [{"name": name, "count": count} for name, count in events],
        "known_event_types": sorted(EVENT_TYPES),
        "severities": ["info", "warning", "error"],
        "total_entries": db.scalar(select(func.count(AuditLog.id))) or 0,
        "append_only": True,
    }


@router.get("/export.csv")
def export_csv(
    user: CurrentUser,
    db: DbSession,
    q: str | None = None,
    workflow_id: str | None = None,
    agent_name: str | None = None,
    event_type: str | None = None,
    severity: str | None = None,
    date_from: datetime | None = None,
    date_to: datetime | None = None,
) -> StreamingResponse:
    if not has_permission(user, "audit.view"):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Your role cannot export the audit trail")
    conditions = _filters(q, workflow_id, agent_name, event_type, severity, date_from, date_to)
    entries = list(db.scalars(_query(conditions).order_by(AuditLog.id).limit(MAX_EXPORT_ROWS)))

    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(
        [
            "id", "timestamp_utc", "workflow_id", "task_id", "agent", "event_type", "actor",
            "severity", "tool", "message", "input_summary", "output_summary", "payload",
        ]
    )
    for entry in entries:
        writer.writerow(
            [
                entry.id,
                entry.created_at.isoformat() if entry.created_at else "",
                entry.workflow_id or "",
                entry.task_id,
                entry.agent_name,
                entry.event_type,
                entry.actor,
                entry.severity,
                entry.tool_name,
                entry.message,
                entry.input_summary,
                entry.output_summary,
                json.dumps(entry.payload or {}, default=str),
            ]
        )
    buffer.seek(0)
    filename = f"nexus-audit-{workflow_id or 'all'}.csv"
    return StreamingResponse(
        iter([buffer.getvalue()]),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.get("/workflow/{workflow_id}")
def workflow_history(workflow_id: str, user: CurrentUser, db: DbSession) -> list[dict]:
    if not has_permission(user, "audit.view"):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Your role cannot read the audit trail")
    entries = db.scalars(
        select(AuditLog).where(AuditLog.workflow_id == workflow_id).order_by(AuditLog.id)
    )
    return [_row(entry) for entry in entries]
