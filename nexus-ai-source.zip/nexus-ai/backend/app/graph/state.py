"""Shared workflow state carried between orchestrator nodes."""
from __future__ import annotations

from typing import Any, TypedDict

STAGES = [
    {"key": "user_input", "label": "User Input", "description": "Natural-language business request"},
    {"key": "command_center", "label": "AI Command Center", "description": "Web app submits the request"},
    {"key": "backend", "label": "Backend Processing", "description": "FastAPI authenticates and allocates a workflow id"},
    {"key": "planner", "label": "Planner Agent", "description": "LLM decomposes the request into tasks"},
    {"key": "orchestrator", "label": "LangGraph Orchestrator", "description": "Routes tasks and tracks dependencies"},
    {"key": "agents", "label": "Specialized AI Agents", "description": "HR, Document, IT, Finance and Support agents"},
    {"key": "tool_registry", "label": "Tool Registry", "description": "Authorisation and schema validation"},
    {"key": "approval", "label": "Human Approval", "description": "Checkpoint that pauses the graph"},
    {"key": "execution", "label": "Execution Agent", "description": "Performs approved operations and verifies results"},
    {"key": "recovery", "label": "Failure Recovery", "description": "Backoff retry, compensation and escalation"},
    {"key": "audit", "label": "Audit Logging", "description": "Append-only record of every decision"},
    {"key": "report", "label": "Final Report", "description": "Execution report and completion notification"},
]


class WorkflowState(TypedDict, total=False):
    """Every node receives this and returns the keys it changed."""

    workflow_id: str
    request_text: str
    category_hint: str | None
    requester_email: str
    requester_name: str
    requester_permissions: list[str]

    plan: dict[str, Any]
    tasks: list[dict[str, Any]]
    current_task_id: str
    attempt: int

    stage: str
    active_agent: str
    progress: float
    status: str
    last_error: str
    failure_reason: str
    approval_outcome: str
    escalated: bool
    summary: str
