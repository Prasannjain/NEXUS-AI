"""Background runtime that drives the LangGraph workflow.

The API returns immediately after queueing a workflow; the graph runs in a
worker thread and streams its progress into the database, which the monitor
polls. An approval checkpoint suspends the thread on ``interrupt()`` and a
later ``resume()`` call continues from the persisted checkpoint.
"""
from __future__ import annotations

import threading
from typing import Any

from langgraph.types import Command

from ..database import session_scope
from ..models import Workflow
from ..services import audit
from .orchestrator import get_graph

_lock = threading.Lock()
_running: set[str] = set()


class WorkflowAlreadyRunning(RuntimeError):
    pass


def graph_config(workflow_id: str) -> dict[str, Any]:
    return {"configurable": {"thread_id": workflow_id}, "recursion_limit": 300}


def is_running(workflow_id: str) -> bool:
    with _lock:
        return workflow_id in _running


def active_run_count() -> int:
    with _lock:
        return len(_running)


def _claim(workflow_id: str) -> bool:
    with _lock:
        if workflow_id in _running:
            return False
        _running.add(workflow_id)
        return True


def _release(workflow_id: str) -> None:
    with _lock:
        _running.discard(workflow_id)


def _mark_paused(workflow_id: str) -> None:
    with session_scope() as db:
        workflow = db.get(Workflow, workflow_id)
        if workflow and workflow.status not in ("awaiting_approval",):
            workflow.status = "awaiting_approval"
            workflow.current_stage = "Human Approval"
            workflow.active_agent = "Approval Agent"
            db.commit()


def _mark_crashed(workflow_id: str, error: Exception) -> None:
    with session_scope() as db:
        workflow = db.get(Workflow, workflow_id)
        if workflow is None:
            return
        workflow.status = "failed"
        workflow.current_stage = "Failure Recovery"
        workflow.error_message = f"Orchestrator fault: {error}"
        db.commit()
        audit.record(
            db,
            event_type="workflow_failed",
            message=f"Orchestrator fault in {workflow_id}: {error}",
            workflow_id=workflow_id,
            agent_name="orchestrator",
            severity="error",
        )


def _execute(workflow_id: str, payload: Any) -> dict[str, Any]:
    graph = get_graph()
    config = graph_config(workflow_id)
    try:
        result = graph.invoke(payload, config)
        if isinstance(result, dict) and result.get("__interrupt__"):
            _mark_paused(workflow_id)
        return result if isinstance(result, dict) else {}
    finally:
        _release(workflow_id)


def run_sync(workflow_id: str, payload: Any) -> dict[str, Any]:
    """Blocking run used by tests and the CLI demo script."""
    if not _claim(workflow_id):
        raise WorkflowAlreadyRunning(workflow_id)
    try:
        return _execute(workflow_id, payload)
    except Exception as error:  # noqa: BLE001
        _mark_crashed(workflow_id, error)
        raise


def start_workflow(payload: dict[str, Any]) -> bool:
    """Queue a workflow on a worker thread. Returns False if one is active."""
    workflow_id = payload["workflow_id"]
    if not _claim(workflow_id):
        return False
    thread = threading.Thread(
        target=_guarded, args=(workflow_id, payload), name=f"nexus-graph-{workflow_id}", daemon=True
    )
    thread.start()
    return True


def resume_workflow(workflow_id: str, resume_value: Any = None) -> bool:
    """Continue a checkpointed workflow after a human decision."""
    if not _claim(workflow_id):
        return False
    payload = Command(resume=resume_value if resume_value is not None else {"source": "approval_api"})
    thread = threading.Thread(
        target=_guarded, args=(workflow_id, payload), name=f"nexus-resume-{workflow_id}", daemon=True
    )
    thread.start()
    return True


def _guarded(workflow_id: str, payload: Any) -> None:
    try:
        result = _execute(workflow_id, payload)
        if isinstance(result, dict) and result.get("__interrupt__"):
            _mark_paused(workflow_id)
    except Exception as error:  # noqa: BLE001 - a worker must never die silently
        _release(workflow_id)
        _mark_crashed(workflow_id, error)


def checkpoint_state(workflow_id: str) -> dict[str, Any]:
    """Inspect where the graph is parked - used by the monitor."""
    graph = get_graph()
    try:
        state = graph.get_state(graph_config(workflow_id))
    except Exception:  # noqa: BLE001 - no checkpoint yet
        return {"exists": False}
    values = state.values if state else {}
    interrupts = []
    for task in getattr(state, "tasks", ()) or ():
        for pending in getattr(task, "interrupts", ()) or ():
            interrupts.append(getattr(pending, "value", pending))
    return {
        "exists": True,
        "next_nodes": list(getattr(state, "next", ()) or ()),
        "interrupts": interrupts,
        "current_node": values.get("stage", ""),
        "progress": values.get("progress", 0.0),
    }
