"""LangGraph orchestrator.

Central engine that runs a workflow plan: it routes each task to the specialised
agent that owns it, pauses the graph at human-approval checkpoints with
``interrupt()``, executes approved tool calls through the registry, retries
transient failures with exponential backoff, records everything in the audit
trail and finally produces the execution report.
"""
from __future__ import annotations

import asyncio
import os
import sqlite3
import time
from datetime import datetime, timezone
from typing import Any

from langgraph.graph import END, START, StateGraph
from langgraph.types import interrupt
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..agents.catalog import agent_display_name
from ..agents.planner import build_plan
from ..config import settings
from ..database import session_scope
from ..models import (
    AgentExecution,
    Approval,
    GeneratedDocument,
    Notification,
    ToolCall,
    Workflow,
    WorkflowTask,
    utcnow,
)
from ..services import audit
from ..tools.adapters import ToolExecutionError
from ..tools.definitions import get_tool_definition
from ..tools.registry import AuthorizationContext, ToolPermissionDenied, registry
from . import recovery
from .state import STAGES, WorkflowState

TERMINAL_TASK_STATES = {"completed", "failed", "rejected", "skipped"}


# ---------------------------------------------------------------------------
# Persistence helpers
# ---------------------------------------------------------------------------


def _load_workflow(db: Session, workflow_id: str) -> Workflow:
    workflow = db.get(Workflow, workflow_id)
    if workflow is None:
        raise RuntimeError(f"Workflow {workflow_id} not found")
    return workflow


def _patch_workflow(db: Session, workflow_id: str, **fields: Any) -> Workflow:
    workflow = _load_workflow(db, workflow_id)
    for key, value in fields.items():
        setattr(workflow, key, value)
    db.commit()
    return workflow


def _progress_of(tasks: list[dict[str, Any]]) -> float:
    if not tasks:
        return 0.0
    done = sum(1 for task in tasks if task.get("status") in TERMINAL_TASK_STATES)
    return round(done / len(tasks) * 100, 1)


def _task(tasks: list[dict[str, Any]], task_id: str) -> dict[str, Any] | None:
    return next((task for task in tasks if task.get("task_id") == task_id), None)


def _sync_tasks(db: Session, workflow_id: str, tasks: list[dict[str, Any]]) -> None:
    """Mirror the in-graph task list onto workflow_tasks rows."""
    existing = {row.task_id: row for row in db.scalars(select(WorkflowTask).where(WorkflowTask.workflow_id == workflow_id))}
    for index, task in enumerate(tasks, start=1):
        row = existing.get(task["task_id"])
        if row is None:
            row = WorkflowTask(workflow_id=workflow_id, task_id=task["task_id"])
            db.add(row)
        row.seq = index
        row.description = task.get("description", "")
        row.agent_name = task.get("agent", "")
        row.tool_name = task.get("tool", "")
        row.arguments = task.get("arguments", {})
        row.depends_on = task.get("depends_on", [])
        row.requires_approval = bool(task.get("requires_approval"))
        row.risk_level = task.get("risk_level", "low")
        row.reversible = bool(task.get("reversible", True))
        row.status = task.get("status", "pending")
        row.result = task.get("result")
        row.output_summary = task.get("output_summary", "")
        row.error = task.get("error", "")
        row.attempts = int(task.get("attempts", 0) or 0)
        row.idempotency_key = registry.idempotency_key(workflow_id, task["task_id"], task.get("tool", ""))
        row.started_at = _from_iso(task.get("started_at")) or row.started_at
        row.finished_at = _from_iso(task.get("finished_at")) or row.finished_at
    db.commit()


def _from_iso(value: Any) -> datetime | None:
    if isinstance(value, datetime):
        return value
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value))
    except ValueError:
        return None


def _iso(value: datetime | None) -> str:
    return value.isoformat() if value else ""


def _record_execution(
    db: Session,
    *,
    workflow_id: str,
    agent_name: str,
    task_id: str,
    node: str,
    status: str,
    decision: str = "",
    input_summary: str = "",
    output_summary: str = "",
    error: str = "",
    duration_ms: float = 0.0,
) -> None:
    db.add(
        AgentExecution(
            workflow_id=workflow_id,
            agent_name=agent_name,
            task_id=task_id,
            node=node,
            status=status,
            decision=decision,
            input_summary=input_summary[:2000],
            output_summary=output_summary[:2000],
            error=error[:2000],
            duration_ms=round(duration_ms, 2),
        )
    )
    db.commit()


def _notify(
    db: Session,
    *,
    workflow: Workflow,
    recipient: str,
    title: str,
    message: str,
    level: str = "info",
) -> None:
    db.add(
        Notification(
            user_id=workflow.user_id,
            workflow_id=workflow.id,
            title=title,
            message=message,
            level=level,
            recipient=recipient,
        )
    )
    db.commit()


def derive_final_status(tasks: list[dict[str, Any]]) -> str:
    if not tasks:
        return "failed"
    statuses = [task.get("status") for task in tasks]
    completed = sum(1 for status in statuses if status == "completed")
    failed = sum(1 for status in statuses if status == "failed")
    rejected = sum(1 for status in statuses if status == "rejected")
    skipped = sum(1 for status in statuses if status == "skipped")
    if completed == len(tasks):
        return "completed"
    if completed == 0:
        return "rejected" if rejected else "failed"
    if failed or rejected or skipped:
        return "completed_with_exceptions"
    return "completed"


# ---------------------------------------------------------------------------
# Graph nodes
# ---------------------------------------------------------------------------


def node_intake(state: WorkflowState) -> dict[str, Any]:
    workflow_id = state["workflow_id"]
    with session_scope() as db:
        workflow = _patch_workflow(
            db,
            workflow_id,
            status="running",
            current_stage="Backend Processing",
            active_agent="FastAPI Gateway",
            started_at=workflow_started(db, workflow_id),
            request_text=state.get("request_text") or workflow.request_text,
        )
        audit.record(
            db,
            event_type="workflow_started",
            message=f"Workflow {workflow_id} accepted for '{workflow.category}' processing",
            workflow_id=workflow_id,
            agent_name="gateway",
            actor=state.get("requester_email", "system"),
            input_summary=(state.get("request_text") or "")[:500],
        )
    return {"stage": "Backend Processing", "active_agent": "FastAPI Gateway", "status": "running"}


def workflow_started(db: Session, workflow_id: str) -> datetime:
    workflow = db.get(Workflow, workflow_id)
    return workflow.started_at or utcnow()


async def _plan(request_text: str, category_hint: str | None) -> dict[str, Any]:
    return (await build_plan(request_text, category_hint)).to_dict()


def node_plan(state: WorkflowState) -> dict[str, Any]:
    workflow_id = state["workflow_id"]
    started = time.perf_counter()
    with session_scope() as db:
        workflow = _load_workflow(db, workflow_id)
        cached = workflow.plan or {}
        tasks = [dict(task) for task in (state.get("tasks") or cached.get("tasks") or [])]
        if not tasks:
            plan = asyncio.run(_plan(workflow.request_text, state.get("category_hint")))
            tasks = [dict(task, status="pending", attempts=0, result=None,
                           output_summary="", error="",
                           started_at="", finished_at="") for task in plan["tasks"]]
            workflow.plan = {**plan, "tasks": tasks}
            workflow.category = plan["category"]
            workflow.title = plan["objective"][:200]
            workflow.llm_provider = f"{plan['provider']} ({plan['model']})"
            workflow.current_stage = "Planner Agent"
            workflow.active_agent = "Planner Agent"
            db.commit()
            audit.record(
                db,
                event_type="workflow_planned",
                message=f"Planner produced {len(tasks)} task(s) for {plan['category_label']} "
                        f"using the {plan['source']} planner",
                workflow_id=workflow_id,
                agent_name="planner",
                actor=state.get("requester_email", "system"),
                input_summary=workflow.request_text[:500],
                output_summary="; ".join(f"{t['task_id']}:{t['agent']}:{t['tool']}" for t in tasks)[:1500],
                payload={"rationale": plan.get("rationale", ""), "entities": plan.get("entities", {})},
            )
            _record_execution(
                db,
                workflow_id=workflow_id,
                agent_name="planner",
                task_id="",
                node="planner",
                status="completed",
                decision=plan.get("rationale", "")[:500],
                input_summary=workflow.request_text[:500],
                output_summary=f"{len(tasks)} tasks across "
                               f"{sorted({t['agent'] for t in tasks})}",
                duration_ms=(time.perf_counter() - started) * 1000,
            )
        _sync_tasks(db, workflow_id, tasks)
        persisted_plan = dict(workflow.plan or {})
    return {"tasks": tasks, "plan": persisted_plan, "stage": "Planner Agent"}


def node_select_task(state: WorkflowState) -> dict[str, Any]:
    tasks = [dict(task) for task in state.get("tasks", [])]
    completed = {task["task_id"] for task in tasks if task.get("status") == "completed"}
    next_task = None
    for task in tasks:
        if task.get("status") in TERMINAL_TASK_STATES:
            continue
        if all(dep in completed for dep in task.get("depends_on", [])):
            next_task = task
            break
    if next_task is None:
        return {"tasks": tasks, "current_task_id": "", "stage": "LangGraph Orchestrator"}
    next_task["status"] = "ready"
    with session_scope() as db:
        _patch_workflow(
            db,
            state["workflow_id"],
            current_stage="LangGraph Orchestrator",
            active_agent="LangGraph Orchestrator",
            progress=_progress_of(tasks),
        )
        audit.record(
            db,
            event_type="task_started",
            message=f"Orchestrator routed {next_task['task_id']} to the "
                    f"{agent_display_name(next_task['agent'])}",
            workflow_id=state["workflow_id"],
            task_id=next_task["task_id"],
            agent_name=next_task["agent"],
            input_summary=next_task.get("description", ""),
        )
    return {"tasks": tasks, "current_task_id": next_task["task_id"], "attempt": 1, "last_error": ""}


def route_after_select(state: WorkflowState) -> str:
    task = _task(state.get("tasks", []), state.get("current_task_id", ""))
    if task is None:
        return "finalize"
    return task["agent"]


def make_agent_node(agent_name: str):
    """Each specialised agent prepares the authorised invocation for its task."""

    def agent_node(state: WorkflowState) -> dict[str, Any]:
        tasks = [dict(task) for task in state.get("tasks", [])]
        task = _task(tasks, state.get("current_task_id", ""))
        if task is None or task.get("agent") != agent_name:
            return {"tasks": tasks}
        task["status"] = "prepared"
        task["started_at"] = task.get("started_at") or utcnow().isoformat()
        definition = get_tool_definition(task["tool"])
        display = agent_display_name(agent_name)
        started = time.perf_counter()
        with session_scope() as db:
            _patch_workflow(
                db,
                state["workflow_id"],
                current_stage="Specialized AI Agents",
                active_agent=display,
            )
            decision = (
                f"{display} prepared `{task['tool']}` for task {task['task_id']}: {task['description']}. "
                f"Argument keys: {sorted((task.get('arguments') or {}).keys())}. "
                f"Registry policy: risk={definition.risk_level}, side_effect={definition.side_effect}, "
                f"human approval {'required' if task.get('requires_approval') else 'not required'}."
            )
            _record_execution(
                db,
                workflow_id=state["workflow_id"],
                agent_name=agent_name,
                task_id=task["task_id"],
                node=f"{agent_name}_agent",
                status="completed",
                decision=decision,
                input_summary=task.get("description", ""),
                output_summary=f"proposed invocation of {task['tool']}",
                duration_ms=(time.perf_counter() - started) * 1000,
            )
            audit.record(
                db,
                event_type="agent_decision",
                message=decision,
                workflow_id=state["workflow_id"],
                task_id=task["task_id"],
                agent_name=agent_name,
                tool_name=task["tool"],
                input_summary=str(task.get("arguments", {}))[:500],
            )
            _sync_tasks(db, state["workflow_id"], tasks)
        return {"tasks": tasks, "stage": "Specialized AI Agents", "active_agent": display}

    return agent_node


def _approval_for(db: Session, workflow_id: str, task_id: str) -> Approval | None:
    return db.scalar(
        select(Approval)
        .where(Approval.workflow_id == workflow_id, Approval.task_id == task_id)
        .order_by(Approval.id.desc())
    )


def node_approval_gate(state: WorkflowState) -> dict[str, Any]:
    tasks = [dict(task) for task in state.get("tasks", [])]
    task = _task(tasks, state.get("current_task_id", ""))
    workflow_id = state["workflow_id"]
    if task is None:
        return {"tasks": tasks, "approval_outcome": "not_required"}
    if not task.get("requires_approval"):
        return {"tasks": tasks, "approval_outcome": "not_required"}

    definition = get_tool_definition(task["tool"])
    with session_scope() as db:
        approval = _approval_for(db, workflow_id, task["task_id"])
        if approval is None:
            workflow = _load_workflow(db, workflow_id)
            approval = Approval(
                workflow_id=workflow_id,
                task_id=task["task_id"],
                agent_name=task["agent"],
                action=f"{definition.display_name} ({task['tool']})",
                details={
                    "description": task.get("description", ""),
                    "arguments": task.get("arguments", {}),
                    "tool": task["tool"],
                    "side_effect": definition.side_effect,
                    "retry_safe": definition.retry_safe,
                    "request_text": workflow.request_text,
                    "requested_by": workflow.user.email if workflow.user else "",
                },
                risk_level=definition.risk_level,
                policy_reason=(
                    f"Registry policy requires a human checkpoint for '{task['tool']}' "
                    f"(risk {definition.risk_level}, {definition.side_effect} side effect"
                    + (", irreversible" if not definition.reversible else "")
                    + (", not auto-retryable" if not definition.retry_safe else "")
                    + ")."
                ),
                status="pending",
            )
            db.add(approval)
            _patch_workflow(
                db,
                workflow_id,
                status="awaiting_approval",
                current_stage="Human Approval",
                active_agent="Approval Agent",
            )
            _notify(
                db,
                workflow=workflow,
                recipient="approver@nexus-ai.example",
                title=f"Approval required: {definition.display_name}",
                message=f"Workflow {workflow_id} paused at {task['task_id']} "
                        f"({definition.risk_level} risk). Review it in Human Approvals.",
                level="warning",
            )
            audit.record(
                db,
                event_type="approval_requested",
                message=f"Approval Agent paused workflow {workflow_id} at {task['task_id']}: "
                        f"{definition.display_name}",
                workflow_id=workflow_id,
                task_id=task["task_id"],
                agent_name="approval",
                severity="warning",
                payload={"approval_id": approval.id, "risk_level": definition.risk_level},
            )
            audit.record(
                db,
                event_type="workflow_paused",
                message="LangGraph checkpoint reached - the workflow is suspended until an "
                        "authorised human decides",
                workflow_id=workflow_id,
                task_id=task["task_id"],
                agent_name="approval",
                severity="warning",
            )
            db.commit()
            approval_id = approval.id
        else:
            approval_id = approval.id

    # Suspend the graph here. The decision is read back from the database, never
    # from the resume payload, so a caller cannot forge an approval.
    while True:
        interrupt(
            {
                "approval_id": approval_id,
                "workflow_id": workflow_id,
                "task_id": task["task_id"],
                "tool": task["tool"],
                "risk_level": definition.risk_level,
                "reason": "human_approval_required",
            }
        )
        with session_scope() as db:
            row = _approval_for(db, workflow_id, task["task_id"])
            outcome = row.status if row else "rejected"
            decided_by = row.decided_by if row else ""
            comment = row.comment if row else ""
            if outcome in ("approved", "rejected"):
                if outcome == "approved":
                    _patch_workflow(db, workflow_id, status="running", current_stage="Execution Agent")
                else:
                    _patch_workflow(db, workflow_id, status="running", current_stage="Human Approval")
                audit.record(
                    db,
                    event_type="workflow_resumed" if outcome == "approved" else "workflow_resumed",
                    message=f"Workflow resumed by {decided_by or 'system'} after {outcome} of {approval_id}",
                    workflow_id=workflow_id,
                    task_id=task["task_id"],
                    agent_name="approval",
                )
                break

    with session_scope() as db:
        _sync_tasks(db, workflow_id, tasks)
    return {"tasks": tasks, "approval_outcome": outcome, "active_agent": decided_by or "approver",
            "summary": comment}


def route_after_approval(state: WorkflowState) -> str:
    return {"approved": "execute", "rejected": "reject"}.get(state.get("approval_outcome", ""), "execute")


def _effective_permissions(state: WorkflowState, task: dict[str, Any], definition) -> set[str]:
    """Role grants, widened only by an explicit human approval for this task."""
    permissions = set(state.get("requester_permissions") or [])
    if task.get("requires_approval") and state.get("approval_outcome") == "approved":
        permissions.add(definition.required_permission)
    return permissions


def node_execute(state: WorkflowState) -> dict[str, Any]:
    tasks = [dict(task) for task in state.get("tasks", [])]
    task = _task(tasks, state.get("current_task_id", ""))
    workflow_id = state["workflow_id"]
    if task is None:
        return {"tasks": tasks}
    definition = get_tool_definition(task["tool"])
    attempt = int(state.get("attempt") or 1)
    task["attempts"] = attempt
    task["status"] = "running"
    started = time.perf_counter()
    error: Exception | None = None
    outcome_data: dict[str, Any] = {}
    summary = ""
    documents: list[dict[str, Any]] = []

    with session_scope() as db:
        _patch_workflow(
            db,
            workflow_id,
            current_stage="Tool Registry",
            active_agent="Execution Agent",
        )
        _sync_tasks(db, workflow_id, tasks)

    try:
        auth = AuthorizationContext(
            agent_name=task["agent"],
            permissions=_effective_permissions(state, task, definition),
        )
        with session_scope() as db:
            outcome = registry.execute(
                db,
                name=task["tool"],
                arguments=dict(task.get("arguments") or {}),
                auth=auth,
                workflow_id=workflow_id,
                task_id=task["task_id"],
                attempt=attempt,
            )
            summary = outcome.summary
            outcome_data = outcome.data
            documents = list(outcome.documents)
            workflow = _load_workflow(db, workflow_id)
            for document in documents:
                db.add(
                    GeneratedDocument(
                        workflow_id=workflow_id,
                        task_id=task["task_id"],
                        doc_type=document.get("doc_type", "document"),
                        title=document.get("title", "Document"),
                        content=document.get("content", ""),
                        storage_path=document.get("storage_path", ""),
                        file_size=int(document.get("file_size") or 0),
                    )
                )
                audit.record(
                    db,
                    event_type="document_generated",
                    message=f"Stored {document.get('title', 'document')} at {document.get('storage_path')}",
                    workflow_id=workflow_id,
                    task_id=task["task_id"],
                    agent_name="document",
                    tool_name=task["tool"],
                )
            # Feed concrete results forward so later tasks use real identifiers.
            for key in ("employee_code", "identity_id", "mailbox", "payment_request_id"):
                if outcome_data.get(key) and key not in (task.get("arguments") or {}):
                    for later in tasks:
                        later.setdefault("arguments", {}).setdefault(key, outcome_data[key])
            db.commit()
    except (ToolExecutionError, ToolPermissionDenied, ValueError) as exc:
        error = exc
        summary = str(exc)
    except Exception as exc:  # noqa: BLE001 - unexpected adapter faults must not kill the worker
        error = exc
        summary = f"Unexpected execution fault: {exc}"

    duration_ms = (time.perf_counter() - started) * 1000
    if error is not None:
        task["error_kind"] = "transient" if recovery.is_transient(error) else "permanent"
        task["error"] = summary
    with session_scope() as db:
        if error is None:
            task["status"] = "completed"
            task["result"] = {"summary": summary, **outcome_data}
            task["output_summary"] = summary
            task["finished_at"] = utcnow().isoformat()
            task["error"] = ""
            _record_execution(
                db,
                workflow_id=workflow_id,
                agent_name="execution",
                task_id=task["task_id"],
                node="execute",
                status="completed",
                decision=f"Executed {task['tool']} on behalf of {task['agent']} and verified the result",
                input_summary=str(task.get("arguments", {}))[:500],
                output_summary=summary,
                duration_ms=duration_ms,
            )
            audit.record(
                db,
                event_type="tool_invoked",
                message=f"Execution Agent ran {task['tool']}: {summary}",
                workflow_id=workflow_id,
                task_id=task["task_id"],
                agent_name="execution",
                tool_name=task["tool"],
                input_summary=str(task.get("arguments", {}))[:500],
                output_summary=summary,
                payload={"simulated": True, "attempt": attempt, "duration_ms": round(duration_ms, 2)},
            )
            audit.record(
                db,
                event_type="task_completed",
                message=f"{task['task_id']} completed by {agent_display_name(task['agent'])}",
                workflow_id=workflow_id,
                task_id=task["task_id"],
                agent_name=task["agent"],
            )
        else:
            task["status"] = "needs_recovery"
            task["error"] = summary
            _record_execution(
                db,
                workflow_id=workflow_id,
                agent_name="execution",
                task_id=task["task_id"],
                node="execute",
                status="failed",
                decision="Execution Agent captured the fault and handed it to failure recovery",
                input_summary=str(task.get("arguments", {}))[:500],
                output_summary=summary,
                error=summary,
                duration_ms=duration_ms,
            )
            audit.record(
                db,
                event_type="tool_failed",
                message=f"{task['tool']} failed on attempt {attempt}: {summary}",
                workflow_id=workflow_id,
                task_id=task["task_id"],
                agent_name="execution",
                tool_name=task["tool"],
                severity="error",
                output_summary=summary,
            )
        _patch_workflow(db, workflow_id, current_stage="Execution Agent", active_agent="Execution Agent")
        _sync_tasks(db, workflow_id, tasks)

    return {
        "tasks": tasks,
        "last_error": summary if error is not None else "",
        "stage": "Execution Agent",
        "active_agent": "Execution Agent",
    }


def route_after_execute(state: WorkflowState) -> str:
    task = _task(state.get("tasks", []), state.get("current_task_id", ""))
    return "recover" if task and task.get("status") == "needs_recovery" else "audit"


def node_recover(state: WorkflowState) -> dict[str, Any]:
    """Failure Recovery: backoff retry, compensation, or escalation."""
    tasks = [dict(task) for task in state.get("tasks", [])]
    task = _task(tasks, state.get("current_task_id", ""))
    workflow_id = state["workflow_id"]
    if task is None:
        return {"tasks": tasks}
    definition = get_tool_definition(task["tool"])
    attempt = int(state.get("attempt") or 1)
    error_kind = task.get("error_kind", "permanent")
    error_text = state.get("last_error") or task.get("error") or "unknown failure"
    decision = recovery.decide(task, definition, error_kind, error_text, attempt)
    with session_scope() as db:
        _patch_workflow(db, workflow_id, current_stage="Failure Recovery", active_agent="Failure Recovery")
        audit.record(
            db,
            event_type="task_retry" if decision.retry else "task_failed",
            message=decision.reason,
            workflow_id=workflow_id,
            task_id=task["task_id"],
            agent_name="execution",
            tool_name=task["tool"],
            severity="warning" if decision.retry else "error",
            payload={"attempt": attempt, "retry_safe": definition.retry_safe},
        )
        if decision.retry:
            task["status"] = "retrying"
            _sync_tasks(db, workflow_id, tasks)
        else:
            task["status"] = "failed"
            task["error"] = decision.reason
            task["finished_at"] = utcnow().isoformat()
            compensation = None
            if definition.reversible:
                prior_call = db.scalar(
                    select(ToolCall).where(
                        ToolCall.idempotency_key == registry.idempotency_key(workflow_id, task["task_id"], task["tool"])
                    )
                )
                compensation = recovery.compensate(task["tool"], (prior_call.result if prior_call else {}), task.get("arguments"))
            if compensation:
                db.add(
                    ToolCall(
                        workflow_id=workflow_id,
                        task_id=task["task_id"],
                        tool_name=f"{task['tool']}.compensate",
                        agent_name="execution",
                        idempotency_key=f"{workflow_id}:{task['task_id']}:{task['tool']}:compensation",
                        arguments=task.get("arguments") or {},
                        result=compensation,
                        status="completed",
                    )
                )
                audit.record(
                    db,
                    event_type="task_rolled_back",
                    message=f"Compensating action applied for {task['tool']}: {compensation.get('compensated')}",
                    workflow_id=workflow_id,
                    task_id=task["task_id"],
                    agent_name="execution",
                    tool_name=task["tool"],
                    severity="warning",
                    output_summary=str(compensation)[:500],
                )
            workflow = _load_workflow(db, workflow_id)
            audit.record(
                db,
                event_type="workflow_escalated",
                message=f"Unresolved failure on {task['task_id']} escalated to "
                        f"{settings.workflow_escalation_email}",
                workflow_id=workflow_id,
                task_id=task["task_id"],
                agent_name="audit",
                severity="error",
            )
            _notify(
                db,
                workflow=workflow,
                recipient=settings.workflow_escalation_email,
                title=f"Escalation: {task['tool']} failed permanently",
                message=decision.reason,
                level="error",
            )
            _sync_tasks(db, workflow_id, tasks)
    if decision.retry and decision.delay_seconds:
        time.sleep(decision.delay_seconds)
    return {
        "tasks": tasks,
        "attempt": attempt + 1 if decision.retry else attempt,
        "stage": "Failure Recovery",
        "failure_reason": "" if decision.retry else decision.reason,
    }


def route_after_recover(state: WorkflowState) -> str:
    task = _task(state.get("tasks", []), state.get("current_task_id", ""))
    return "execute" if task and task.get("status") == "retrying" else "audit"


def node_reject(state: WorkflowState) -> dict[str, Any]:
    """A human rejected the checkpoint: stop this action and its dependents."""
    tasks = [dict(task) for task in state.get("tasks", [])]
    task = _task(tasks, state.get("current_task_id", ""))
    workflow_id = state["workflow_id"]
    if task is None:
        return {"tasks": tasks}
    task["status"] = "rejected"
    task["error"] = "Rejected at the human approval checkpoint"
    task["finished_at"] = utcnow().isoformat()
    blocked = _mark_dependents_skipped(tasks, task["task_id"])
    with session_scope() as db:
        workflow = _load_workflow(db, workflow_id)
        approval = _approval_for(db, workflow_id, task["task_id"])
        audit.record(
            db,
            event_type="approval_rejected",
            message=f"{approval.decided_by if approval else 'approver'} rejected {task['task_id']} "
                    f"({task['tool']}). The action was not executed.",
            workflow_id=workflow_id,
            task_id=task["task_id"],
            agent_name="approval",
            severity="warning",
            output_summary=approval.comment if approval else "",
        )
        for skipped_id in blocked:
            audit.record(
                db,
                event_type="task_skipped",
                message=f"{skipped_id} skipped because it depends on rejected {task['task_id']}",
                workflow_id=workflow_id,
                task_id=skipped_id,
                agent_name="orchestrator",
                severity="warning",
            )
        _notify(
            db,
            workflow=workflow,
            recipient=workflow.user.email if workflow.user else "requester@nexus-ai.example",
            title=f"Rejected: {task['description'][:80]}",
            message=f"An approver rejected the sensitive action in workflow {workflow_id}. "
                    f"{(approval.comment if approval else '') or 'No comment supplied.'} "
                    "The remaining dependent steps were not executed.",
            level="error",
        )
        _patch_workflow(db, workflow_id, current_stage="Human Approval", active_agent="Approval Agent")
        _sync_tasks(db, workflow_id, tasks)
    return {"tasks": tasks, "stage": "Human Approval"}


def _mark_dependents_skipped(tasks: list[dict[str, Any]], rejected_id: str) -> list[str]:
    blocked: list[str] = []
    changed = True
    frontier = {rejected_id}
    while changed:
        changed = False
        for task in tasks:
            if task.get("status") in TERMINAL_TASK_STATES:
                continue
            if frontier & set(task.get("depends_on", [])):
                task["status"] = "skipped"
                task["error"] = f"Dependency {sorted(frontier & set(task.get('depends_on', [])))} was not completed"
                blocked.append(task["task_id"])
                frontier.add(task["task_id"])
                changed = True
    return blocked


def node_audit_step(state: WorkflowState) -> dict[str, Any]:
    tasks = [dict(task) for task in state.get("tasks", [])]
    workflow_id = state["workflow_id"]
    progress = _progress_of(tasks)
    with session_scope() as db:
        _patch_workflow(db, workflow_id, current_stage="Audit Logging", active_agent="Audit Agent", progress=progress)
        _sync_tasks(db, workflow_id, tasks)
    return {"tasks": tasks, "stage": "Audit Logging", "active_agent": "Audit Agent", "progress": progress}


def node_finalize(state: WorkflowState) -> dict[str, Any]:
    workflow_id = state["workflow_id"]
    tasks = [dict(task) for task in state.get("tasks", [])]
    with session_scope() as db:
        workflow = _load_workflow(db, workflow_id)
        final_status = derive_final_status(tasks)
        report = build_report(db, workflow, tasks, final_status)
        _patch_workflow(
            db,
            workflow_id,
            status=final_status,
            current_stage="Final Report",
            active_agent="Reporter",
            progress=_progress_of(tasks),
            finished_at=utcnow(),
            final_report=report,
            result_summary=report["headline"],
            error_message="" if final_status == "completed" else report["headline"],
        )
        _sync_tasks(db, workflow_id, tasks)
        recipient = workflow.user.email if workflow.user else "requester@nexus-ai.example"
        _notify(
            db,
            workflow=workflow,
            recipient=recipient,
            title=f"Workflow {final_status.replace('_', ' ')}: {workflow.id}",
            message=report["headline"],
            level="success" if final_status == "completed" else "warning",
        )
        audit.record(
            db,
            event_type="workflow_completed" if final_status.startswith("completed") else "workflow_failed",
            message=report["headline"],
            workflow_id=workflow_id,
            agent_name="audit",
            severity="info" if final_status == "completed" else "warning",
        )
    return {"status": final_status, "stage": "Final Report", "summary": report["headline"], "tasks": tasks}


# ---------------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------------


def build_report(db: Session, workflow: Workflow, tasks: list[dict[str, Any]], final_status: str) -> dict[str, Any]:
    from ..models import AuditLog

    approvals = list(db.scalars(select(Approval).where(Approval.workflow_id == workflow.id).order_by(Approval.id)))
    calls = list(db.scalars(select(ToolCall).where(ToolCall.workflow_id == workflow.id).order_by(ToolCall.id)))
    documents = list(db.scalars(select(GeneratedDocument).where(GeneratedDocument.workflow_id == workflow.id)))
    audit_count = len(list(db.scalars(select(AuditLog.id).where(AuditLog.workflow_id == workflow.id))))
    completed = [task for task in tasks if task.get("status") == "completed"]
    failed = [task for task in tasks if task.get("status") == "failed"]
    rejected = [task for task in tasks if task.get("status") == "rejected"]
    skipped = [task for task in tasks if task.get("status") == "skipped"]
    pending = [task for task in tasks if task.get("status") not in TERMINAL_TASK_STATES]

    headline = (
        f"{len(completed)} of {len(tasks)} planned task(s) executed successfully"
        + (f", {len(failed)} failed" if failed else "")
        + (f", {len(rejected)} rejected at approval" if rejected else "")
        + (f", {len(skipped)} skipped because their dependencies were not executed" if skipped else "")
        + (f", {len(pending)} not executed" if pending else "")
        + ". All enterprise actions ran against simulated sandbox systems."
    )
    duration = workflow.duration_seconds or 0.0
    return {
        "workflow_id": workflow.id,
        "title": workflow.title or workflow.request_text[:120],
        "original_request": workflow.request_text,
        "category": workflow.category,
        "category_label": (workflow.plan or {}).get("category_label", workflow.category),
        "status": final_status,
        "headline": headline,
        "created_at": _iso(workflow.created_at),
        "started_at": _iso(workflow.started_at),
        "finished_at": _iso(workflow.finished_at or utcnow()),
        "duration_seconds": round(duration, 2),
        "llm_provider": workflow.llm_provider or "none",
        "plan_rationale": (workflow.plan or {}).get("rationale", ""),
        "entities": (workflow.plan or {}).get("entities", {}),
        "agents_involved": sorted({task.get("agent", "") for task in tasks} - {""}),
        "tasks": tasks,
        "completed_tasks": [task["task_id"] for task in completed],
        "failed_tasks": [{"task_id": task["task_id"], "reason": task.get("error", "")} for task in failed],
        "rejected_tasks": [task["task_id"] for task in rejected],
        "skipped_tasks": [task["task_id"] for task in skipped],
        "pending_tasks": [task["task_id"] for task in pending],
        "approvals": [
            {
                "id": approval.id,
                "task_id": approval.task_id,
                "agent_name": approval.agent_name,
                "action": approval.action,
                "risk_level": approval.risk_level,
                "policy_reason": approval.policy_reason,
                "status": approval.status,
                "requested_at": _iso(approval.requested_at),
                "decided_at": _iso(approval.decided_at),
                "decided_by": approval.decided_by,
                "comment": approval.comment,
            }
            for approval in approvals
        ],
        "tool_executions": [
            {
                "tool_name": call.tool_name,
                "task_id": call.task_id,
                "agent_name": call.agent_name,
                "idempotency_key": call.idempotency_key,
                "status": call.status,
                "duration_ms": call.duration_ms,
                "summary": (call.result or {}).get("summary", ""),
                "simulated": True,
                "created_at": _iso(call.created_at),
            }
            for call in calls
        ],
        "documents": [
            {
                "id": document.id,
                "title": document.title,
                "doc_type": document.doc_type,
                "storage_path": document.storage_path,
                "file_size": document.file_size,
                "created_at": _iso(document.created_at),
            }
            for document in documents
        ],
        "audit_entries": audit_count,
        "simulation_notice": (
            "NEXUS AI ran against simulated enterprise integrations. No production HR, "
            "finance, CRM, IT, document or mail system was contacted."
        ),
    }


# ---------------------------------------------------------------------------
# Graph assembly
# ---------------------------------------------------------------------------

_checkpointer = None


def get_checkpointer():
    global _checkpointer
    if _checkpointer is None:
        path = settings.checkpoint_database_path
        directory = os.path.dirname(os.path.abspath(path))
        os.makedirs(directory, exist_ok=True)
        from langgraph.checkpoint.sqlite import SqliteSaver

        connection = sqlite3.connect(path, check_same_thread=False)
        _checkpointer = SqliteSaver(connection)
    return _checkpointer


def build_graph():
    graph = StateGraph(WorkflowState)

    graph.add_node("intake", node_intake)
    graph.add_node("planner", node_plan)
    graph.add_node("select_task", node_select_task)
    for agent_name in ("hr", "document", "it", "finance", "support"):
        graph.add_node(agent_name, make_agent_node(agent_name))
    graph.add_node("approval_gate", node_approval_gate)
    graph.add_node("execute", node_execute)
    graph.add_node("recover", node_recover)
    graph.add_node("reject", node_reject)
    graph.add_node("audit_step", node_audit_step)
    graph.add_node("finalize", node_finalize)

    graph.add_edge(START, "intake")
    graph.add_edge("intake", "planner")
    graph.add_edge("planner", "select_task")
    graph.add_conditional_edges(
        "select_task",
        route_after_select,
        {
            "hr": "hr",
            "document": "document",
            "it": "it",
            "finance": "finance",
            "support": "support",
            "finalize": "finalize",
        },
    )
    for agent_name in ("hr", "document", "it", "finance", "support"):
        graph.add_edge(agent_name, "approval_gate")
    graph.add_conditional_edges(
        "approval_gate",
        route_after_approval,
        {"execute": "execute", "reject": "reject"},
    )
    graph.add_conditional_edges("execute", route_after_execute, {"recover": "recover", "audit": "audit_step"})
    graph.add_conditional_edges("recover", route_after_recover, {"execute": "execute", "audit": "audit_step"})
    graph.add_edge("reject", "audit_step")
    graph.add_edge("audit_step", "select_task")
    graph.add_edge("finalize", END)

    return graph.compile(checkpointer=get_checkpointer())


_compiled_graph = None


def get_graph():
    global _compiled_graph
    if _compiled_graph is None:
        _compiled_graph = build_graph()
    return _compiled_graph


__all__ = [
    "STAGES",
    "WorkflowState",
    "build_graph",
    "build_report",
    "get_graph",
    "derive_final_status",
]
