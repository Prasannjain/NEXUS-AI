"""Failure recovery: retry policy, idempotency guard and compensation."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from ..config import settings
from ..tools.adapters import TransientError
from ..tools.definitions import ToolDefinition

RETRYABLE_EXCEPTIONS = (TransientError, TimeoutError, ConnectionError)


@dataclass
class RecoveryDecision:
    retry: bool
    reason: str
    delay_seconds: float = 0.0
    attempt: int = 1


def is_transient(error: Exception) -> bool:
    return isinstance(error, RETRYABLE_EXCEPTIONS)


def backoff_delay(attempt: int) -> float:
    """Exponential backoff: base * factor ** (attempt - 1)."""
    return round(settings.retry_base_delay_seconds * (settings.retry_backoff_factor ** max(0, attempt - 1)), 3)


def decide(task: dict[str, Any], definition: ToolDefinition, error_kind: str, error_text: str, attempt: int) -> RecoveryDecision:
    """Decide whether a failed task may be re-attempted.

    A tool that is not retry-safe (payments and other irreversible writes) is
    never replayed automatically, even on a transient error, because a duplicate
    side effect is worse than a paused workflow.
    """
    if not definition.retry_safe:
        return RecoveryDecision(
            retry=False,
            reason=(
                f"{definition.name} is not retry-safe ({definition.side_effect} side effect, "
                f"risk {definition.risk_level}); automatic replay is blocked to prevent duplicate "
                "impact. Escalated for manual review."
            ),
            attempt=attempt,
        )
    if error_kind != "transient":
        return RecoveryDecision(retry=False, reason=f"Permanent failure: {error_text}", attempt=attempt)
    if attempt >= settings.max_task_attempts:
        return RecoveryDecision(
            retry=False,
            reason=f"Exhausted {settings.max_task_attempts} attempts. Last error: {error_text}",
            attempt=attempt,
        )
    return RecoveryDecision(
        retry=True,
        reason=f"Transient failure ({error_text}); retry {attempt + 1}/{settings.max_task_attempts} scheduled",
        delay_seconds=backoff_delay(attempt + 1),
        attempt=attempt,
    )


# ---------------------------------------------------------------------------
# Compensation (rollback) for reversible sandbox operations
# ---------------------------------------------------------------------------


def _void_employee_record(result: dict, arguments: dict) -> dict:
    return {
        "compensated": "employee_record_voided",
        "employee_code": result.get("employee_code") or arguments.get("employee_code", ""),
        "record_status": "voided_by_compensation",
    }


def _deprovision_identity(result: dict, arguments: dict) -> dict:
    return {
        "compensated": "sso_identity_disabled",
        "identity_id": result.get("identity_id", ""),
        "principal": result.get("principal") or arguments.get("full_name", ""),
        "status": "disabled",
    }


def _cancel_payment_request(result: dict, arguments: dict) -> dict:
    return {
        "compensated": "payment_request_cancelled_before_run",
        "payment_request_id": result.get("payment_request_id", ""),
        "status": "cancelled",
        "note": "Cancelled while still queued in the sandbox; no funds moved.",
    }


COMPENSATIONS: dict[str, Callable[[dict, dict], dict]] = {
    "hr.create_employee_record": _void_employee_record,
    "it.provision_sso_identity": _deprovision_identity,
    "finance.create_payment_request": _cancel_payment_request,
}


def compensate(tool_name: str, result: dict | None, arguments: dict | None) -> dict[str, Any] | None:
    """Return the compensating action for a completed write, or None if unsupported."""
    handler = COMPENSATIONS.get(tool_name)
    if handler is None:
        return None
    return handler(result or {}, arguments or {})


def compensation_supported(definition: ToolDefinition) -> bool:
    return definition.reversible and definition.name in COMPENSATIONS
