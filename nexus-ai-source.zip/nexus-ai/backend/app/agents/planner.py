"""Planner Agent.

Turns a natural-language business request into a dependency-aware execution
plan. Uses the configured LLM when one is available and falls back to a
deterministic rule engine otherwise, so planning never silently fails.

Approval requirements are never taken from the model: they are recomputed from
the tool registry, so a prompt-injected plan cannot talk its way past a
checkpoint.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any

from ..llm.provider import LLMError, llm_client
from ..tools.definitions import HIGH_RISK_LEVELS, TOOL_DEFINITIONS, get_tool_definition
from .catalog import WORKER_AGENTS

CATEGORIES = {
    "employee_onboarding": "Employee Onboarding",
    "invoice_processing": "Invoice Processing",
    "customer_request": "Customer Request Resolution",
}

CATEGORY_KEYWORDS = {
    "employee_onboarding": ["onboard", "onboarding", "new hire", "join", "employee", "offer letter", "start date"],
    "invoice_processing": ["invoice", "vendor", "payment", "billing", "po", "accounts payable"],
    "customer_request": ["customer", "ticket", "order", "support", "complaint", "refund", "delivery", "shipment"],
}

VALID_AGENTS = set(WORKER_AGENTS)
VALID_TOOLS = {tool.name for tool in TOOL_DEFINITIONS}


@dataclass
class Plan:
    category: str
    category_label: str
    objective: str
    entities: dict[str, Any] = field(default_factory=dict)
    tasks: list[dict[str, Any]] = field(default_factory=list)
    rationale: str = ""
    source: str = "rule_engine"
    provider: str = "none"
    model: str = "nexus-rule-engine"

    def to_dict(self) -> dict[str, Any]:
        return {
            "category": self.category,
            "category_label": self.category_label,
            "objective": self.objective,
            "entities": self.entities,
            "tasks": self.tasks,
            "rationale": self.rationale,
            "source": self.source,
            "provider": self.provider,
            "model": self.model,
        }


# ---------------------------------------------------------------------------
# Entity extraction
# ---------------------------------------------------------------------------

NAME_PATTERN = re.compile(
    r"\b(?i:onboard|onboarding|re onboard|re-onboard|hire|hiring|appoint|appointing|bring aboard)\s+"
    r"(?i:a|an|the|new)?\s*(?i:[a-z]+\s+){0,3}?"
    r"([A-Z][a-zA-Z'\-]+(?:\s+[A-Z][a-zA-Z'\-]+){1,2})"
)
DEPT_PATTERN = re.compile(
    r"\b(Engineering|Finance|Human Resources|HR|Sales|Customer Support|Operations|Marketing)\b", re.IGNORECASE
)
TITLE_PATTERN = re.compile(
    r"\b((?:Senior |Junior |Lead |Principal )?(?:Software|Data|DevOps|Site Reliability|Product|QA|Security|Network|"
    r"Cloud|Backend|Frontend|Full[- ]Stack|Machine Learning|Accounting|Payroll|Support)?\s?"
    r"(?:Engineer|Developer|Manager|Analyst|Administrator|Architect|Specialist|Consultant|Designer|Accountant|"
    r"Technician|Lead|Officer|Representative|Director))\b",
    re.IGNORECASE,
)
INVOICE_PATTERN = re.compile(r"\b(INV[-_ ]?\d{3,8})\b", re.IGNORECASE)
ORDER_PATTERN = re.compile(r"\b(ORD[-_ ]?\d{3,8})\b", re.IGNORECASE)
TICKET_PATTERN = re.compile(r"\b(TCK[-_ ]?\d{3,8}|CASE[-_ ]?\d{3,8})\b", re.IGNORECASE)
AMOUNT_PATTERN = re.compile(r"(?:EUR|USD|INR|€|\$|₹)\s?(\d{1,3}(?:[, ]\d{3})*(?:\.\d{1,2})?)|(\d{1,3}(?:[, ]\d{3})*(?:\.\d{1,2})?)\s*(?:EUR|USD|INR|€|\$|₹)", re.IGNORECASE)
CURRENCY_PATTERN = re.compile(r"\b(EUR|USD|INR|GBP)\b", re.IGNORECASE)
DATE_PATTERN = re.compile(r"\b(\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\d{4}-\d{2}-\d{2}|(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2}(?:,\s*\d{4})?)\b", re.IGNORECASE)
EMAIL_PATTERN = re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b")
COMPANY_SUFFIX = (
    r"(?:Group|Ltd|Limited|Inc|LLC|GmbH|Studios|Services|Solutions|Systems|Supplies|Logistics|"
    r"Retail|Foods|Technologies|Partners|Company|Data|Labs)"
)
# A company reads as up to three capitalised words (never digits, so reference
# codes such as INV-88214 cannot be swallowed) followed by a recognised suffix.
COMPANY_PHRASE = r"((?:[A-Z][A-Za-z'&-]+\s+){0,3}[A-Z][A-Za-z'&-]*\s+" + COMPANY_SUFFIX + r")"
CUSTOMER_PATTERN = re.compile(r"\b(?i:customer|client)\s+" + COMPANY_PHRASE)
VENDOR_PATTERN = re.compile(r"\b(?i:from|by|vendor|supplier)\s+" + COMPANY_PHRASE)
ANY_COMPANY_PATTERN = re.compile(COMPANY_PHRASE)
# Words that make a capitalised pair read as a role or system, not a person.
NON_NAME_WORDS = {
    "engineer", "manager", "analyst", "developer", "officer", "specialist", "department",
    "engineering", "finance", "sales", "operations", "marketing", "support", "account",
    "team", "lead", "director", "head", "sso", "laptop", "payroll", "access", "accounting",
}


def extract_entities(text: str) -> dict[str, Any]:
    entities: dict[str, Any] = {}
    stripped = text.strip()

    match = NAME_PATTERN.search(stripped)
    if match and not re.search(r"\d", match.group(1)):
        candidate = match.group(1).strip()
        if not any(word.lower() in NON_NAME_WORDS for word in candidate.split()):
            entities["full_name"] = candidate

    dept = DEPT_PATTERN.search(stripped)
    if dept:
        raw = dept.group(1).title()
        entities["department"] = "Human Resources" if raw == "Hr" else raw

    title = TITLE_PATTERN.search(stripped)
    if title:
        entities["job_title"] = " ".join(word.capitalize() for word in title.group(1).split())

    for pattern, key in (
        (INVOICE_PATTERN, "invoice_number"),
        (ORDER_PATTERN, "order_id"),
        (TICKET_PATTERN, "ticket_id"),
        (EMAIL_PATTERN, "email"),
    ):
        found = pattern.search(stripped)
        if found:
            entities[key] = found.group(0).upper() if key != "email" else found.group(0)

    amount_match = AMOUNT_PATTERN.search(stripped)
    if amount_match:
        raw = (amount_match.group(1) or amount_match.group(2)).replace(",", "").replace(" ", "")
        try:
            entities["amount"] = float(raw)
        except ValueError:
            pass

    currency = CURRENCY_PATTERN.search(stripped)
    if currency:
        entities["currency"] = currency.group(1).upper()

    date = DATE_PATTERN.search(stripped)
    if date:
        entities["start_date"] = date.group(1)

    vendor = VENDOR_PATTERN.search(stripped)
    if vendor:
        entities["vendor_name"] = vendor.group(1).strip()

    customer = CUSTOMER_PATTERN.search(stripped)
    if customer:
        entities["customer_name"] = customer.group(1).strip()
    elif not entities.get("vendor_name"):
        # No explicit connector: attribute the first company phrase to whichever
        # reference code the request carries.
        generic = ANY_COMPANY_PATTERN.search(stripped)
        if generic:
            name = generic.group(1).strip()
            if entities.get("invoice_number"):
                entities["vendor_name"] = name
            elif entities.get("order_id") or entities.get("ticket_id"):
                entities["customer_name"] = name

    if re.search(r"refund|damaged|late|delay|missing|broken|not received|wrong", stripped, re.IGNORECASE):
        entities["issue_summary"] = re.sub(r"\s+", " ", stripped)[:160]

    return entities


def classify(text: str, entities: dict[str, Any]) -> str:
    lowered = text.lower()
    scores = {
        category: sum(1 for keyword in keywords if keyword in lowered)
        for category, keywords in CATEGORY_KEYWORDS.items()
    }
    if entities.get("invoice_number") or entities.get("vendor_name"):
        scores["invoice_processing"] += 2
    if entities.get("full_name"):
        scores["employee_onboarding"] += 2
    if entities.get("order_id") or entities.get("ticket_id") or entities.get("customer_name"):
        scores["customer_request"] += 2
    best = max(scores, key=lambda key: scores[key])
    return best if scores[best] > 0 else "customer_request"


# ---------------------------------------------------------------------------
# Deterministic plan templates
# ---------------------------------------------------------------------------


def _task(
    *,
    index: int,
    agent: str,
    tool: str,
    description: str,
    arguments: dict[str, Any],
    depends_on: list[str] | None = None,
) -> dict[str, Any]:
    definition = get_tool_definition(tool)
    return {
        "task_id": f"t{index}",
        "description": description,
        "agent": agent,
        "tool": tool,
        "arguments": {key: value for key, value in arguments.items() if value not in (None, "", [])},
        "depends_on": depends_on or [],
        "requires_approval": bool(definition.requires_approval or definition.risk_level in HIGH_RISK_LEVELS),
        "risk_level": definition.risk_level,
        "reversible": definition.reversible,
        "retry_safe": definition.retry_safe,
        "side_effect": definition.side_effect,
    }


def template_plan(category: str, entities: dict[str, Any], objective: str) -> list[dict[str, Any]]:
    name = entities.get("full_name", "New Employee")
    department = entities.get("department", "Engineering")
    job_title = entities.get("job_title", "Software Engineer")
    invoice_number = entities.get("invoice_number", "INV-88215")
    order_id = entities.get("order_id", "")
    customer_name = entities.get("customer_name", "")
    ticket_id = entities.get("ticket_id", "TCK-44102")

    if category == "employee_onboarding":
        base_args = {
            "full_name": name,
            "department": department,
            "job_title": job_title,
            "email": entities.get("email"),
            "start_date": entities.get("start_date"),
        }
        return [
            _task(index=1, agent="hr", tool="hr.validate_employee_details",
                  description=f"Validate the onboarding details for {name} ({job_title}, {department})",
                  arguments=base_args),
            _task(index=2, agent="hr", tool="hr.create_employee_record",
                  description=f"Create the employee master record for {name}",
                  arguments=base_args, depends_on=["t1"]),
            _task(index=3, agent="document", tool="document.generate_offer_letter",
                  description=f"Generate the offer letter for {name}",
                  arguments=base_args, depends_on=["t2"]),
            _task(index=4, agent="document", tool="document.generate_onboarding_pack",
                  description=f"Generate the day-one onboarding pack for {name}",
                  arguments={"full_name": name, "job_title": job_title, "start_date": entities.get("start_date")},
                  depends_on=["t2"]),
            _task(index=5, agent="it", tool="it.create_email_account",
                  description=f"Provision the corporate mailbox for {name}",
                  arguments={"full_name": name, "department": department}, depends_on=["t2"]),
            _task(index=6, agent="it", tool="it.provision_sso_identity",
                  description=f"Provision SSO identity and MFA enrolment for {name}",
                  arguments={"full_name": name, "email": entities.get("email")}, depends_on=["t5"]),
            _task(index=7, agent="it", tool="it.grant_system_access",
                  description=f"Grant role-based system access for the {job_title} role",
                  arguments={"access_level": "contributor", "systems": []}, depends_on=["t6"]),
            _task(index=8, agent="it", tool="it.setup_equipment",
                  description="Reserve the standard laptop image and equipment kit",
                  arguments={"full_name": name, "location": entities.get("location")}, depends_on=["t2"]),
            _task(index=9, agent="hr", tool="hr.update_onboarding_status",
                  description=f"Advance the onboarding tracker for {name} to accounts_ready",
                  arguments={"stage": "accounts_ready"}, depends_on=["t3", "t4", "t7", "t8"]),
            _task(index=10, agent="hr", tool="email.send_notification",
                  description=f"Notify {name} and the {department} manager that onboarding is complete",
                  arguments={"recipient": entities.get("email") or "new-hire@nexus-ai.example",
                             "subject": f"Onboarding ready - {name}",
                             "body": f"Your onboarding workflow for the {job_title} position has completed. "
                                     "Your offer letter, onboarding pack and accounts are ready."},
                  depends_on=["t9"]),
        ]

    if category == "invoice_processing":
        invoice_args = {
            "invoice_number": invoice_number,
            "vendor_name": entities.get("vendor_name"),
            "amount": entities.get("amount"),
            "currency": entities.get("currency", "EUR"),
            "raw_text": objective,
        }
        return [
            _task(index=1, agent="finance", tool="finance.extract_invoice_data",
                  description=f"Extract the invoice fields from {invoice_number}",
                  arguments=invoice_args),
            _task(index=2, agent="finance", tool="finance.validate_invoice",
                  description=f"Validate {invoice_number} against vendor master and policy limits",
                  arguments=invoice_args, depends_on=["t1"]),
            _task(index=3, agent="finance", tool="finance.detect_duplicate_invoice",
                  description=f"Check {invoice_number} for duplicates in the posted ledger",
                  arguments=invoice_args, depends_on=["t1"]),
            _task(index=4, agent="document", tool="document.generate_invoice_pdf",
                  description=f"Generate the invoice summary document for {invoice_number}",
                  arguments=invoice_args, depends_on=["t2", "t3"]),
            _task(index=5, agent="finance", tool="finance.create_payment_request",
                  description=f"Create the payment request for {invoice_number}",
                  arguments=invoice_args, depends_on=["t2", "t3", "t4"]),
            _task(index=6, agent="finance", tool="email.send_notification",
                  description="Notify the finance controller that the payment request is queued",
                  arguments={"recipient": "finance-controller@nexus-ai.example",
                             "subject": f"Payment request queued for {invoice_number}",
                             "body": "The invoice passed validation and duplicate checks. A sandbox payment "
                                     "request was queued for the scheduled run."},
                  depends_on=["t5"]),
        ]

    support_args = {
        "customer_name": customer_name,
        "order_id": order_id,
        "ticket_id": ticket_id,
        "customer_id": entities.get("customer_id", ""),
    }
    return [
        _task(index=1, agent="support", tool="crm.lookup_customer",
              description=f"Identify the customer account for {customer_name or 'the requester'}",
              arguments={"customer_name": customer_name, "email": entities.get("email")}),
        _task(index=2, agent="support", tool="crm.lookup_order_status",
              description=f"Look up the order status for {order_id or 'the customer'}",
              arguments=support_args, depends_on=["t1"]),
        _task(index=3, agent="support", tool="crm.update_ticket",
              description="Classify the ticket and set its priority",
              arguments={**support_args, "classification": _classification(objective),
                         "priority": _priority(objective)},
              depends_on=["t1"]),
        _task(index=4, agent="support", tool="crm.log_resolution",
              description="Record the suggested resolution against the ticket",
              arguments={**support_args, "resolution": _resolution_draft(objective)},
              depends_on=["t2", "t3"]),
        _task(index=5, agent="support", tool="email.send_notification",
              description="Send the drafted response to the customer",
              arguments={"recipient": entities.get("email") or "customer@nexus-ai.example",
                         "subject": f"Update on your request {ticket_id}",
                         "body": _resolution_draft(objective)},
              depends_on=["t4"]),
    ]


def _classification(text: str) -> str:
    lowered = text.lower()
    if any(word in lowered for word in ("refund", "charge", "billing", "invoice")):
        return "billing"
    if any(word in lowered for word in ("broken", "damaged", "crash", "error", "not working")):
        return "defect"
    if any(word in lowered for word in ("late", "delay", "where", "delivery", "shipment", "tracking")):
        return "delivery_status"
    return "general_enquiry"


def _priority(text: str) -> str:
    lowered = text.lower()
    if any(word in lowered for word in ("urgent", "asap", "critical", "outage")):
        return "high"
    if any(word in lowered for word in ("refund", "damaged", "late", "delay")):
        return "medium"
    return "low"


def _resolution_draft(text: str) -> str:
    kind = _classification(text)
    drafts = {
        "delivery_status": "We located the order in the fulfilment queue and it is progressing through "
                           "the carrier network. An updated delivery window has been attached to the ticket.",
        "billing": "The billing query was reviewed against the invoice ledger. The charge matches an approved "
                   "invoice and the account team has been tagged for a written confirmation.",
        "defect": "The reported defect was reproduced against the current build. A workaround and an engineering "
                  "follow-up have been recorded on the ticket.",
        "general_enquiry": "The enquiry was answered from the product knowledge base and the ticket was moved "
                           "to resolved-pending-confirmation.",
    }
    return drafts[kind]


# ---------------------------------------------------------------------------
# Plan normalisation
# ---------------------------------------------------------------------------


def _fill_arguments(tool: str, arguments: dict[str, Any], entities: dict[str, Any]) -> dict[str, Any]:
    definition = get_tool_definition(tool)
    if definition is None:
        return arguments
    merged = dict(arguments or {})
    schema = definition.input_schema or {}
    for key in schema.get("required", []):
        if not merged.get(key):
            if key in entities and entities[key] not in (None, ""):
                merged[key] = entities[key]
            elif key == "recipient":
                merged[key] = entities.get("email") or "requester@nexus-ai.example"
            elif key in ("full_name",):
                merged[key] = entities.get("full_name") or "New Employee"
            elif key in ("amount",):
                merged[key] = entities.get("amount", 0)
            elif key in ("classification",):
                merged[key] = _classification(json.dumps(entities, default=str))
            elif key in ("resolution",):
                merged[key] = _resolution_draft(json.dumps(entities, default=str))
            elif key in ("stage",):
                merged[key] = "accounts_ready"
            elif key in ("access_level",):
                merged[key] = "contributor"
            elif key in ("invoice_number",):
                merged[key] = entities.get("invoice_number") or "INV-88215"
            elif key in ("ticket_id",):
                merged[key] = entities.get("ticket_id") or "TCK-44102"
            elif key in ("title", "storage_path"):
                merged[key] = f"{tool} for {entities.get('full_name') or entities.get('invoice_number') or 'workflow'}"
    for key, value in entities.items():
        if key in (definition.input_schema.get("properties") or {}) and not merged.get(key):
            merged[key] = value
    return merged


def normalize_tasks(tasks: list[dict[str, Any]], entities: dict[str, Any]) -> list[dict[str, Any]]:
    """Validate an LLM-produced plan: drop unknown tools, recompute approvals, renumber ids."""
    normalized: list[dict[str, Any]] = []
    id_map: dict[str, str] = {}
    for raw in tasks:
        agent = str(raw.get("agent") or raw.get("agent_name") or "").lower().strip()
        tool = str(raw.get("tool") or raw.get("tool_name") or "").strip()
        definition = get_tool_definition(tool)
        if definition is None:
            continue
        if agent not in VALID_AGENTS:
            agent = definition.agent_scope[0] if definition.agent_scope else "hr"
        old_id = str(raw.get("task_id") or raw.get("id") or f"t{len(normalized) + 1}")
        new_id = f"t{len(normalized) + 1}"
        id_map[old_id] = new_id
        arguments = _fill_arguments(tool, dict(raw.get("arguments") or {}), entities)
        normalized.append(
            {
                "task_id": new_id,
                "description": str(raw.get("description") or raw.get("title") or definition.display_name),
                "agent": agent,
                "tool": tool,
                "arguments": arguments,
                "depends_on": [],
                "requires_approval": bool(definition.requires_approval or definition.risk_level in HIGH_RISK_LEVELS),
                "risk_level": definition.risk_level,
                "reversible": definition.reversible,
                "retry_safe": definition.retry_safe,
                "side_effect": definition.side_effect,
            }
        )
    for task in normalized:
        task["depends_on"] = sorted(
            {id_map[dep] for dep in (task.get("depends_on") or []) if dep in id_map}
            - {task["task_id"]}
        )
    return _drop_cycles(normalized)


def _drop_cycles(tasks: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by_id = {task["task_id"]: task for task in tasks}
    ordered: list[dict[str, Any]] = []
    resolved: set[str] = set()
    pending = list(tasks)
    while pending:
        ready = [task for task in pending if all(dep in resolved for dep in task["depends_on"] if dep in by_id)]
        for task in ready:
            ordered.append(task)
            resolved.add(task["task_id"])
            pending.remove(task)
        if not ready:
            # Dependency cycle from a model-authored plan: strip the unresolvable
            # edges instead of deadlocking the workflow.
            for task in pending:
                task["depends_on"] = [dep for dep in task["depends_on"] if dep not in by_id]
            ordered.extend(pending)
            break
    return ordered


def topological_order(tasks: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by_id = {task["task_id"]: task for task in tasks}
    ordered: list[dict[str, Any]] = []
    resolved: set[str] = set()
    remaining = list(tasks)
    while remaining:
        ready = [task for task in remaining if all(dep in resolved for dep in task.get("depends_on", []))]
        if not ready:
            ordered.extend(remaining)
            break
        for task in ready:
            ordered.append(task)
            resolved.add(task["task_id"])
            remaining.remove(task)
    return ordered


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

PLANNER_SYSTEM = (
    "You are the Planner Agent inside NEXUS AI, an enterprise workflow orchestrator. "
    "You decompose a business request into tasks for specialised agents. "
    "You may only use the agents and tools you are given. Reply with JSON only."
)


def _planner_prompt(request_text: str, category_hint: str | None, entities: dict[str, Any]) -> str:
    tool_catalog = [
        {
            "tool": tool.name,
            "agents": tool.agent_scope,
            "required": tool.input_schema.get("required", []),
            "risk": tool.risk_level,
        }
        for tool in TOOL_DEFINITIONS
    ]
    return f"""Business request:
\"\"\"{request_text}\"\"\"

Pre-extracted entities (may be incomplete): {json.dumps(entities, default=str)}
Requested workflow category: {category_hint or 'auto-detect'}

Allowed agents: {sorted(VALID_AGENTS)}
Allowed tools: {json.dumps(tool_catalog)}

Return JSON with exactly this shape:
{{
  "category": "employee_onboarding | invoice_processing | customer_request",
  "objective": "one sentence restating the goal",
  "entities": {{...merged entities, only keys you are confident about...}},
  "rationale": "why this plan",
  "tasks": [
    {{"task_id": "t1", "description": "...", "agent": "hr", "tool": "hr.validate_employee_details",
      "arguments": {{...}}, "depends_on": []}}
  ]
}}

Rules:
- Every task must reference one allowed tool and one allowed agent.
- Order tasks so dependencies come first.
- Do NOT invent employee, customer or financial identifiers that are not in the request.
- Keep plans between 4 and 12 tasks."""


async def build_plan(request_text: str, category_hint: str | None = None) -> Plan:
    entities = extract_entities(request_text)
    category = category_hint if category_hint in CATEGORIES else classify(request_text, entities)
    objective = request_text.strip()

    provider = llm_client.provider
    if provider != "none":
        try:
            result = await llm_client.complete(
                _planner_prompt(request_text, category_hint, entities),
                system=PLANNER_SYSTEM,
                json_mode=True,
            )
            data = result.data or {}
            raw_tasks = data.get("tasks") or []
            merged_entities = {**entities, **{k: v for k, v in (data.get("entities") or {}).items() if v}}
            llm_category = data.get("category")
            chosen_category = llm_category if llm_category in CATEGORIES else category
            tasks = normalize_tasks(raw_tasks, merged_entities)
            if len(tasks) >= 3:
                return Plan(
                    category=chosen_category,
                    category_label=CATEGORIES[chosen_category],
                    objective=str(data.get("objective") or objective),
                    entities=merged_entities,
                    tasks=topological_order(tasks),
                    rationale=str(data.get("rationale") or "Plan produced by the configured LLM planner."),
                    source="llm",
                    provider=result.provider,
                    model=result.model,
                )
        except (LLMError, ValueError, KeyError, TypeError):
            pass  # fall through to the deterministic planner

    tasks = topological_order(template_plan(category, entities, objective))
    return Plan(
        category=category,
        category_label=CATEGORIES[category],
        objective=objective,
        entities=entities,
        tasks=tasks,
        rationale=(
            "Deterministic planner produced this plan from the "
            f"{CATEGORIES[category]} template"
            + ("" if provider == "none" else f" because the {provider} planner was unavailable")
            + ". Approval checkpoints follow the tool registry policy."
        ),
        source="rule_engine",
        provider="none" if provider == "none" else provider,
        model="nexus-rule-engine",
    )
