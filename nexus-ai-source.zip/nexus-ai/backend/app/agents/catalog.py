"""Catalog of the specialised agents that make up the NEXUS AI workforce.

Each entry declares what the agent does and which tools it may touch. The
orchestrator enforces the tool scope, so an agent only ever receives the
permissions required for its assigned task.
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class AgentSpec:
    name: str
    display_name: str
    description: str
    capabilities: list[str] = field(default_factory=list)
    allowed_tools: list[str] = field(default_factory=list)
    icon: str = "bot"
    color: str = ""


AGENTS: list[AgentSpec] = [
    AgentSpec(
        name="planner",
        display_name="Planner Agent",
        description="Understands the business request, classifies the workflow and produces a "
        "dependency-aware execution plan assigning tasks to specialised agents.",
        capabilities=[
            "Request understanding",
            "Workflow classification",
            "Entity extraction",
            "Task decomposition",
            "Agent assignment",
        ],
        allowed_tools=[],
        icon="brain",
        color="amber",
    ),
    AgentSpec(
        name="hr",
        display_name="HR Agent",
        description="Creates and validates employee records and tracks onboarding progress.",
        capabilities=["Employee records", "Validation", "Onboarding tracking", "Department assignment"],
        allowed_tools=[
            "hr.validate_employee_details",
            "hr.create_employee_record",
            "hr.assign_department",
            "hr.update_onboarding_status",
        ],
        icon="users",
        color="rose",
    ),
    AgentSpec(
        name="document",
        display_name="Document Agent",
        description="Generates enterprise documents from templates and stores references.",
        capabilities=["Document generation", "Templates", "File storage"],
        allowed_tools=[
            "document.list_templates",
            "document.generate_offer_letter",
            "document.generate_onboarding_pack",
            "document.generate_invoice_pdf",
            "document.store_reference",
        ],
        icon="file-text",
        color="emerald",
    ),
    AgentSpec(
        name="it",
        display_name="IT Agent",
        description="Provisions accounts, identities and equipment for new employees.",
        capabilities=["Account provisioning", "Access requests", "System setup"],
        allowed_tools=[
            "it.create_email_account",
            "it.provision_sso_identity",
            "it.grant_system_access",
            "it.setup_equipment",
        ],
        icon="monitor",
        color="orange",
    ),
    AgentSpec(
        name="finance",
        display_name="Finance / Invoice Agent",
        description="Extracts, validates and de-duplicates invoices and prepares payment requests.",
        capabilities=["Invoice processing", "Validation", "Payment requests", "Duplicate detection"],
        allowed_tools=[
            "finance.extract_invoice_data",
            "finance.validate_invoice",
            "finance.detect_duplicate_invoice",
            "finance.create_payment_request",
        ],
        icon="database",
        color="violet",
    ),
    AgentSpec(
        name="support",
        display_name="Customer Support Agent",
        description="Classifies customer queries, looks up orders and drafts resolutions.",
        capabilities=["Query classification", "Order status", "Resolution suggestions"],
        allowed_tools=[
            "crm.lookup_customer",
            "crm.lookup_order_status",
            "crm.update_ticket",
            "crm.log_resolution",
            "document.generate_onboarding_pack",
        ],
        icon="headphones",
        color="teal",
    ),
    AgentSpec(
        name="approval",
        display_name="Approval Agent",
        description="Detects sensitive operations, applies approval policy and pauses or resumes "
        "workflows around human checkpoints.",
        capabilities=["Policy checks", "Approval requests", "Pause/resume workflow"],
        allowed_tools=[],
        icon="shield-check",
        color="blue",
    ),
    AgentSpec(
        name="execution",
        display_name="Execution Agent",
        description="Executes approved tasks through registered tools, verifies results and "
        "reports execution status back into workflow state.",
        capabilities=["Authorised execution", "Result verification", "Error capture"],
        allowed_tools=["*"],
        icon="settings",
        color="blue",
    ),
    AgentSpec(
        name="audit",
        display_name="Audit Agent",
        description="Records agent activity, decisions, tool calls, approvals, failures and "
        "recovery attempts into the append-only audit trail.",
        capabilities=["Record actions", "Log decisions", "Maintain history"],
        allowed_tools=[],
        icon="clipboard-list",
        color="teal",
    ),
]

AGENT_INDEX: dict[str, AgentSpec] = {agent.name: agent for agent in AGENTS}

# Agents that carry out workflow work (planner/approval/audit are coordinators).
WORKER_AGENTS = ["hr", "document", "it", "finance", "support"]


def agent_display_name(name: str) -> str:
    spec = AGENT_INDEX.get(name)
    return spec.display_name if spec else name.replace("_", " ").title()
