"""Provider-agnostic LLM access.

Supports Gemini, OpenAI and Ollama. Keys come from the environment only; when
no provider is configured (or a call fails) callers fall back to the
deterministic planner so the platform stays functional offline.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any

import httpx

from ..config import settings


class LLMError(RuntimeError):
    pass


@dataclass
class LLMResult:
    text: str
    provider: str
    model: str
    data: Any | None = None


_JSON_BLOCK = re.compile(r"```(?:json)?\s*(.*?)```", re.DOTALL)


def extract_json(text: str) -> Any | None:
    """Best-effort JSON recovery from a model response."""
    if not text:
        return None
    candidate = text.strip()
    fenced = _JSON_BLOCK.search(candidate)
    if fenced:
        candidate = fenced.group(1).strip()
    try:
        return json.loads(candidate)
    except json.JSONDecodeError:
        pass
    start = candidate.find("{")
    end = candidate.rfind("}")
    if start != -1 and end > start:
        try:
            return json.loads(candidate[start : end + 1])
        except json.JSONDecodeError:
            return None
    return None


class LLMClient:
    def __init__(self, settings_obj=None):
        self.settings = settings_obj or settings

    @property
    def provider(self) -> str:
        return self.settings.resolved_llm_provider()

    def available_providers(self) -> list[dict[str, Any]]:
        s = self.settings
        return [
            {
                "name": "gemini",
                "label": "Google Gemini",
                "model": s.gemini_model,
                "configured": bool(s.gemini_api_key),
                "key_env": "GEMINI_API_KEY",
            },
            {
                "name": "openai",
                "label": "OpenAI",
                "model": s.openai_model,
                "configured": bool(s.openai_api_key),
                "key_env": "OPENAI_API_KEY",
            },
            {
                "name": "ollama",
                "label": "Ollama (local)",
                "model": s.ollama_model,
                "configured": bool(s.ollama_base_url),
                "key_env": "OLLAMA_BASE_URL",
            },
            {
                "name": "none",
                "label": "Deterministic planner",
                "model": "nexus-rule-engine",
                "configured": True,
                "key_env": "",
            },
        ]

    async def complete(self, prompt: str, *, system: str = "", json_mode: bool = False) -> LLMResult:
        provider = self.provider
        try:
            if provider == "gemini":
                text, model = await self._gemini(prompt, system)
            elif provider == "openai":
                text, model = await self._openai(prompt, system, json_mode)
            elif provider == "ollama":
                text, model = await self._ollama(prompt, system, json_mode)
            else:
                raise LLMError("No LLM provider is configured")
        except httpx.HTTPError as exc:
            # A provider that is configured but unreachable must degrade to the
            # deterministic planner rather than failing the workflow.
            raise LLMError(f"{provider} is unreachable: {exc}") from exc
        return LLMResult(
            text=text,
            provider=provider,
            model=model,
            data=extract_json(text) if json_mode else None,
        )

    # -- Gemini -------------------------------------------------------------

    async def _gemini(self, prompt: str, system: str) -> tuple[str, str]:
        model = self.settings.gemini_model
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
        body: dict[str, Any] = {
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {"temperature": 0.2},
        }
        if system:
            body["systemInstruction"] = {"parts": [{"text": system}]}
        async with httpx.AsyncClient(timeout=self.settings.llm_timeout_seconds) as client:
            response = await client.post(
                url, params={"key": self.settings.gemini_api_key}, json=body
            )
        if response.status_code >= 400:
            raise LLMError(f"Gemini error {response.status_code}: {response.text[:300]}")
        payload = response.json()
        try:
            parts = payload["candidates"][0]["content"]["parts"]
            return "".join(part.get("text", "") for part in parts), model
        except (KeyError, IndexError) as exc:
            raise LLMError("Unexpected Gemini response shape") from exc

    # -- OpenAI -------------------------------------------------------------

    async def _openai(self, prompt: str, system: str, json_mode: bool) -> tuple[str, str]:
        model = self.settings.openai_model
        messages = ([{"role": "system", "content": system}] if system else []) + [
            {"role": "user", "content": prompt}
        ]
        body: dict[str, Any] = {"model": model, "messages": messages, "temperature": 0.2}
        if json_mode:
            body["response_format"] = {"type": "json_object"}
        async with httpx.AsyncClient(timeout=self.settings.llm_timeout_seconds) as client:
            response = await client.post(
                f"{self.settings.openai_base_url}/chat/completions",
                headers={"Authorization": f"Bearer {self.settings.openai_api_key}"},
                json=body,
            )
        if response.status_code >= 400:
            raise LLMError(f"OpenAI error {response.status_code}: {response.text[:300]}")
        payload = response.json()
        try:
            return payload["choices"][0]["message"]["content"], model
        except (KeyError, IndexError) as exc:
            raise LLMError("Unexpected OpenAI response shape") from exc

    # -- Ollama -------------------------------------------------------------

    async def _ollama(self, prompt: str, system: str, json_mode: bool) -> tuple[str, str]:
        model = self.settings.ollama_model
        base = self.settings.ollama_base_url or "http://localhost:11434"
        body: dict[str, Any] = {"model": model, "prompt": prompt, "stream": False}
        if system:
            body["system"] = system
        if json_mode:
            body["format"] = "json"
        async with httpx.AsyncClient(timeout=self.settings.llm_timeout_seconds) as client:
            response = await client.post(f"{base.rstrip('/')}/api/generate", json=body)
        if response.status_code >= 400:
            raise LLMError(f"Ollama error {response.status_code}: {response.text[:300]}")
        return response.json().get("response", ""), model

    async def health(self) -> dict[str, Any]:
        provider = self.provider
        if provider == "none":
            return {"provider": provider, "status": "offline_fallback", "detail": "No API key configured"}
        try:
            result = await self.complete("Reply with the single word: ready")
            return {"provider": provider, "status": "online", "detail": result.model}
        except LLMError as exc:
            return {"provider": provider, "status": "error", "detail": str(exc)[:200]}


llm_client = LLMClient()
