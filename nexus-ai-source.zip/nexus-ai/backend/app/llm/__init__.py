"""LLM provider layer."""
