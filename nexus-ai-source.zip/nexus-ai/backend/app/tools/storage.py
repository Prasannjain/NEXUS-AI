"""File storage for documents produced by the Document Agent."""
from __future__ import annotations

import os
import re
import unicodedata
from datetime import datetime, timezone

from ..config import settings


def _slug(value: str) -> str:
    normalized = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode()
    slug = re.sub(r"[^a-z0-9]+", "-", normalized.lower()).strip("-")
    return slug[:60] or "document"


def documents_dir() -> str:
    path = os.path.abspath(os.path.expanduser(settings.generated_documents_dir))
    os.makedirs(path, exist_ok=True)
    return path


def save_document(*, title: str, content: str, doc_type: str, workflow_id: str) -> tuple[str, int]:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    filename = f"{workflow_id}_{doc_type}_{stamp}.md"
    path = os.path.join(documents_dir(), filename)
    header = f"<!-- NEXUS AI generated document | workflow {workflow_id} | {doc_type} -->\n\n"
    body = f"# {title}\n\n{content}\n"
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(header + body)
    return f"generated_documents/{filename}", os.path.getsize(path)


def read_document(relative_path: str) -> str | None:
    base = documents_dir()
    target = os.path.abspath(os.path.join(base, os.path.basename(relative_path)))
    if not target.startswith(base) or not os.path.isfile(target):
        return None
    with open(target, encoding="utf-8") as handle:
        return handle.read()


def slugify_filename(title: str, extension: str = "md") -> str:
    return f"{_slug(title)}.{extension}"
