"""Simulated enterprise API adapters.

Each handler stands in for a real integration call and returns realistic
synthetic payloads. Every result is tagged ``simulated: true`` so the platform
can never present a sandbox action as a production change.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable

from . import mock_data
from .storage import save_document


class ToolExecutionError(RuntimeError):
    """Raised for permanent failures; transient ones use TransientError."""


class TransientError(RuntimeError):
    """Raised for recoverable failures that the retry policy may re-attempt."""


@dataclass
class ToolContext:
    workflow_id: str
    task_id: str
    agent_name: str
    attempt: int = 1
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class ToolOutcome:
    summary: str
    data: dict[str, Any]
    documents: list[dict[str, Any]] = field(default_factory=list)

    def as_result(self) -> dict[str, Any]:
        payload = {"summary": self.summary, "simulated": True, **self.data}
        if self.documents:
            payload["documents"] = self.documents
        return payload


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _email_for(name: str) -> str:
    slug = "".join(ch for ch in name.lower().replace(".", "").replace("-", " ") if ch.isalnum() or ch == " ")
    parts = slug.split()
    return f"{'.'.join(parts) or 'employee'}@nexus-ai.example"


def _employee_code(seed: str) -> str:
    rng = random.Random(seed)
    return f"EMP-{rng.randint(2000, 2999)}"


# ---------------------------------------------------------------------------
# HR
# ---------------------------------------------------------------------------


def hr_validate(args: dict, ctx: ToolContext) -> ToolOutcome:
    name = str(args.get("full_name", "")).strip()
    department = str(args.get("department", "")).strip()
    title = str(args.get("job_title", "")).strip()
    problems: list[str] = []
    if len(name) < 3:
        problems.append("full_name must contain a first and last name")
    if department and department not in mock_data.DEPARTMENTS:
        problems.append(f"department '{department}' is not in the approved department list")
    if not title:
        problems.append("job_title is required")
    warnings = []
    if not args.get("start_date"):
        warnings.append("start_date not supplied; defaulted to the next business day")
    return ToolOutcome(
        summary=(
            "Employee details passed HR validation"
            if not problems
            else f"HR validation raised {len(problems)} issue(s)"
        ),
        data={
            "valid": not problems,
            "issues": problems,
            "warnings": warnings,
            "normalized": {
                "full_name": name.title() if name else name,
                "department": department or "Unassigned",
                "job_title": title,
                "work_email": args.get("email") or _email_for(name),
                "employee_code": args.get("employee_code") or _employee_code(name + department),
                "manager": args.get("manager") or next(
                    (e["full_name"] for e in mock_data.EMPLOYEES if e["department"] == department),
                    "Pending assignment",
                ),
                "start_date": args.get("start_date") or "2026-11-09",
                "location": args.get("location") or mock_data.LOCATIONS[0],
            },
            "validated_at": _now(),
        },
    )


def hr_create_employee_record(args: dict, ctx: ToolContext) -> ToolOutcome:
    name = str(args.get("full_name", "Unknown Employee"))
    code = args.get("employee_code") or _employee_code(name + ctx.workflow_id)
    return ToolOutcome(
        summary=f"Synthetic employee record {code} created in the sandbox HR system",
        data={
            "employee_code": code,
            "full_name": name,
            "department": args.get("department", "Unassigned"),
            "job_title": args.get("job_title", ""),
            "work_email": args.get("email") or _email_for(name),
            "manager": args.get("manager", ""),
            "start_date": args.get("start_date", "2026-11-09"),
            "location": args.get("location", mock_data.LOCATIONS[0]),
            "record_status": "active_pending_confirmation",
            "system": "HR Management System (sandbox)",
        },
    )


def hr_assign_department(args: dict, ctx: ToolContext) -> ToolOutcome:
    return ToolOutcome(
        summary=f"{args.get('employee_code', 'record')} attached to {args.get('department', 'department')} cost centre",
        data={
            "employee_code": args.get("employee_code", ""),
            "department": args.get("department", ""),
            "manager": args.get("manager", ""),
            "cost_center": f"CC-{abs(hash(args.get('department', ''))) % 900 + 1000}",
            "assignment_effective": _now(),
        },
    )


def hr_update_onboarding_status(args: dict, ctx: ToolContext) -> ToolOutcome:
    stage = str(args.get("stage", "documentation"))
    checklist = ["record_created", "documents_issued", "accounts_provisioned", stage]
    return ToolOutcome(
        summary=f"Onboarding tracker advanced to '{stage}'",
        data={
            "employee_code": args.get("employee_code", ""),
            "stage": stage,
            "checklist": sorted(set(checklist)),
            "completion_percent": min(100, 25 * len(sorted(set(checklist)))),
            "notes": args.get("notes", ""),
        },
    )


# ---------------------------------------------------------------------------
# Documents
# ---------------------------------------------------------------------------


def document_list_templates(args: dict, ctx: ToolContext) -> ToolOutcome:
    doc_type = args.get("doc_type")
    templates = [t for t in mock_data.DOCUMENT_TEMPLATES if not doc_type or t["doc_type"] == doc_type]
    return ToolOutcome(
        summary=f"{len(templates)} template(s) available",
        data={"templates": templates},
    )


def _persist(*, title: str, body: str, doc_type: str, ctx: ToolContext) -> dict[str, Any]:
    path, size = save_document(title=title, content=body, doc_type=doc_type, workflow_id=ctx.workflow_id)
    return {"title": title, "doc_type": doc_type, "storage_path": path, "file_size": size, "content": body}


def document_generate_offer_letter(args: dict, ctx: ToolContext) -> ToolOutcome:
    name = args.get("full_name", "New Colleague")
    title = f"Offer Letter - {name}"
    body = (
        f"Dear {name},\n\n"
        f"We are pleased to confirm your appointment as {args.get('job_title', 'Employee')} within "
        f"{args.get('department', 'the organisation')}, reporting on {args.get('start_date', 'the agreed start date')} "
        f"from {args.get('location', 'the head office')}.\n\n"
        f"Employee code: {args.get('employee_code', 'pending')}\n\n"
        f"{mock_data.EMAIL_SIGNATURE}"
    )
    doc = _persist(title=title, body=body, doc_type="offer_letter", ctx=ctx)
    return ToolOutcome(summary=f"Offer letter generated for {name}", data={"storage_path": doc["storage_path"]}, documents=[doc])


def document_generate_onboarding_pack(args: dict, ctx: ToolContext) -> ToolOutcome:
    name = args.get("full_name", "New Colleague")
    title = f"Onboarding Pack - {name}"
    body = (
        f"# Day One Checklist for {name}\n\n"
        f"- Role: {args.get('job_title', 'Employee')}\n"
        f"- Start date: {args.get('start_date', 'TBC')}\n"
        f"- Employee code: {args.get('employee_code', 'pending')}\n\n"
        "## Included\n"
        "1. Acceptable use and security policy acknowledgement\n"
        "2. Equipment handover form\n"
        "3. Team introduction schedule\n"
        "4. Payroll and benefits registration\n\n"
        f"{mock_data.EMAIL_SIGNATURE}"
    )
    doc = _persist(title=title, body=body, doc_type="onboarding_pack", ctx=ctx)
    return ToolOutcome(summary=f"Onboarding pack generated for {name}", data={"storage_path": doc["storage_path"]}, documents=[doc])


def document_generate_invoice_pdf(args: dict, ctx: ToolContext) -> ToolOutcome:
    invoice_number = args.get("invoice_number", "INV-UNKNOWN")
    title = f"Invoice Summary - {invoice_number}"
    amount = args.get("amount", 0)
    currency = args.get("currency", "EUR")
    body = (
        f"Vendor: {args.get('vendor_name', 'Unknown vendor')}\n"
        f"Invoice: {invoice_number}\n"
        f"Amount: {currency} {amount:,.2f}\n"
        f"Validation: passed policy checks\n\n"
        f"{mock_data.EMAIL_SIGNATURE}"
    )
    doc = _persist(title=title, body=body, doc_type="invoice_summary", ctx=ctx)
    return ToolOutcome(
        summary=f"Invoice summary document generated for {invoice_number}",
        data={"storage_path": doc["storage_path"]},
        documents=[doc],
    )


def document_store_reference(args: dict, ctx: ToolContext) -> ToolOutcome:
    title = args.get("title", "Reference")
    return ToolOutcome(
        summary=f"Reference '{title}' filed against the workflow record",
        data={
            "title": title,
            "storage_path": args.get("storage_path", ""),
            "doc_type": args.get("doc_type", "reference"),
            "filed_at": _now(),
        },
    )


# ---------------------------------------------------------------------------
# IT
# ---------------------------------------------------------------------------


def it_create_email_account(args: dict, ctx: ToolContext) -> ToolOutcome:
    name = args.get("full_name", "New Colleague")
    return ToolOutcome(
        summary=f"Mailbox provisioned in the sandbox directory for {name}",
        data={
            "mailbox": _email_for(name),
            "employee_code": args.get("employee_code", ""),
            "distribution_lists": [f"{str(args.get('department', 'all')).lower().replace(' ', '-')}@nexus-ai.example"],
            "calendar": "primary",
            "provisioned_at": _now(),
        },
    )


def it_provision_sso_identity(args: dict, ctx: ToolContext) -> ToolOutcome:
    name = args.get("full_name", "New Colleague")
    return ToolOutcome(
        summary=f"SSO identity and MFA enrolment created for {name}",
        data={
            "identity_id": f"IDN-{str(args.get('employee_code', 'TEMP')).split('-')[-1]}",
            "principal": _email_for(name),
            "mfa_enrolment": "required_on_first_signin",
            "groups": ["employees", str(args.get("department", "general")).lower().replace(" ", "-")],
            "created_at": _now(),
        },
    )


def it_grant_system_access(args: dict, ctx: ToolContext) -> ToolOutcome:
    systems = args.get("systems") or [entry["system"] for entry in mock_data.SYSTEM_ROLES]
    grants = [
        {"system": system, "access": args.get("access_level", "read")}
        for system in systems
    ]
    return ToolOutcome(
        summary=f"Granted {args.get('access_level', 'read')} access to {len(grants)} sandbox system(s)",
        data={
            "employee_code": args.get("employee_code", ""),
            "grants": grants,
            "review_after_days": 90,
            "granted_at": _now(),
        },
    )


def it_setup_equipment(args: dict, ctx: ToolContext) -> ToolOutcome:
    # Deterministic transient failure on the first attempt demonstrates the
    # exponential-backoff recovery path without breaking the happy path.
    if ctx.attempt < 2:
        raise TransientError("IT provisioning gateway timed out after 5000ms (asset reservation lock)")
    return ToolOutcome(
        summary="Equipment reservation confirmed after gateway recovery",
        data={
            "employee_code": args.get("employee_code", ""),
            "asset_tag": f"AST-{abs(hash(str(args.get('employee_code')))) % 90000 + 10000}",
            "image": "Standard corporate build 2026.10",
            "collection_location": args.get("location", mock_data.LOCATIONS[0]),
            "reserved_at": _now(),
        },
    )


# ---------------------------------------------------------------------------
# Finance
# ---------------------------------------------------------------------------


def _find_invoice(invoice_number: str) -> dict | None:
    for invoice in mock_data.INVOICES:
        if invoice["invoice_number"].lower() == str(invoice_number).lower():
            return invoice
    return None


def finance_extract_invoice_data(args: dict, ctx: ToolContext) -> ToolOutcome:
    invoice_number = args.get("invoice_number", "")
    known = _find_invoice(invoice_number)
    if known:
        data = dict(known)
        source = "invoice ledger"
    else:
        raw = str(args.get("raw_text", ""))
        vendor = next((v["name"] for v in mock_data.VENDORS if v["name"].lower() in raw.lower()), "Unrecognised vendor")
        amount = 0.0
        for token in raw.replace(",", " ").split():
            try:
                candidate = float(token)
                if candidate > amount:
                    amount = candidate
            except ValueError:
                continue
        data = {
            "invoice_number": invoice_number or "INV-UNREADABLE",
            "vendor_name": vendor,
            "amount": amount,
            "currency": "EUR" if "€" in raw or "eur" in raw.lower() else "USD",
            "invoice_date": "2026-10-15",
            "cost_center": "CC-unclassified",
            "status": "needs_validation",
        }
        source = "document OCR"
    confidence = 0.97 if known else 0.81
    return ToolOutcome(
        summary=f"Extracted invoice fields from {source} ({int(confidence * 100)}% confidence)",
        data={"extracted": data, "confidence": confidence, "source": source},
    )


def finance_validate_invoice(args: dict, ctx: ToolContext) -> ToolOutcome:
    invoice = _find_invoice(args.get("invoice_number", ""))
    amount = float(args.get("amount") or (invoice or {}).get("amount") or 0)
    issues: list[str] = []
    if not invoice and not args.get("vendor_name"):
        issues.append("vendor could not be matched to the vendor master")
    if amount <= 0:
        issues.append("invoice amount must be greater than zero")
    if amount > 50000:
        issues.append("amount exceeds the delegated approval limit of EUR 50,000")
    return ToolOutcome(
        summary="Invoice passed finance validation" if not issues else f"Invoice failed validation: {'; '.join(issues)}",
        data={
            "valid": not issues,
            "issues": issues,
            "invoice_number": args.get("invoice_number", ""),
            "vendor_name": args.get("vendor_name") or (invoice or {}).get("vendor_name", ""),
            "amount": amount,
            "currency": args.get("currency") or (invoice or {}).get("currency", "EUR"),
            "cost_center": (invoice or {}).get("cost_center", "CC-unclassified"),
            "policy_checks": [
                {"check": "vendor_master_match", "passed": bool(invoice or args.get("vendor_name"))},
                {"check": "amount_within_delegation", "passed": amount <= 50000},
                {"check": "cost_centre_present", "passed": bool(invoice)},
            ],
        },
    )


def finance_detect_duplicate_invoice(args: dict, ctx: ToolContext) -> ToolOutcome:
    invoice_number = str(args.get("invoice_number", "")).lower()
    amount = args.get("amount")
    vendor = str(args.get("vendor_name") or "").lower()
    matches = [
        other["invoice_number"]
        for other in mock_data.INVOICES
        if other["invoice_number"].lower() != invoice_number
        and (amount is None or float(other["amount"]) == float(amount))
        and (not vendor or other["vendor_name"].lower() == vendor)
    ]
    duplicate = bool(matches)
    return ToolOutcome(
        summary="Duplicate invoice detected" if duplicate else "No duplicate invoice found in the ledger",
        data={
            "duplicate": duplicate,
            "matching_invoices": matches,
            "comparison": {"amount": amount, "vendor_name": args.get("vendor_name", "")},
            "ledger_scanned": len(mock_data.INVOICES),
        },
    )


def finance_create_payment_request(args: dict, ctx: ToolContext) -> ToolOutcome:
    invoice = _find_invoice(args.get("invoice_number", "")) or {}
    amount = float(args.get("amount") or invoice.get("amount") or 0)
    return ToolOutcome(
        summary=f"Payment request queued in the sandbox finance system for {amount:,.2f} "
        f"{invoice.get('currency', 'EUR')}",
        data={
            "payment_request_id": f"PAY-{str(args.get('invoice_number', 'X')).replace('INV-', '')}",
            "invoice_number": args.get("invoice_number", ""),
            "vendor_name": args.get("vendor_name") or invoice.get("vendor_name", ""),
            "amount": amount,
            "currency": args.get("currency") or invoice.get("currency", "EUR"),
            "payment_terms": invoice.get("payment_terms", "NET-30"),
            "status": "queued_for_scheduled_run",
            "scheduled_run": "2026-11-03T02:00:00+00:00",
            "idempotency_key": ctx.extra.get("idempotency_key", ""),
            "note": "Sandbox request only - no funds were moved.",
        },
    )


# ---------------------------------------------------------------------------
# CRM / support
# ---------------------------------------------------------------------------


def crm_lookup_customer(args: dict, ctx: ToolContext) -> ToolOutcome:
    needle = str(
        args.get("customer_name") or args.get("customer_id") or args.get("email") or ""
    ).strip().lower()
    for customer in mock_data.CUSTOMERS:
        if (
            not needle
            or needle in customer["name"].lower()
            or needle == customer["customer_id"].lower()
            or needle in customer["email"].lower()
        ):
            return ToolOutcome(
                summary=f"Matched customer account {customer['customer_id']}",
                data={"customer": customer, "orders": [o for o in mock_data.ORDERS if o["customer_id"] == customer["customer_id"]]},
            )
    raise ToolExecutionError(f"No CRM customer matched '{needle or 'unspecified'}'")


def crm_lookup_order_status(args: dict, ctx: ToolContext) -> ToolOutcome:
    order_id = str(args.get("order_id") or "").lower()
    customer_id = str(args.get("customer_id") or "").lower()
    for order in mock_data.ORDERS:
        if (order_id and order["order_id"].lower() == order_id) or (
            not order_id and customer_id and order["customer_id"].lower() == customer_id
        ):
            return ToolOutcome(
                summary=f"Order {order['order_id']} is {order['status']}",
                data={"order": order, "next_update": "2026-11-02T09:00:00+00:00"},
            )
    raise ToolExecutionError("No matching order found in the CRM sandbox")


def crm_update_ticket(args: dict, ctx: ToolContext) -> ToolOutcome:
    return ToolOutcome(
        summary=f"Ticket {args.get('ticket_id', 'TCK-UNKNOWN')} classified as {args.get('classification', 'general')}",
        data={
            "ticket_id": args.get("ticket_id", ""),
            "classification": args.get("classification", "general_enquiry"),
            "priority": args.get("priority", "medium"),
            "customer_id": args.get("customer_id", ""),
            "updated_at": _now(),
        },
    )


def crm_log_resolution(args: dict, ctx: ToolContext) -> ToolOutcome:
    resolution = str(args.get("resolution", ""))
    ticket_id = args.get("ticket_id", "TCK-UNKNOWN")
    title = f"Resolution Note - {ticket_id}"
    body = (
        f"Ticket: {ticket_id}\nCustomer: {args.get('customer_id', 'unknown')}\n\n"
        f"{resolution}\n\n{mock_data.EMAIL_SIGNATURE}"
    )
    doc = _persist(title=title, body=body, doc_type="resolution_note", ctx=ctx)
    return ToolOutcome(
        summary=f"Resolution recorded against {ticket_id}",
        data={"ticket_id": ticket_id, "logged_at": _now(), "storage_path": doc["storage_path"]},
        documents=[doc],
    )


# ---------------------------------------------------------------------------
# Notifications
# ---------------------------------------------------------------------------


def email_send_notification(args: dict, ctx: ToolContext) -> ToolOutcome:
    recipient = args.get("recipient", "")
    if "@" not in str(recipient):
        raise ToolExecutionError("Notification recipient must be an email address")
    return ToolOutcome(
        summary=f"Notification '{args.get('subject', 'Update')}' delivered to {recipient}",
        data={
            "recipient": recipient,
            "subject": args.get("subject", ""),
            "message_id": f"<{ctx.workflow_id}.{ctx.task_id}@nexus-ai.example>",
            "delivered_at": _now(),
            "channel": "sandbox_smtp",
            "note": "Delivered inside the sandbox; no external mailbox was contacted.",
        },
    )


HANDLERS: dict[str, Callable[[dict, ToolContext], ToolOutcome]] = {
    "hr.validate_employee_details": hr_validate,
    "hr.create_employee_record": hr_create_employee_record,
    "hr.assign_department": hr_assign_department,
    "hr.update_onboarding_status": hr_update_onboarding_status,
    "document.list_templates": document_list_templates,
    "document.generate_offer_letter": document_generate_offer_letter,
    "document.generate_onboarding_pack": document_generate_onboarding_pack,
    "document.generate_invoice_pdf": document_generate_invoice_pdf,
    "document.store_reference": document_store_reference,
    "it.create_email_account": it_create_email_account,
    "it.provision_sso_identity": it_provision_sso_identity,
    "it.grant_system_access": it_grant_system_access,
    "it.setup_equipment": it_setup_equipment,
    "finance.extract_invoice_data": finance_extract_invoice_data,
    "finance.validate_invoice": finance_validate_invoice,
    "finance.detect_duplicate_invoice": finance_detect_duplicate_invoice,
    "finance.create_payment_request": finance_create_payment_request,
    "crm.lookup_customer": crm_lookup_customer,
    "crm.lookup_order_status": crm_lookup_order_status,
    "crm.update_ticket": crm_update_ticket,
    "crm.log_resolution": crm_log_resolution,
    "email.send_notification": email_send_notification,
}
