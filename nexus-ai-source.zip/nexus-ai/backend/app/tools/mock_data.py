"""Synthetic enterprise data.

Everything below is fabricated demo data for the sandbox integrations. No real
employee, customer or financial record is stored anywhere in this project.
"""
from __future__ import annotations

DEPARTMENTS = [
    "Engineering",
    "Finance",
    "Human Resources",
    "Sales",
    "Customer Support",
    "Operations",
]

LOCATIONS = ["Bengaluru HQ", "Pune Office", "Remote - India", "Frankfurt Office"]

SYSTEM_ROLES = [
    {"system": "Corporate Laptop Fleet", "access": "Standard build image"},
    {"system": "Confluence", "access": "read"},
    {"system": "Jira", "access": "contributor"},
    {"system": "Source Repository", "access": "read"},
]

EMPLOYEES: list[dict] = [
    {"employee_code": "EMP-1001", "full_name": "Anita Desai", "department": "Human Resources", "title": "HR Manager"},
    {"employee_code": "EMP-1002", "full_name": "Marcus Feld", "department": "Finance", "title": "Financial Controller"},
    {"employee_code": "EMP-1003", "full_name": "Priya Nair", "department": "Engineering", "title": "Engineering Lead"},
]

VENDORS: list[dict] = [
    {"vendor_id": "VND-2001", "name": "Northwind Cloud Services", "payment_terms": "NET-30", "bank": "Sandbox National Bank"},
    {"vendor_id": "VND-2002", "name": "Acme Office Supplies", "payment_terms": "NET-15", "bank": "Sandbox National Bank"},
    {"vendor_id": "VND-2003", "name": "Helios Data Ltd", "payment_terms": "NET-45", "bank": "Continental Test Bank"},
]

# Amounts are deliberately synthetic; the duplicate detector compares these.
INVOICES: list[dict] = [
    {
        "invoice_number": "INV-88213",
        "vendor_id": "VND-2001",
        "vendor_name": "Northwind Cloud Services",
        "amount": 18450.0,
        "currency": "EUR",
        "invoice_date": "2026-09-12",
        "cost_center": "CC-4400 Infrastructure",
        "status": "approved_for_payment",
    },
    {
        "invoice_number": "INV-88214",
        "vendor_id": "VND-2002",
        "vendor_name": "Acme Office Supplies",
        "amount": 1290.5,
        "currency": "EUR",
        "invoice_date": "2026-09-18",
        "cost_center": "CC-1200 Facilities",
        "status": "approved_for_payment",
    },
    {
        "invoice_number": "INV-88215",
        "vendor_id": "VND-2003",
        "vendor_name": "Helios Data Ltd",
        "amount": 7420.0,
        "currency": "EUR",
        "invoice_date": "2026-09-27",
        "cost_center": "CC-3100 Analytics",
        "status": "needs_validation",
    },
]

CUSTOMERS: list[dict] = [
    {
        "customer_id": "CUS-5001",
        "name": "Beacon Retail Group",
        "email": "apaccounts@beacon-retail.example",
        "plan": "Enterprise",
        "region": "EMEA",
        "support_tier": "priority",
    },
    {
        "customer_id": "CUS-5002",
        "name": "Vertex Logistics",
        "email": "helpdesk@vertex-logistics.example",
        "plan": "Professional",
        "region": "APAC",
        "support_tier": "standard",
    },
    {
        "customer_id": "CUS-5003",
        "name": "Lumen Studios",
        "email": "ops@lumen-studios.example",
        "plan": "Starter",
        "region": "AMER",
        "support_tier": "standard",
    },
]

ORDERS: list[dict] = [
    {"order_id": "ORD-77301", "customer_id": "CUS-5001", "status": "delivered", "placed_on": "2026-09-02", "amount": 24000.0},
    {"order_id": "ORD-77302", "customer_id": "CUS-5002", "status": "in_transit", "placed_on": "2026-10-08", "amount": 5400.0},
    {"order_id": "ORD-77303", "customer_id": "CUS-5003", "status": "payment_pending", "placed_on": "2026-10-21", "amount": 890.0},
]

DOCUMENT_TEMPLATES: list[dict] = [
    {"template_id": "TPL-OFFER-01", "name": "Offer Letter", "doc_type": "offer_letter"},
    {"template_id": "TPL-ONBOARD-01", "name": "Onboarding Pack", "doc_type": "onboarding_pack"},
    {"template_id": "TPL-INVOICE-01", "name": "Invoice Summary", "doc_type": "invoice_pdf"},
    {"template_id": "TPL-RESOLUTION-01", "name": "Support Resolution Note", "doc_type": "resolution_note"},
]

EMAIL_SIGNATURE = (
    "NEXUS AI Automation\n"
    "Synthetic sandbox environment - no production system was contacted."
)
