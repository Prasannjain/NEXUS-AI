"""Tool registry: schema validation, authorisation, idempotent execution.

The registry is the only path an agent has to an enterprise system. It refuses
disabled tools, out-of-scope agents, missing permissions and invalid payloads,
and it records one idempotency-guarded row per (workflow, task, tool).
"""
from __future__ import annotations

import time
from dataclasses import asdict
from datetime import datetime, timezone
from typing import Any

from jsonschema import Draft202012Validator
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import settings
from ..models import Integration, Tool, ToolCall
from .adapters import HANDLERS, ToolContext, ToolExecutionError, ToolOutcome, TransientError
from .definitions import (
    INTEGRATION_DEFINITIONS,
    TOOL_DEFINITIONS,
    ToolDefinition,
    get_tool_definition,
)

__all__ = [
    "ToolExecutionError",
    "TransientError",
    "ToolOutcome",
    "ToolPermissionDenied",
    "ToolValidationError",
    "registry",
]


class ToolValidationError(RuntimeError):
    pass


class ToolPermissionDenied(RuntimeError):
    pass


class AuthorizationContext:
    """Who is asking, and what they are allowed to touch."""

    def __init__(self, agent_name: str, permissions: set[str] | list[str], allow_wildcard: bool = True):
        self.agent_name = agent_name
        self.permissions = set(permissions or [])

    def grants(self, required: str) -> bool:
        if "*" in self.permissions or "tools.execute_all" in self.permissions:
            return True
        return required in self.permissions


def _schema_validator(schema: dict) -> Draft202012Validator:
    Draft202012Validator.check_schema(schema)
    return Draft202012Validator(schema)


def validate_payload(definition: ToolDefinition, arguments: dict[str, Any]) -> None:
    validator = _schema_validator(definition.input_schema)
    errors = sorted(validator.iter_errors(arguments), key=lambda error: list(error.path))
    if errors:
        detail = "; ".join(f"{'.'.join(map(str, error.path)) or error.message}" for error in errors[:3])
        raise ToolValidationError(f"Input schema rejected the payload: {detail}")


def sync_catalog(db: Session) -> dict[str, int]:
    """Insert or refresh integrations and tools from the declarative catalog."""
    now = datetime.now(timezone.utc)
    existing_integrations = {row.key: row for row in db.scalars(select(Integration))}
    for spec in INTEGRATION_DEFINITIONS:
        row = existing_integrations.get(spec["key"])
        if row is None:
            db.add(Integration(**spec))
        else:
            for key, value in spec.items():
                setattr(row, key, value)
    db.flush()

    integrations = {row.key: row for row in db.scalars(select(Integration))}
    existing_tools = {row.name: row for row in db.scalars(select(Tool))}
    for definition in TOOL_DEFINITIONS:
        payload = asdict(definition)
        integration_key = payload.pop("integration")
        payload["integration_id"] = integrations[integration_key].id if integration_key in integrations else None
        row = existing_tools.get(definition.name)
        if row is None:
            db.add(Tool(**payload))
        else:
            # Operator edits to `enabled` survive a re-sync; everything else follows code.
            for key, value in payload.items():
                if key != "enabled":
                    setattr(row, key, value)
    db.commit()
    return {"integrations": len(integrations), "tools": len(TOOL_DEFINITIONS)}


class ToolRegistry:
    def definition(self, name: str) -> ToolDefinition:
        definition = get_tool_definition(name)
        if definition is None:
            raise ToolExecutionError(f"Tool '{name}' is not registered")
        return definition

    def row(self, db: Session, name: str) -> Tool | None:
        return db.scalar(select(Tool).where(Tool.name == name))

    def is_enabled(self, db: Session, name: str) -> bool:
        row = self.row(db, name)
        return bool(row and row.enabled)

    def authorize(self, db: Session, name: str, auth: AuthorizationContext) -> Tool:
        definition = self.definition(name)
        row = self.row(db, name)
        if row is None:
            raise ToolExecutionError(f"Tool '{name}' is not registered")
        if not row.enabled:
            raise ToolPermissionDenied(f"Tool '{name}' is disabled in the registry")
        if definition.agent_scope and auth.agent_name not in definition.agent_scope:
            raise ToolPermissionDenied(
                f"Agent '{auth.agent_name}' is not authorised for tool '{name}' "
                f"(scope: {', '.join(definition.agent_scope)})"
            )
        if not auth.grants(definition.required_permission):
            raise ToolPermissionDenied(
                f"Missing permission '{definition.required_permission}' for tool '{name}'"
            )
        return row

    def idempotency_key(self, workflow_id: str, task_id: str, name: str) -> str:
        return f"{workflow_id}:{task_id}:{name}"

    def execute(
        self,
        db: Session,
        *,
        name: str,
        arguments: dict[str, Any],
        auth: AuthorizationContext,
        workflow_id: str,
        task_id: str,
        attempt: int = 1,
    ) -> ToolOutcome:
        definition = self.definition(name)
        tool_row = self.authorize(db, name, auth)
        validate_payload(definition, arguments)

        key = self.idempotency_key(workflow_id, task_id, name)
        prior = db.scalar(select(ToolCall).where(ToolCall.idempotency_key == key))
        if prior and prior.status == "completed" and prior.result:
            # A replayed task must never fire a second side effect.
            return ToolOutcome(
                summary=str(prior.result.get("summary", "Reused previous tool result")),
                data={**{k: v for k, v in prior.result.items() if k != "summary"}, "replayed": True},
            )

        handler = HANDLERS.get(name)
        if handler is None:
            raise ToolExecutionError(f"No adapter implemented for tool '{name}'")

        context = ToolContext(
            workflow_id=workflow_id,
            task_id=task_id,
            agent_name=auth.agent_name,
            attempt=attempt,
            extra={"idempotency_key": key, "tool": tool_row},
        )
        started = time.perf_counter()
        try:
            outcome = handler(dict(arguments), context)
        except (ToolExecutionError, TransientError) as error:
            self._record(
                db,
                prior=prior,
                key=key,
                workflow_id=workflow_id,
                task_id=task_id,
                name=name,
                agent=auth.agent_name,
                arguments=arguments,
                result={"error": str(error)},
                status="failed",
                duration_ms=(time.perf_counter() - started) * 1000,
            )
            raise
        duration_ms = (time.perf_counter() - started) * 1000

        result = outcome.as_result()
        self._record(
            db,
            prior=prior,
            key=key,
            workflow_id=workflow_id,
            task_id=task_id,
            name=name,
            agent=auth.agent_name,
            arguments=arguments,
            result=result,
            status="completed",
            duration_ms=duration_ms,
        )
        tool_row.last_used_at = datetime.now(timezone.utc)
        integration = tool_row.integration
        if integration is not None:
            integration.last_activity_at = datetime.now(timezone.utc)
        db.commit()
        outcome.data["duration_ms"] = round(duration_ms, 2)
        return outcome

    def _record(
        self,
        db: Session,
        *,
        prior: ToolCall | None,
        key: str,
        workflow_id: str,
        task_id: str,
        name: str,
        agent: str,
        arguments: dict,
        result: dict,
        status: str,
        duration_ms: float,
    ) -> None:
        row = prior or db.scalar(select(ToolCall).where(ToolCall.idempotency_key == key))
        if row is None:
            row = ToolCall(
                idempotency_key=key,
                workflow_id=workflow_id,
                task_id=task_id,
                tool_name=name,
                agent_name=agent,
            )
            db.add(row)
        row.arguments = arguments
        row.result = result
        row.status = status
        row.duration_ms = round(duration_ms, 2)
        db.commit()

    def preview_connection(self, name: str) -> dict[str, Any]:
        definition = self.definition(name)
        return {
            "tool": definition.name,
            "integration": definition.integration,
            "simulated": True,
            "status": "online" if settings.environment != "production" else "online",
        }


registry = ToolRegistry()
