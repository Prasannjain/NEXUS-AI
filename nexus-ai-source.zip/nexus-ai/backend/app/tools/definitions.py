"""Declarative definitions of the sandbox integrations and their tools.

`side_effect` drives approval policy: `read` tools never need approval,
`write` tools may, and `financial` tools always do. `retry_safe=False` blocks
automatic retries so a payment can never be issued twice.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

INTEGRATION_DEFINITIONS: list[dict[str, Any]] = [
    {
        "key": "hr_system",
        "name": "HR Management System",
        "description": "Employee master data, department assignment and onboarding tracking.",
        "system_type": "human_resources",
        "base_url": "https://hr.sandbox.nexus-ai.example/api/v1",
        "required_permissions": ["hr.read", "hr.write"],
        "available_operations": [
            "validate_employee_details",
            "create_employee_record",
            "assign_department",
            "update_onboarding_status",
        ],
    },
    {
        "key": "finance_system",
        "name": "Finance / Accounting System",
        "description": "Invoice ledger, vendor master and payment requests.",
        "system_type": "finance",
        "base_url": "https://finance.sandbox.nexus-ai.example/api/v2",
        "required_permissions": ["finance.read", "finance.payment.write"],
        "available_operations": [
            "extract_invoice_data",
            "validate_invoice",
            "detect_duplicate_invoice",
            "create_payment_request",
        ],
    },
    {
        "key": "crm_system",
        "name": "CRM System",
        "description": "Customer accounts, orders and support tickets.",
        "system_type": "crm",
        "base_url": "https://crm.sandbox.nexus-ai.example/api/v1",
        "required_permissions": ["crm.read", "crm.write"],
        "available_operations": [
            "lookup_customer",
            "lookup_order_status",
            "update_ticket",
            "log_resolution",
        ],
    },
    {
        "key": "it_provisioning",
        "name": "IT Provisioning",
        "description": "Directory accounts, SSO identity, application access and equipment.",
        "system_type": "it",
        "base_url": "https://itprovision.sandbox.nexus-ai.example/api/v1",
        "required_permissions": ["it.read", "it.account.write", "it.identity.write"],
        "available_operations": [
            "create_email_account",
            "provision_sso_identity",
            "grant_system_access",
            "setup_equipment",
        ],
    },
    {
        "key": "document_storage",
        "name": "Document Storage",
        "description": "Template library and generated document repository.",
        "system_type": "documents",
        "base_url": "https://docs.sandbox.nexus-ai.example/api/v1",
        "required_permissions": ["document.read", "document.write"],
        "available_operations": [
            "list_templates",
            "generate_offer_letter",
            "generate_onboarding_pack",
            "generate_invoice_pdf",
            "store_reference",
        ],
    },
    {
        "key": "email_notifications",
        "name": "Email / Notification Service",
        "description": "Outbound notifications to requesters, approvers and administrators.",
        "system_type": "notifications",
        "base_url": "https://smtp.sandbox.nexus-ai.example:587",
        "required_permissions": ["notifications.send"],
        "available_operations": ["send_notification"],
    },
]


@dataclass
class ToolDefinition:
    name: str
    display_name: str
    description: str
    integration: str
    agent_scope: list[str]
    required_permission: str
    input_schema: dict[str, Any]
    side_effect: str = "read"
    risk_level: str = "low"
    requires_approval: bool = False
    retry_safe: bool = True
    reversible: bool = True
    produces_documents: bool = False


def _obj(required: list[str], properties: dict[str, Any]) -> dict[str, Any]:
    return {"type": "object", "required": required, "properties": properties, "additionalProperties": True}


STR = {"type": "string"}
NUM = {"type": "number"}


TOOL_DEFINITIONS: list[ToolDefinition] = [
    # -- HR -------------------------------------------------------------------
    ToolDefinition(
        name="hr.validate_employee_details",
        display_name="Validate employee details",
        description="Checks name, department and job title against HR reference data.",
        integration="hr_system",
        agent_scope=["hr", "planner"],
        required_permission="hr.read",
        input_schema=_obj(["full_name", "department", "job_title"],
                          {"full_name": STR, "department": STR, "job_title": STR, "email": STR}),
    ),
    ToolDefinition(
        name="hr.create_employee_record",
        display_name="Create employee record",
        description="Writes a new employee master record in the HR system.",
        integration="hr_system",
        agent_scope=["hr"],
        required_permission="hr.write",
        input_schema=_obj(["full_name", "department", "job_title"],
                          {"full_name": STR, "department": STR, "job_title": STR,
                           "email": STR, "manager": STR, "start_date": STR, "location": STR}),
        side_effect="write",
        risk_level="high",
        requires_approval=True,
    ),
    ToolDefinition(
        name="hr.assign_department",
        display_name="Assign department",
        description="Attaches an employee record to a cost centre and manager.",
        integration="hr_system",
        agent_scope=["hr"],
        required_permission="hr.write",
        input_schema=_obj(["employee_code", "department"], {"employee_code": STR, "department": STR, "manager": STR}),
        side_effect="write",
    ),
    ToolDefinition(
        name="hr.update_onboarding_status",
        display_name="Update onboarding tracker",
        description="Moves the onboarding checklist forward.",
        integration="hr_system",
        agent_scope=["hr"],
        required_permission="hr.write",
        input_schema=_obj(["employee_code", "stage"], {"employee_code": STR, "stage": STR, "notes": STR}),
        side_effect="write",
    ),
    # -- Documents -------------------------------------------------------------
    ToolDefinition(
        name="document.list_templates",
        display_name="List document templates",
        description="Returns the available template library.",
        integration="document_storage",
        agent_scope=["document", "hr", "finance", "support"],
        required_permission="document.read",
        input_schema=_obj([], {"doc_type": STR}),
    ),
    ToolDefinition(
        name="document.generate_offer_letter",
        display_name="Generate offer letter",
        description="Renders the offer letter template for a new hire.",
        integration="document_storage",
        agent_scope=["document"],
        required_permission="document.write",
        input_schema=_obj(["full_name", "job_title", "department"],
                          {"full_name": STR, "job_title": STR, "department": STR,
                           "employee_code": STR, "start_date": STR, "location": STR}),
        side_effect="write",
        produces_documents=True,
    ),
    ToolDefinition(
        name="document.generate_onboarding_pack",
        display_name="Generate onboarding pack",
        description="Builds the day-one pack: policy, security and equipment notes.",
        integration="document_storage",
        agent_scope=["document", "support"],
        required_permission="document.write",
        input_schema=_obj(["full_name"], {"full_name": STR, "employee_code": STR, "job_title": STR, "start_date": STR}),
        side_effect="write",
        produces_documents=True,
    ),
    ToolDefinition(
        name="document.generate_invoice_pdf",
        display_name="Generate invoice summary",
        description="Renders the validated invoice into the archive-ready summary document.",
        integration="document_storage",
        agent_scope=["document", "finance"],
        required_permission="document.write",
        input_schema=_obj(["invoice_number"], {"invoice_number": STR, "vendor_name": STR, "amount": NUM, "currency": STR}),
        side_effect="write",
        produces_documents=True,
    ),
    ToolDefinition(
        name="document.store_reference",
        display_name="Store document reference",
        description="Registers a generated document reference against the workflow record.",
        integration="document_storage",
        agent_scope=["document"],
        required_permission="document.write",
        input_schema=_obj(["title", "storage_path"], {"title": STR, "storage_path": STR, "doc_type": STR}),
        side_effect="write",
    ),
    # -- IT --------------------------------------------------------------------
    ToolDefinition(
        name="it.create_email_account",
        display_name="Create mailbox account",
        description="Provisions the corporate mailbox and distribution list membership.",
        integration="it_provisioning",
        agent_scope=["it"],
        required_permission="it.account.write",
        input_schema=_obj(["full_name", "employee_code"],
                          {"full_name": STR, "employee_code": STR, "department": STR, "job_title": STR}),
        side_effect="write",
    ),
    ToolDefinition(
        name="it.provision_sso_identity",
        display_name="Provision SSO identity",
        description="Creates the directory identity and MFA enrolment for a new employee.",
        integration="it_provisioning",
        agent_scope=["it"],
        required_permission="it.identity.write",
        input_schema=_obj(["full_name", "employee_code"], {"full_name": STR, "employee_code": STR, "email": STR}),
        side_effect="write",
        risk_level="high",
        requires_approval=True,
    ),
    ToolDefinition(
        name="it.grant_system_access",
        display_name="Grant system access",
        description="Grants role-based access to internal systems.",
        integration="it_provisioning",
        agent_scope=["it"],
        required_permission="it.identity.write",
        input_schema=_obj(["employee_code", "access_level"],
                          {"employee_code": STR, "access_level": STR, "systems": {"type": "array"}, "full_name": STR}),
        side_effect="write",
        risk_level="critical",
        requires_approval=True,
        reversible=False,
    ),
    ToolDefinition(
        name="it.setup_equipment",
        display_name="Prepare equipment",
        description="Reserves a laptop image and peripheral kit.",
        integration="it_provisioning",
        agent_scope=["it"],
        required_permission="it.account.write",
        input_schema=_obj(["employee_code"], {"employee_code": STR, "full_name": STR, "location": STR}),
        side_effect="write",
    ),
    # -- Finance ---------------------------------------------------------------
    ToolDefinition(
        name="finance.extract_invoice_data",
        display_name="Extract invoice data",
        description="Reads vendor, amount and cost centre fields from the invoice ledger.",
        integration="finance_system",
        agent_scope=["finance"],
        required_permission="finance.read",
        input_schema=_obj(["invoice_number"], {"invoice_number": STR, "raw_text": STR}),
    ),
    ToolDefinition(
        name="finance.validate_invoice",
        display_name="Validate invoice",
        description="Checks vendor master, tax fields and policy limits.",
        integration="finance_system",
        agent_scope=["finance"],
        required_permission="finance.read",
        input_schema=_obj(["invoice_number"], {"invoice_number": STR, "amount": NUM, "vendor_name": STR, "currency": STR}),
    ),
    ToolDefinition(
        name="finance.detect_duplicate_invoice",
        display_name="Detect duplicate invoice",
        description="Compares vendor, amount and date against posted invoices.",
        integration="finance_system",
        agent_scope=["finance"],
        required_permission="finance.read",
        input_schema=_obj(["invoice_number"], {"invoice_number": STR, "amount": NUM, "vendor_name": STR}),
    ),
    ToolDefinition(
        name="finance.create_payment_request",
        display_name="Create payment request",
        description="Queues a payment request for the approved invoice. Financial write.",
        integration="finance_system",
        agent_scope=["finance"],
        required_permission="finance.payment.write",
        input_schema=_obj(["invoice_number", "amount"], {"invoice_number": STR, "amount": NUM, "vendor_name": STR, "currency": STR}),
        side_effect="financial",
        risk_level="critical",
        requires_approval=True,
        retry_safe=False,
        reversible=False,
    ),
    # -- CRM -------------------------------------------------------------------
    ToolDefinition(
        name="crm.lookup_customer",
        display_name="Look up customer",
        description="Finds a customer account by name, id or email.",
        integration="crm_system",
        agent_scope=["support", "finance"],
        required_permission="crm.read",
        input_schema=_obj([], {"customer_name": STR, "customer_id": STR, "email": STR}),
    ),
    ToolDefinition(
        name="crm.lookup_order_status",
        display_name="Look up order status",
        description="Returns fulfilment status for an order or the latest order for a customer.",
        integration="crm_system",
        agent_scope=["support"],
        required_permission="crm.read",
        input_schema=_obj([], {"order_id": STR, "customer_id": STR}),
    ),
    ToolDefinition(
        name="crm.update_ticket",
        display_name="Update support ticket",
        description="Sets classification and priority on the CRM ticket.",
        integration="crm_system",
        agent_scope=["support"],
        required_permission="crm.write",
        input_schema=_obj(["ticket_id", "classification"],
                          {"ticket_id": STR, "classification": STR, "priority": STR, "customer_id": STR}),
        side_effect="write",
    ),
    ToolDefinition(
        name="crm.log_resolution",
        display_name="Log resolution",
        description="Stores the resolution note and suggested reply against the ticket.",
        integration="crm_system",
        agent_scope=["support"],
        required_permission="crm.write",
        input_schema=_obj(["ticket_id", "resolution"], {"ticket_id": STR, "resolution": STR, "customer_id": STR}),
        side_effect="write",
        produces_documents=True,
    ),
    # -- Notifications ---------------------------------------------------------
    ToolDefinition(
        name="email.send_notification",
        display_name="Send notification",
        description="Delivers an in-app and sandbox email notification to a recipient.",
        integration="email_notifications",
        agent_scope=["support", "hr", "finance", "it", "document", "execution"],
        required_permission="notifications.send",
        input_schema=_obj(["recipient", "subject", "body"],
                          {"recipient": STR, "subject": STR, "body": STR, "employee_code": STR}),
        side_effect="write",
    ),
]

# Approval policy: which tool characteristics force a human checkpoint.
HIGH_RISK_LEVELS = {"high", "critical"}


def tool_names() -> list[str]:
    return [tool.name for tool in TOOL_DEFINITIONS]


def get_tool_definition(name: str) -> ToolDefinition | None:
    for tool in TOOL_DEFINITIONS:
        if tool.name == name:
            return tool
    return None


def tool_dicts() -> list[dict[str, Any]]:
    return [asdict(tool) for tool in TOOL_DEFINITIONS]
