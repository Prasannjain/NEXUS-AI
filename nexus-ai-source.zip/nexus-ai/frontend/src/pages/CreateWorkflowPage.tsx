import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { clsx } from "clsx";
import {
  AlertTriangle,
  ArrowRight,
  Bot,
  Circle,
  GitBranch,
  Layers,
  Loader2,
  Quote,
  Rocket,
  ShieldCheck,
  Sparkles,
  Wand2,
} from "lucide-react";
import { api, ApiError } from "../api/client";
import type { PlanPreview } from "../api/types";
import { Badge, Button, Card, CardTitle, ErrorNotice, Field, Notice, RiskBadge, inputClass } from "../components/ui";
import { agentIcon } from "../lib/icons";
import { agentColor, titleCase } from "../lib/format";
import { useAsync } from "../lib/hooks";
import { useToast } from "../state/ToastContext";

const CATEGORY_ICONS: Record<string, typeof Layers> = {
  employee_onboarding: Layers,
  invoice_processing: Circle,
  customer_request: Bot,
};

function PlanPreviewPanel({ plan }: { plan: PlanPreview }) {
  const byId = useMemo(() => new Map(plan.tasks.map((task) => [task.task_id, task])), [plan]);

  return (
    <Card className="animate-rise">
      <CardTitle
        icon={<Wand2 className="size-4" />}
        title={`Plan produced by the ${plan.source === "rule_engine" ? "deterministic" : "LLM-assisted"} Planner Agent`}
        subtitle={plan.rationale}
        action={
          <div className="flex flex-wrap items-center gap-2 justify-end">
            <Badge tone="navy">{plan.task_count} tasks</Badge>
            <Badge tone="amber">{plan.approval_checkpoints.length} checkpoints</Badge>
            <Badge tone="teal">{plan.provider === "none" ? "rule engine" : plan.provider}</Badge>
          </div>
        }
      />

      <div className="mb-4 flex flex-wrap items-center gap-2">
        {plan.agents.map((agent) => {
          const Icon = agentIcon();
          return (
            <span
              key={agent}
              className="inline-flex items-center gap-1.5 rounded-full border border-line px-2.5 py-1 text-[11px] font-medium text-ink-soft"
            >
              <Icon className="size-3" style={{ color: agentColor(agent) }} />
              {titleCase(agent)}
            </span>
          );
        })}
      </div>

      <div className="overflow-x-auto">
        <table className="w-full min-w-[720px] text-left text-[13px]">
          <thead>
            <tr className="border-b border-line text-[11px] tracking-wide text-ink-faint uppercase">
              <th className="py-2 pr-3 font-semibold">Step</th>
              <th className="py-2 pr-3 font-semibold">Agent</th>
              <th className="py-2 pr-3 font-semibold">Tool</th>
              <th className="py-2 pr-3 font-semibold">Task</th>
              <th className="py-2 pr-3 font-semibold">Depends on</th>
              <th className="py-2 pr-3 font-semibold">Risk</th>
              <th className="py-2 font-semibold">Approval</th>
            </tr>
          </thead>
          <tbody>
            {plan.tasks.map((task, index) => (
              <tr key={task.task_id} className="border-b border-line/70 last:border-0">
                <td className="py-2.5 pr-3 font-mono text-[11px] text-ink-faint">
                  {String(index + 1).padStart(2, "0")} · {task.task_id}
                </td>
                <td className="py-2.5 pr-3">
                  <span
                    className="inline-flex items-center gap-1.5 rounded-lg px-2 py-1 text-[11px] font-semibold"
                    style={{ background: `${agentColor(task.agent)}1a`, color: agentColor(task.agent) }}
                  >
                    {titleCase(task.agent)}
                  </span>
                </td>
                <td className="py-2.5 pr-3 font-mono text-[11px] text-ink-soft">{task.tool}</td>
                <td className="py-2.5 pr-3 text-ink">{task.description}</td>
                <td className="py-2.5 pr-3 text-[11px] text-ink-faint">
                  {task.depends_on.length
                    ? task.depends_on.map((id) => byId.get(id)?.task_id ?? id).join(", ")
                    : "—"}
                </td>
                <td className="py-2.5 pr-3">
                  <RiskBadge level={task.risk_level} />
                </td>
                <td className="py-2.5">
                  {task.requires_approval ? (
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-700 dark:text-amber-300">
                      <ShieldCheck className="size-3.5" /> required
                    </span>
                  ) : (
                    <span className="text-[11px] text-ink-faint">auto</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <p className="mt-4 text-[11px] leading-relaxed text-ink-faint">
        Approval requirements come from the tool registry, not from the model output, so a request cannot plan its way
        past a checkpoint. The Execution Agent will only call tools the assigned agent is scoped for.
      </p>
    </Card>
  );
}

export default function CreateWorkflowPage() {
  const navigate = useNavigate();
  const toast = useToast();
  const categories = useAsync(() => api.categories(), []);
  const [request, setRequest] = useState("");
  const [category, setCategory] = useState("auto");
  const [plan, setPlan] = useState<PlanPreview | null>(null);
  const [previewing, setPreviewing] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  const activeCategory = useMemo(
    () => categories.data?.categories.find((item) => item.key === category) ?? null,
    [categories.data, category],
  );

  const examples = activeCategory?.examples ?? [];
  const tooShort = request.trim().length < 8;

  async function preview() {
    setPreviewing(true);
    setError("");
    try {
      setPlan(await api.previewPlan(request.trim(), category));
    } catch (err) {
      setError(err instanceof ApiError ? err.detail : "The planner could not build a plan.");
      setPlan(null);
    } finally {
      setPreviewing(false);
    }
  }

  async function submit() {
    setSubmitting(true);
    setError("");
    try {
      const created = await api.createWorkflow(request.trim(), category);
      toast.push(`${created.id} submitted — the Planner Agent is decomposing it.`, "success");
      navigate(`/workflows/${created.id}`);
    } catch (err) {
      setError(err instanceof ApiError ? err.detail : "The platform could not accept the request.");
      setSubmitting(false);
    }
  }

  return (
    <div className="grid gap-4 xl:grid-cols-[1.15fr_0.85fr]">
      <div className="space-y-4">
        <Card>
          <CardTitle
            icon={<Sparkles className="size-4" />}
            title="Describe the outcome you need"
            subtitle="Plain language — the Planner Agent classifies it, extracts the details and builds a dependency-ordered plan."
          />

          <Field label="Workflow category" hint="Leave on auto-detect and the planner classifies from your wording.">
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
              <button
                type="button"
                onClick={() => setCategory("auto")}
                className={clsx(
                  "flex items-center gap-2 rounded-xl border px-3 py-2.5 text-left text-[13px] transition",
                  category === "auto"
                    ? "border-teal-400 bg-teal-50 text-teal-900 dark:bg-teal-500/10 dark:text-teal-200"
                    : "border-line text-ink-soft hover:border-line-strong hover:bg-surface-muted",
                )}
              >
                <GitBranch className="size-4" /> Auto-detect
              </button>
              {(categories.data?.categories ?? []).map((item) => {
                const Icon = CATEGORY_ICONS[item.key] ?? Layers;
                return (
                  <button
                    key={item.key}
                    type="button"
                    onClick={() => setCategory(item.key)}
                    className={clsx(
                      "flex items-center gap-2 rounded-xl border px-3 py-2.5 text-left text-[13px] transition",
                      category === item.key
                        ? "border-teal-400 bg-teal-50 text-teal-900 dark:bg-teal-500/10 dark:text-teal-200"
                        : "border-line text-ink-soft hover:border-line-strong hover:bg-surface-muted",
                    )}
                  >
                    <Icon className="size-4" /> {item.label}
                  </button>
                );
              })}
            </div>
          </Field>

          <div className="mt-4">
            <Field label="Request" required hint={`${request.trim().length} characters — minimum 8`}>
              <textarea
                className={clsx(inputClass, "min-h-[132px] resize-y leading-relaxed")}
                value={request}
                onChange={(event) => setRequest(event.target.value)}
                placeholder="e.g. Onboard Rahul Sharma as a Software Engineer in the Engineering Department starting next Monday; he needs a laptop, SSO and a payroll record."
              />
            </Field>
          </div>

          {error ? <ErrorNotice className="mt-4" message={error} /> : null}

          <div className="mt-4 flex flex-wrap gap-2">
            <Button onClick={preview} variant="secondary" disabled={tooShort || previewing}>
              {previewing ? <Loader2 className="size-4 animate-spin" /> : <Wand2 className="size-4" />}
              Preview plan
            </Button>
            <Button onClick={submit} disabled={tooShort || submitting}>
              {submitting ? <Loader2 className="size-4 animate-spin" /> : <Rocket className="size-4" />}
              Submit workflow
            </Button>
          </div>
          <p className="mt-3 text-[11px] text-ink-faint">
            Submitting authenticates your session, mints a unique workflow id, then hands the request to the Planner
            Agent inside the LangGraph orchestrator.
          </p>
        </Card>

        <Card>
          <CardTitle
            icon={<Quote className="size-4" />}
            title="Example requests"
            subtitle={activeCategory ? `Proven wording for ${activeCategory.label}` : "Pick a category to see tailored examples"}
          />
          {examples.length ? (
            <div className="grid gap-2">
              {examples.map((example) => (
                <button
                  key={example}
                  type="button"
                  onClick={() => setRequest(example)}
                  className="group flex items-start gap-3 rounded-xl border border-line px-3 py-2.5 text-left text-[13px] text-ink-soft transition hover:border-teal-300 hover:bg-teal-50/50 dark:hover:bg-teal-500/10"
                >
                  <Quote className="mt-0.5 size-3.5 shrink-0 text-ink-faint group-hover:text-teal-600" />
                  <span className="flex-1">{example}</span>
                  <ArrowRight className="mt-0.5 size-3.5 shrink-0 opacity-0 transition group-hover:opacity-100" />
                </button>
              ))}
            </div>
          ) : (
            <p className="text-sm text-ink-soft">
              Choose Employee Onboarding, Invoice Processing or Customer Request Resolution above to load sample prompts.
            </p>
          )}
        </Card>

        <Notice tone="warn" title="Sandbox execution">
          Every tool behind this workflow is a simulated enterprise adapter. Nothing is written to a live HR, finance,
          IT, CRM or mail system, and reports always state that actions were simulated.
        </Notice>
      </div>

      <div className="space-y-4">
        {plan ? (
          <PlanPreviewPanel plan={plan} />
        ) : (
          <Card>
            <CardTitle
              icon={<Bot className="size-4" />}
              title="What happens next"
              subtitle="The pipeline your request enters the moment you submit"
            />
            <ol className="space-y-3">
              {[
                ["Intake", "Request is authenticated, categorised and assigned a workflow id."],
                ["Planner Agent", "Extracts entities, decomposes the objective and orders tasks by dependency."],
                ["Specialised agents", "HR, Document, IT, Finance and Support each receive only their own tools."],
                ["Approval checkpoints", "High and critical-risk actions pause; a human must decide."],
                ["Execution Agent", "Validates permissions, calls the registered tool and verifies the result."],
                ["Failure recovery", "Transient faults retry with exponential backoff; financial writes never auto-retry."],
                ["Audit + report", "Every decision lands in the append-only trail and a downloadable report."],
              ].map(([label, description], index) => (
                <li key={label} className="flex gap-3">
                  <span className="mt-0.5 grid size-6 shrink-0 place-items-center rounded-lg bg-navy-900 text-[11px] font-bold text-white dark:bg-navy-100 dark:text-navy-900">
                    {index + 1}
                  </span>
                  <div>
                    <p className="text-[13px] font-semibold text-ink">{label}</p>
                    <p className="text-xs text-ink-soft">{description}</p>
                  </div>
                </li>
              ))}
            </ol>
            <div className="mt-4 flex items-start gap-2 rounded-xl bg-surface-muted px-3 py-2.5 text-[11px] text-ink-soft dark:bg-elevated">
              <AlertTriangle className="mt-0.5 size-3.5 shrink-0 text-amber-500" />
              Preview is optional — submitting starts the orchestrator immediately and the plan appears on the monitor.
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
