import { useEffect, useMemo, useState } from "react";
import { clsx } from "clsx";
import { Link } from "react-router-dom";
import {
  ChevronLeft,
  ChevronRight,
  Download,
  FileClock,
  Filter,
  LockKeyhole,
  RotateCcw,
  Search,
  Workflow,
} from "lucide-react";
import { api, ApiError } from "../api/client";
import type { AuditEntry } from "../api/types";
import { useAsync, useDebounced } from "../lib/hooks";
import { formatDateTime, titleCase } from "../lib/format";
import {
  Badge,
  Button,
  Card,
  CardTitle,
  Code,
  EmptyState,
  ErrorNotice,
  Field,
  LoadingPanel,
  Notice,
  Spinner,
  StatTile,
  inputClass,
} from "../components/ui";

const PAGE_SIZE = 50;

const SEVERITY_STYLE: Record<string, { dot: string; badge: string }> = {
  info: { dot: "bg-slate-400", badge: "bg-slate-100 text-slate-700 dark:bg-slate-500/15 dark:text-slate-300" },
  warning: { dot: "bg-amber-400", badge: "bg-amber-100 text-amber-800 dark:bg-amber-500/15 dark:text-amber-300" },
  error: { dot: "bg-red-500", badge: "bg-red-100 text-red-800 dark:bg-red-500/15 dark:text-red-300" },
};

interface Filters {
  q: string;
  workflow_id: string;
  agent_name: string;
  event_type: string;
  severity: string;
  date_from: string;
  date_to: string;
}

const EMPTY: Filters = {
  q: "",
  workflow_id: "",
  agent_name: "",
  event_type: "",
  severity: "",
  date_from: "",
  date_to: "",
};

export default function AuditLogsPage() {
  const [filters, setFilters] = useState<Filters>(EMPTY);
  const debouncedSearch = useDebounced(filters.q, 300);
  const [page, setPage] = useState(0);
  const [expanded, setExpanded] = useState<number | null>(null);
  const [exporting, setExporting] = useState(false);
  const [exportError, setExportError] = useState("");

  const active = useMemo<Filters>(
    () => ({ ...filters, q: debouncedSearch }),
    [filters, debouncedSearch],
  );

  const facets = useAsync(() => api.auditFacets(), []);

  const query = useMemo(
    () => ({
      q: active.q.trim() || undefined,
      workflow_id: active.workflow_id.trim() || undefined,
      agent_name: active.agent_name || undefined,
      event_type: active.event_type || undefined,
      severity: active.severity || undefined,
      date_from: active.date_from ? new Date(active.date_from).toISOString() : undefined,
      date_to: active.date_to ? new Date(active.date_to).toISOString() : undefined,
    }),
    [active],
  );

  useEffect(() => setPage(0), [query]);

  const logs = useAsync(
    () => api.audit({ ...query, limit: PAGE_SIZE, offset: page * PAGE_SIZE }),
    [query, page],
  );

  const total = logs.data?.total ?? 0;
  const pageCount = Math.max(1, Math.ceil(total / PAGE_SIZE));

  function update<K extends keyof Filters>(key: K, value: Filters[K]) {
    setFilters((current) => ({ ...current, [key]: value }));
  }

  async function exportCsv() {
    setExporting(true);
    setExportError("");
    try {
      await api.exportAudit(query);
    } catch (error) {
      setExportError(error instanceof ApiError ? error.detail : "The export could not be generated.");
    } finally {
      setExporting(false);
    }
  }

  const isFiltered = Object.values(active).some((value) => value.trim() !== "");

  return (
    <div className="space-y-5">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatTile
          label="Audit entries"
          value={(facets.data?.total_entries ?? 0).toLocaleString()}
          hint="every agent decision and API action"
          icon={<FileClock className="size-4" />}
          tone="navy"
        />
        <StatTile
          label="Matching filter"
          value={total.toLocaleString()}
          hint={isFiltered ? "narrowed view" : "showing the full trail"}
          icon={<Filter className="size-4" />}
          tone="teal"
        />
        <StatTile
          label="Recorded agents"
          value={facets.data?.agents.length ?? 0}
          hint="per-agent history available"
          icon={<Workflow className="size-4" />}
          tone="violet"
        />
        <StatTile
          label="Writability"
          value={facets.data?.append_only ? "Append-only" : "Mutable"}
          hint="no update or delete endpoint exists"
          icon={<LockKeyhole className="size-4" />}
          tone="green"
        />
      </div>

      <Notice title="Why the trail cannot be edited">
        Audit rows are written by the orchestrator and the API inside the same transaction as the action they describe.
        The application exposes no PUT, PATCH or DELETE route for <Code>/api/audit</Code>, so ordinary users and agents
        can only read and export it. Every entry below is a real record from this database.
      </Notice>

      <Card padded={false}>
        <div className="flex flex-wrap items-end gap-3 border-b border-line px-4 py-3">
          <div className="relative min-w-64 flex-1">
            <Search className="pointer-events-none absolute top-2.5 left-3 size-4 text-ink-faint" />
            <input
              value={filters.q}
              onChange={(event) => update("q", event.target.value)}
              placeholder="Search message, actor, tool, workflow or summary…"
              className={clsx(inputClass, "pl-9")}
              aria-label="Search audit entries"
            />
          </div>
          <div className="w-44">
            <Field label="Workflow id">
              <input
                value={filters.workflow_id}
                onChange={(event) => update("workflow_id", event.target.value)}
                placeholder="WF-…"
                className={clsx(inputClass, "font-mono text-xs")}
              />
            </Field>
          </div>
          <Field label="Agent">
            <select
              className={inputClass}
              value={filters.agent_name}
              onChange={(event) => update("agent_name", event.target.value)}
            >
              <option value="">Any agent</option>
              {(facets.data?.agents ?? []).map((agent) => (
                <option key={agent.name} value={agent.name}>
                  {titleCase(agent.name)} ({agent.value})
                </option>
              ))}
            </select>
          </Field>
          <Field label="Event">
            <select
              className={inputClass}
              value={filters.event_type}
              onChange={(event) => update("event_type", event.target.value)}
            >
              <option value="">Any event</option>
              {(facets.data?.event_types ?? []).map((event) => (
                <option key={event.name} value={event.name}>
                  {event.name.replace(/_/g, " ")} ({event.value})
                </option>
              ))}
            </select>
          </Field>
          <Field label="Severity">
            <select
              className={inputClass}
              value={filters.severity}
              onChange={(event) => update("severity", event.target.value)}
            >
              <option value="">Any</option>
              {(facets.data?.severities ?? []).map((severity) => (
                <option key={severity} value={severity}>
                  {severity}
                </option>
              ))}
            </select>
          </Field>
          <Field label="From">
            <input
              type="datetime-local"
              className={inputClass}
              value={filters.date_from}
              onChange={(event) => update("date_from", event.target.value)}
            />
          </Field>
          <Field label="To">
            <input
              type="datetime-local"
              className={inputClass}
              value={filters.date_to}
              onChange={(event) => update("date_to", event.target.value)}
            />
          </Field>
          <div className="flex gap-2">
            <Button variant="secondary" size="sm" onClick={() => setFilters(EMPTY)} disabled={!isFiltered}>
              <RotateCcw className="size-3.5" /> Reset
            </Button>
            <Button size="sm" onClick={exportCsv} disabled={exporting || total === 0}>
              {exporting ? <Spinner /> : <Download className="size-3.5" />} Export CSV
            </Button>
          </div>
        </div>

        {exportError ? <div className="px-4 pt-3"><ErrorNotice message={exportError} /></div> : null}

        {logs.loading ? (
          <LoadingPanel label="Reading the audit trail" />
        ) : logs.error ? (
          <div className="p-4">
            <ErrorNotice message={logs.error} onRetry={logs.reload} />
          </div>
        ) : (logs.data?.items.length ?? 0) === 0 ? (
          <div className="p-6">
            <EmptyState
              title="No audit entry matches these filters"
              description="Widen the date range or clear the search to see the full append-only trail."
              icon={<FileClock className="size-6" />}
            />
          </div>
        ) : (
          <div className="divide-y divide-line">
            {(logs.data?.items ?? []).map((entry) => (
              <AuditRow
                key={entry.id}
                entry={entry}
                expanded={expanded === entry.id}
                onToggle={() => setExpanded(expanded === entry.id ? null : entry.id)}
              />
            ))}
          </div>
        )}

        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-line px-4 py-2.5 text-xs text-ink-soft">
          <p>
            Page {Math.min(page + 1, pageCount)} of {pageCount} · showing {PAGE_SIZE} of {total.toLocaleString()}{" "}
            matching entries
          </p>
          <div className="flex gap-2">
            <Button
              variant="secondary"
              size="sm"
              onClick={() => setPage((value) => Math.max(0, value - 1))}
              disabled={page === 0}
            >
              <ChevronLeft className="size-3.5" /> Previous
            </Button>
            <Button
              variant="secondary"
              size="sm"
              onClick={() => setPage((value) => Math.min(pageCount - 1, value + 1))}
              disabled={page + 1 >= pageCount}
            >
              Next <ChevronRight className="size-3.5" />
            </Button>
          </div>
        </div>
      </Card>

      <Card>
        <CardTitle
          title="Per-agent history"
          subtitle="Select an agent to filter the trail by every decision it recorded."
          icon={<Workflow className="size-4" />}
        />
        <div className="flex flex-wrap gap-2">
          {(facets.data?.agents ?? []).map((agent) => (
            <button
              key={agent.name}
              type="button"
              onClick={() => update("agent_name", filters.agent_name === agent.name ? "" : agent.name)}
              className={clsx(
                "rounded-xl border px-3 py-1.5 text-xs font-medium transition",
                filters.agent_name === agent.name
                  ? "border-teal-400 bg-teal-50 text-teal-800 dark:bg-teal-500/15 dark:text-teal-200"
                  : "border-line bg-surface text-ink-soft hover:border-line-strong hover:bg-surface-muted dark:hover:bg-elevated",
              )}
            >
              {titleCase(agent.name)} · {agent.value}
            </button>
          ))}
          {(facets.data?.event_types ?? []).length === 0 && facets.error ? (
            <p className="text-xs text-ink-soft">{facets.error}</p>
          ) : null}
        </div>
      </Card>
    </div>
  );
}

function AuditRow({
  entry,
  expanded,
  onToggle,
}: {
  entry: AuditEntry;
  expanded: boolean;
  onToggle: () => void;
}) {
  const style = SEVERITY_STYLE[entry.severity] ?? SEVERITY_STYLE.info;
  return (
    <div>
      <button
        type="button"
        onClick={onToggle}
        className="flex w-full items-start gap-3 px-4 py-2.5 text-left transition hover:bg-surface-muted dark:hover:bg-elevated"
      >
        <span className={clsx("mt-1.5 size-2 shrink-0 rounded-full", style.dot)} />
        <span className="w-32 shrink-0 font-mono text-[11px] text-ink-faint">{formatDateTime(entry.created_at)}</span>
        <span className="w-36 shrink-0">
          <Badge className={style.badge}>{entry.event_type.replace(/_/g, " ")}</Badge>
        </span>
        <span className="w-24 shrink-0 text-xs font-medium text-ink-soft">{entry.agent_name ? titleCase(entry.agent_name) : "—"}</span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-[13px] text-ink">{entry.message}</span>
          {entry.tool_name ? <span className="font-mono text-[11px] text-ink-faint">{entry.tool_name}</span> : null}
        </span>
        {entry.workflow_id ? (
          <span className="w-32 shrink-0 text-right font-mono text-[11px] text-teal-700 dark:text-teal-300">
            {entry.workflow_id}
          </span>
        ) : (
          <span className="w-32 shrink-0 text-right text-[11px] text-ink-faint">system</span>
        )}
      </button>

      {expanded ? (
        <div className="grid grid-cols-2 gap-3 border-t border-dashed border-line bg-surface-muted px-4 py-3 text-xs md:grid-cols-6 dark:bg-elevated">
          <Detail label="Actor" value={entry.actor || "system"} />
          <Detail label="Task id" value={entry.task_id || "—"} />
          <Detail label="Entry id" value={String(entry.id)} />
          <Detail label="Input summary" value={entry.input_summary || "—"} span={3} />
          <Detail label="Output summary" value={entry.output_summary || "—"} span={3} />
          <div className="col-span-2 md:col-span-6">
            <p className="mb-1 text-[11px] tracking-wide text-ink-faint uppercase">Payload</p>
            <pre className="max-h-52 overflow-auto rounded-lg border border-line bg-surface p-2 font-mono text-[11px] text-ink-soft dark:bg-surface">
              {JSON.stringify(entry.payload ?? {}, null, 2)}
            </pre>
            {entry.workflow_id ? (
              <Link
                to={`/workflows/${entry.workflow_id}`}
                className="mt-2 inline-flex items-center gap-1 text-[11px] font-medium text-teal-700 hover:underline dark:text-teal-300"
              >
                Open the workflow record
              </Link>
            ) : null}
          </div>
        </div>
      ) : null}
    </div>
  );
}

const DETAIL_SPAN: Record<number, string> = {
  2: "col-span-2 md:col-span-2",
  3: "col-span-2 md:col-span-3",
};

function Detail({ label, value, span = 2 }: { label: string; value: string; span?: number }) {
  return (
    <div className={DETAIL_SPAN[span] ?? DETAIL_SPAN[2]}>
      <p className="text-[11px] tracking-wide text-ink-faint uppercase">{label}</p>
      <p className="break-words font-mono text-[11px] text-ink-soft">{value}</p>
    </div>
  );
}
