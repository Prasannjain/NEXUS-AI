import { useState } from "react";
import { Link } from "react-router-dom";
import { clsx } from "clsx";
import { Activity, Filter, Plus, Search, SlidersHorizontal } from "lucide-react";
import { api } from "../api/client";
import type { WorkflowStatus } from "../api/types";
import { Badge, Button, Card, CardTitle, EmptyState, ErrorNotice, LoadingPanel, Progress, StatusBadge, inputClass } from "../components/ui";
import { usePoll } from "../lib/hooks";
import { formatDuration, relativeTime, titleCase, WORKFLOW_STATUS_LABEL } from "../lib/format";

const STATUSES: (WorkflowStatus | "all")[] = [
  "all",
  "queued",
  "running",
  "awaiting_approval",
  "completed",
  "completed_with_exceptions",
  "rejected",
  "failed",
];

export default function WorkflowMonitorPage() {
  const [status, setStatus] = useState<string>("all");
  const [category, setCategory] = useState("");
  const [search, setSearch] = useState("");
  const categories = usePoll(() => api.categories(), 60000, []);
  const list = usePoll(
    () =>
      api.workflows({
        status: status === "all" ? undefined : status,
        category: category || undefined,
        search: search.trim() || undefined,
        limit: 60,
      }),
    5000,
    [status, category, search],
  );

  const rows = list.data?.items ?? [];

  return (
    <div className="space-y-4">
      <Card>
        <CardTitle
          icon={<Activity className="size-4" />}
          title="Workflow monitor"
          subtitle={`${list.data?.total ?? 0} workflow(s) · auto-refreshes every 5 seconds`}
          action={
            <Link to="/workflows/new">
              <Button size="sm">
                <Plus className="size-4" /> New workflow
              </Button>
            </Link>
          }
        />

        <div className="flex flex-wrap items-center gap-2">
          <div className="relative min-w-[240px] flex-1">
            <Search className="pointer-events-none absolute top-1/2 left-3 size-3.5 -translate-y-1/2 text-ink-faint" />
            <input
              className={clsx(inputClass, "pl-9")}
              placeholder="Search request text or workflow id"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
            />
          </div>
          <select className={clsx(inputClass, "w-auto")} value={category} onChange={(event) => setCategory(event.target.value)}>
            <option value="">All categories</option>
            {(categories.data?.categories ?? []).map((item) => (
              <option key={item.key} value={item.key}>
                {item.label}
              </option>
            ))}
          </select>
          <div className="flex flex-wrap items-center gap-1.5">
            <SlidersHorizontal className="size-3.5 text-ink-faint" />
            {STATUSES.map((option) => (
              <button
                key={option}
                type="button"
                onClick={() => setStatus(option)}
                className={clsx(
                  "rounded-lg border px-2.5 py-1 text-[11px] font-medium transition",
                  status === option
                    ? "border-teal-400 bg-teal-50 text-teal-800 dark:bg-teal-500/15 dark:text-teal-200"
                    : "border-line text-ink-soft hover:bg-surface-muted",
                )}
              >
                {option === "all" ? "All" : WORKFLOW_STATUS_LABEL[option]}
              </button>
            ))}
          </div>
        </div>
      </Card>

      <Card padded={false}>
        <div className="flex items-center justify-between px-5 py-3">
          <p className="text-xs font-semibold tracking-wide text-ink-soft uppercase">Executions</p>
          <Badge tone="neutral">
            <Filter className="size-3" /> {rows.length} shown
          </Badge>
        </div>
        {list.error ? (
          <div className="px-5 pb-5">
            <ErrorNotice message={list.error} />
          </div>
        ) : list.data === null && rows.length === 0 ? (
          <div className="px-5 pb-5">
            <LoadingPanel label="Loading executions" />
          </div>
        ) : rows.length === 0 ? (
          <div className="px-5 pb-5">
            <EmptyState
              title="Nothing matches these filters"
              description="Adjust the status or category filter, or submit a new request."
            />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[900px] text-left text-[13px]">
              <thead>
                <tr className="border-y border-line bg-surface-muted text-[11px] tracking-wide text-ink-faint uppercase dark:bg-elevated">
                  <th className="px-5 py-2.5 font-semibold">Workflow</th>
                  <th className="px-3 py-2.5 font-semibold">Category</th>
                  <th className="px-3 py-2.5 font-semibold">Stage</th>
                  <th className="px-3 py-2.5 font-semibold">Progress</th>
                  <th className="px-3 py-2.5 font-semibold">Tasks</th>
                  <th className="px-3 py-2.5 font-semibold">Requester</th>
                  <th className="px-3 py-2.5 font-semibold">Duration</th>
                  <th className="px-5 py-2.5 font-semibold">Status</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row) => {
                  const done = row.task_counts.completed ?? 0;
                  const failed = (row.task_counts.failed ?? 0) + (row.task_counts.rejected ?? 0);
                  return (
                    <tr key={row.id} className="border-b border-line/70 transition hover:bg-surface-muted dark:hover:bg-elevated">
                      <td className="px-5 py-3">
                        <Link to={`/workflows/${row.id}`} className="block">
                          <p className="max-w-[380px] truncate font-medium text-ink">{row.title}</p>
                          <p className="mt-0.5 flex items-center gap-2 font-mono text-[11px] text-ink-faint">
                            {row.id}
                            <span className="font-sans">· {relativeTime(row.created_at)}</span>
                          </p>
                        </Link>
                      </td>
                      <td className="px-3 py-3 text-xs text-ink-soft">{titleCase(row.category)}</td>
                      <td className="px-3 py-3 text-xs text-ink-soft">
                        {row.current_stage || "—"}
                        {row.active_agent ? (
                          <span className="mt-0.5 block text-[11px] text-ink-faint">{titleCase(row.active_agent)}</span>
                        ) : null}
                      </td>
                      <td className="px-3 py-3">
                        <div className="w-28">
                          <Progress
                            value={row.progress}
                            tone={row.status === "failed" ? "red" : row.status === "awaiting_approval" ? "amber" : "teal"}
                          />
                          <p className="mt-1 text-[10px] text-ink-faint">{row.progress.toFixed(0)}%</p>
                        </div>
                      </td>
                      <td className="px-3 py-3 text-xs tabular-nums text-ink-soft">
                        <span className="text-emerald-600 dark:text-emerald-400">{done}</span>
                        {failed ? <span className="text-red-600 dark:text-red-400"> / {failed}</span> : null}
                        <span className="text-ink-faint"> / {row.task_counts.total ?? 0}</span>
                        {row.pending_approvals ? (
                          <Badge tone="amber" className="ml-2">
                            {row.pending_approvals} pending
                          </Badge>
                        ) : null}
                      </td>
                      <td className="px-3 py-3 text-xs text-ink-soft">{row.requester}</td>
                      <td className="px-3 py-3 text-xs tabular-nums text-ink-soft">{formatDuration(row.duration_seconds)}</td>
                      <td className="px-5 py-3">
                        <StatusBadge status={row.status} />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
