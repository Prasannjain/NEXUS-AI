import { useCallback, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { clsx } from "clsx";
import {
  Activity,
  AlertTriangle,
  ArrowLeft,
  Ban,
  CheckCircle2,
  Clock,
  Download,
  FileText,
  KeyRound,
  Layers,
  Play,
  RefreshCw,
  ScrollText,
  ShieldCheck,
  Wrench,
} from "lucide-react";
import { api, ApiError } from "../api/client";
import type { ApprovalItem, WorkflowTask } from "../api/types";
import {
  Badge,
  Button,
  Card,
  CardTitle,
  Code,
  EmptyState,
  ErrorNotice,
  LoadingPanel,
  Notice,
  Progress,
  RiskBadge,
  StatusBadge,
  TaskBadge,
} from "../components/ui";
import { StageFlow } from "../components/StageFlow";
import { usePoll } from "../lib/hooks";
import { agentColor, formatDateTime, formatDuration, formatMs, taskDuration, titleCase } from "../lib/format";
import { useToast } from "../state/ToastContext";
import { useAuth } from "../state/AuthContext";

const TABS = [
  { key: "pipeline", label: "Pipeline", icon: Layers },
  { key: "tasks", label: "Tasks", icon: Activity },
  { key: "approvals", label: "Approvals", icon: ShieldCheck },
  { key: "tools", label: "Tools & documents", icon: Wrench },
  { key: "audit", label: "Audit trail", icon: ScrollText },
  { key: "report", label: "Final report", icon: FileText },
] as const;

type TabKey = (typeof TABS)[number]["key"];

const TERMINAL = new Set(["completed", "completed_with_exceptions", "rejected", "failed", "cancelled"]);

function TaskRow({ task, expanded, onToggle }: { task: WorkflowTask; expanded: boolean; onToggle: () => void }) {
  const color = agentColor(task.agent_name);
  return (
    <div className="border-b border-line/70 last:border-0">
      <button
        type="button"
        onClick={onToggle}
        className="grid w-full grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 py-3 text-left transition hover:bg-surface-muted sm:grid-cols-[70px_110px_minmax(0,1fr)_120px_auto] dark:hover:bg-elevated"
      >
        <span className="font-mono text-[11px] text-ink-faint">#{String(task.seq).padStart(2, "0")}</span>
        <span className="hidden sm:block">
          <span
            className="inline-flex rounded-md px-2 py-0.5 text-[11px] font-semibold"
            style={{ background: `${color}1f`, color }}
          >
            {titleCase(task.agent_name)}
          </span>
        </span>
        <span className="min-w-0">
          <span className="block truncate text-[13px] text-ink">{task.description}</span>
          <span className="mt-0.5 block truncate font-mono text-[11px] text-ink-faint">{task.tool_name}</span>
        </span>
        <span className="hidden text-[11px] text-ink-faint sm:block">
          {task.attempts > 1 ? (
            <span className="inline-flex items-center gap-1 text-violet-600 dark:text-violet-400">
              <RefreshCw className="size-3" /> {task.attempts} attempts
            </span>
          ) : task.started_at && task.finished_at ? (
            <span className="inline-flex items-center gap-1">
              <Clock className="size-3" /> {taskDuration(task.started_at, task.finished_at)}
            </span>
          ) : (
            "—"
          )}
        </span>
        <span className="flex items-center gap-2">
          {task.requires_approval ? <ShieldCheck className="size-3.5 text-amber-500" /> : null}
          <TaskBadge status={task.status} />
        </span>
      </button>
      {expanded ? (
        <div className="grid gap-3 border-t border-line bg-surface-muted px-3 py-3 text-xs sm:grid-cols-2 dark:bg-elevated/60">
          <div>
            <p className="mb-1 font-semibold tracking-wide text-ink-faint uppercase">Arguments</p>
            <pre className="max-h-40 overflow-auto rounded-lg bg-surface p-2 font-mono text-[11px] text-ink-soft dark:bg-surface">
              {JSON.stringify(task.arguments, null, 2)}
            </pre>
            {task.depends_on.length ? (
              <p className="mt-2 text-[11px] text-ink-faint">
                Depends on: <Code>{task.depends_on.join(", ")}</Code>
              </p>
            ) : null}
          </div>
          <div>
            <p className="mb-1 font-semibold tracking-wide text-ink-faint uppercase">Result</p>
            {task.error ? (
              <p className="rounded-lg bg-red-50 px-2 py-1.5 text-[11px] text-red-800 dark:bg-red-500/10 dark:text-red-200">
                {task.error}
              </p>
            ) : null}
            {task.output_summary ? <p className="mb-1.5 text-ink-soft">{task.output_summary}</p> : null}
            <pre className="max-h-40 overflow-auto rounded-lg bg-surface p-2 font-mono text-[11px] text-ink-soft dark:bg-surface">
              {task.result ? JSON.stringify(task.result, null, 2) : "not executed yet"}
            </pre>
          </div>
        </div>
      ) : null}
    </div>
  );
}

export default function WorkflowDetailPage() {
  const { workflowId = "" } = useParams();
  const toast = useToast();
  const { can } = useAuth();
  const [tab, setTab] = useState<TabKey>("pipeline");
  const [expandedTask, setExpandedTask] = useState<string | null>(null);
  const [selectedStage, setSelectedStage] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const detail = usePoll(() => api.workflow(workflowId), 4000, [workflowId]);
  const queue = usePoll(() => api.approvals("pending"), 6000, []);
  const audit = usePoll(() => api.workflowAudit(workflowId), 8000, [workflowId]);

  const workflow = detail.data;
  const decidable = useMemo(() => {
    const map = new Map<string, ApprovalItem>();
    (queue.data?.items ?? []).forEach((item) => map.set(item.id, item));
    return map;
  }, [queue.data]);

  const stage = useMemo(
    () => workflow?.timeline.find((entry) => entry.key === selectedStage) ?? null,
    [workflow, selectedStage],
  );

  const decide = useCallback(
    async (approvalId: string, action: "approve" | "reject", comment: string) => {
      setBusy(true);
      try {
        await api.decide(approvalId, action, comment);
        toast.push(
          action === "approve" ? "Approved — the workflow resumes now." : "Rejected — the action is blocked and the requester is notified.",
          action === "approve" ? "success" : "info",
        );
        void detail.reload();
        void queue.reload();
      } catch (error) {
        toast.push(error instanceof ApiError ? error.detail : "Decision rejected by the API.", "error");
      } finally {
        setBusy(false);
      }
    },
    [detail, queue, toast],
  );

  if (detail.error && !workflow) {
    return (
      <div className="space-y-4">
        <Link to="/workflows" className="inline-flex items-center gap-1.5 text-sm text-teal-600 hover:underline">
          <ArrowLeft className="size-4" /> Back to monitor
        </Link>
        <ErrorNotice message={detail.error} onRetry={detail.reload} />
      </div>
    );
  }
  if (!workflow) return <LoadingPanel label="Loading workflow" />;

  const settled = TERMINAL.has(workflow.status);
  const pendingApprovals = workflow.approvals.filter((approval) => approval.status === "pending");
  const completedTasks = workflow.tasks.filter((task) => task.status === "completed").length;
  const failedTasks = workflow.tasks.filter((task) => task.status === "failed" || task.status === "rejected").length;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="min-w-0">
          <Link to="/workflows" className="inline-flex items-center gap-1.5 text-xs text-ink-faint hover:text-teal-600">
            <ArrowLeft className="size-3.5" /> Workflow monitor
          </Link>
          <div className="mt-1 flex flex-wrap items-center gap-2.5">
            <h2 className="text-lg font-bold tracking-tight text-ink">{workflow.id}</h2>
            <StatusBadge status={workflow.status} />
            <Badge tone="neutral">{titleCase(workflow.category)}</Badge>
            {workflow.running ? <Badge tone="teal">live run</Badge> : null}
          </div>
          <p className="mt-1 max-w-3xl text-[13px] text-ink-soft">{workflow.request_text}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {workflow.checkpoint.exists && workflow.status === "awaiting_approval" ? (
            <Button
              size="sm"
              variant="secondary"
              disabled={busy || !can("approvals.decide")}
              onClick={async () => {
                setBusy(true);
                try {
                  await api.resumeWorkflow(workflow.id);
                  toast.push("Re-armed the checkpoint so the recorded decision can be applied.", "info");
                  detail.reload();
                } catch (error) {
                  toast.push(error instanceof ApiError ? error.detail : "Resume failed.", "error");
                } finally {
                  setBusy(false);
                }
              }}
            >
              <Play className="size-3.5" /> Re-arm checkpoint
            </Button>
          ) : null}
          {!settled ? (
            <Button
              size="sm"
              variant="danger"
              disabled={busy}
              onClick={async () => {
                setBusy(true);
                try {
                  await api.cancelWorkflow(workflow.id);
                  toast.push(`${workflow.id} cancelled.`, "info");
                  detail.reload();
                } catch (error) {
                  toast.push(error instanceof ApiError ? error.detail : "Cancel failed.", "error");
                } finally {
                  setBusy(false);
                }
              }}
            >
              <Ban className="size-3.5" /> Cancel
            </Button>
          ) : null}
          {settled ? (
            <>
              <Button size="sm" variant="secondary" onClick={() => setTab("report")}>
                <FileText className="size-3.5" /> View report
              </Button>
              <Button size="sm" onClick={() => void api.downloadReport(workflow.id).catch((error) => toast.push(String(error), "error"))}>
                <Download className="size-3.5" /> Download report
              </Button>
            </>
          ) : null}
        </div>
      </div>

      <Card>
        <div className="grid gap-4 md:grid-cols-[minmax(0,1fr)_auto] md:items-center">
          <div>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="text-xs font-semibold tracking-wide text-ink-soft uppercase">
                Stage {workflow.timeline.findIndex((entry) => entry.is_current) + 1} of 12 · {workflow.current_stage || "Queued"}
              </p>
              <p className="text-[11px] text-ink-faint">
                {completedTasks} completed · {failedTasks} failed · {workflow.tasks.length - completedTasks - failedTasks} remaining
              </p>
            </div>
            <Progress
              className="mt-2"
              value={workflow.progress}
              tone={workflow.status === "failed" ? "red" : workflow.status === "awaiting_approval" ? "amber" : "teal"}
            />
            <div className="mt-2.5 flex flex-wrap gap-4 text-[11px] text-ink-soft">
              <span className="inline-flex items-center gap-1">
                <Activity className="size-3" /> agent: <strong>{titleCase(workflow.active_agent || "—")}</strong>
              </span>
              <span className="inline-flex items-center gap-1">
                <Clock className="size-3" /> duration: {formatDuration(workflow.duration_seconds)}
              </span>
              <span className="inline-flex items-center gap-1">
                <KeyRound className="size-3" /> planner: {workflow.llm_provider === "none" ? "deterministic rule engine" : workflow.llm_provider}
              </span>
              <span className="inline-flex items-center gap-1">
                <ScrollText className="size-3" /> audit entries: {workflow.audit_entries}
              </span>
            </div>
          </div>
          {pendingApprovals.length ? (
            <div className="rounded-xl border border-amber-300 bg-amber-50 px-4 py-3 text-amber-900 dark:border-amber-400/30 dark:bg-amber-500/10 dark:text-amber-200">
              <p className="flex items-center gap-1.5 text-xs font-semibold">
                <AlertTriangle className="size-3.5" /> Paused for human approval
              </p>
              <p className="mt-1 text-[11px]">
                The LangGraph thread is interrupted at {pendingApprovals.length} checkpoint(s). Nothing sensitive runs
                until an authorised approver decides.
              </p>
            </div>
          ) : null}
        </div>
      </Card>

      <div className="flex flex-wrap gap-1.5">
        {TABS.map((entry) => {
          const Icon = entry.icon;
          return (
            <button
              key={entry.key}
              type="button"
              onClick={() => setTab(entry.key)}
              className={clsx(
                "inline-flex items-center gap-1.5 rounded-xl border px-3 py-1.5 text-[13px] font-medium transition",
                tab === entry.key
                  ? "border-teal-400 bg-teal-50 text-teal-900 dark:bg-teal-500/15 dark:text-teal-200"
                  : "border-line bg-surface text-ink-soft hover:bg-surface-muted",
              )}
            >
              <Icon className="size-3.5" />
              {entry.label}
              {entry.key === "approvals" && pendingApprovals.length ? (
                <span className="rounded-full bg-amber-500 px-1.5 text-[10px] font-bold text-white">
                  {pendingApprovals.length}
                </span>
              ) : null}
            </button>
          );
        })}
      </div>

      {tab === "pipeline" ? (
        <div className="grid gap-4 xl:grid-cols-[1.5fr_1fr]">
          <Card padded={false}>
            <div className="px-5 pt-5">
              <CardTitle
                title="Twelve-stage execution pipeline"
                subtitle="Click any stage to inspect what happened there"
                className="mb-1"
              />
            </div>
            <StageFlow timeline={workflow.timeline} onSelect={setSelectedStage} />
          </Card>

          <div className="space-y-4">
            {stage ? (
              <Card>
                <CardTitle title={stage.label} subtitle={`Stage ${workflow.timeline.indexOf(stage) + 1} of 12`} />
                <div className="space-y-2 text-[13px]">
                  <p className="text-ink-soft">{stage.description}</p>
                  <p className="rounded-lg bg-surface-muted px-3 py-2 text-ink dark:bg-elevated">{stage.detail || "No activity recorded yet."}</p>
                  <Badge
                    className={clsx(
                      stage.status === "completed" && "!bg-emerald-100 !text-emerald-800 dark:!bg-emerald-500/15 dark:!text-emerald-300",
                      stage.status === "running" && "!bg-blue-100 !text-blue-800 dark:!bg-blue-500/15 dark:!text-blue-300",
                      stage.status === "waiting" && "!bg-amber-100 !text-amber-800 dark:!bg-amber-500/15 dark:!text-amber-300",
                      stage.status === "failed" && "!bg-red-100 !text-red-800 dark:!bg-red-500/15 dark:!text-red-300",
                    )}
                  >
                    {titleCase(stage.status)}
                  </Badge>
                </div>
              </Card>
            ) : (
              <Card>
                <CardTitle title="Stage detail" subtitle="Select a stage in the pipeline graph" />
                <EmptyState title="Nothing selected" description="Agent runs, tool calls and decisions appear here." />
              </Card>
            )}

            <Card>
              <CardTitle title="Agent decisions" subtitle="Newest reasoning written by the orchestrator" />
              <ul className="max-h-72 space-y-2 overflow-y-auto pr-1">
                {workflow.executions.slice(-14).reverse().map((row) => (
                  <li key={row.id} className="rounded-lg border border-line px-3 py-2">
                    <div className="flex items-center justify-between gap-2">
                      <span
                        className="rounded-md px-1.5 py-0.5 text-[10px] font-semibold"
                        style={{ background: `${agentColor(row.agent_name)}1f`, color: agentColor(row.agent_name) }}
                      >
                        {titleCase(row.agent_name || row.node)}
                      </span>
                      <span className="text-[10px] text-ink-faint">{formatMs(row.duration_ms)}</span>
                    </div>
                    <p className="mt-1 text-[11.5px] leading-snug text-ink-soft">{row.decision || row.output_summary || row.node}</p>
                  </li>
                ))}
                {workflow.executions.length === 0 ? <EmptyState title="No decisions recorded yet" /> : null}
              </ul>
            </Card>
          </div>
        </div>
      ) : null}

      {tab === "tasks" ? (
        <Card padded={false}>
          <div className="px-5 pt-5">
            <CardTitle
              title={`Execution plan (${workflow.tasks.length} tasks)`}
              subtitle="Ordered by dependency; expand a row for the arguments and the verified result"
            />
          </div>
          {workflow.tasks.length ? (
            <div className="px-5 pb-4">
              {workflow.tasks.map((task) => (
                <TaskRow
                  key={task.task_id}
                  task={task}
                  expanded={expandedTask === task.task_id}
                  onToggle={() => setExpandedTask((current) => (current === task.task_id ? null : task.task_id))}
                />
              ))}
            </div>
          ) : (
            <div className="px-5 pb-5">
              <EmptyState title="The planner is still working" description="Tasks appear as soon as the plan is persisted." />
            </div>
          )}
          {workflow.plan ? (
            <div className="border-t border-line px-5 py-4">
              <p className="text-xs font-semibold tracking-wide text-ink-soft uppercase">Planner rationale</p>
              <p className="mt-1.5 text-[13px] text-ink-soft">{workflow.plan.rationale}</p>
              <div className="mt-2 flex flex-wrap gap-2">
                <Badge tone="navy">{workflow.plan.task_count} tasks</Badge>
                <Badge tone="amber">{workflow.plan.approval_checkpoints.length} checkpoints</Badge>
                <Badge tone="teal">source: {workflow.plan.source === "rule_engine" ? "deterministic" : workflow.plan.provider}</Badge>
              </div>
            </div>
          ) : null}
        </Card>
      ) : null}

      {tab === "approvals" ? (
        <div className="space-y-4">
          {workflow.approvals.length === 0 ? (
            <Card>
              <EmptyState
                title="No approval checkpoints in this workflow"
                description="The planner found no high or critical-risk action, so nothing needed a human decision."
              />
            </Card>
          ) : null}
          {workflow.approvals.map((approval) => {
            const rich = decidable.get(approval.id);
            const canDecide = Boolean(rich?.can_decide);
            return (
              <Card key={approval.id}>
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-sm font-semibold text-ink">{approval.action}</h3>
                      <RiskBadge level={approval.risk_level} />
                      <Badge
                        className={
                          approval.status === "approved"
                            ? "!bg-emerald-100 !text-emerald-800 dark:!bg-emerald-500/15 dark:!text-emerald-300"
                            : approval.status === "rejected"
                              ? "!bg-rose-100 !text-rose-800 dark:!bg-rose-500/15 dark:!text-rose-300"
                              : "!bg-amber-100 !text-amber-800 dark:!bg-amber-500/15 dark:!text-amber-300"
                        }
                      >
                        {approval.status}
                      </Badge>
                    </div>
                    <p className="mt-1 text-[13px] text-ink-soft">{approval.policy_reason}</p>
                    <p className="mt-1.5 flex flex-wrap gap-3 text-[11px] text-ink-faint">
                      <span>
                        agent <strong className="text-ink-soft">{titleCase(approval.agent_name)}</strong>
                      </span>
                      <span>
                        task <Code>{approval.task_id}</Code>
                      </span>
                      <span>requested {formatDateTime(approval.requested_at)}</span>
                      {approval.decided_at ? <span>decided {formatDateTime(approval.decided_at)} by {approval.decided_by}</span> : null}
                    </p>
                  </div>
                </div>

                {Object.keys(approval.details).length ? (
                  <pre className="mt-3 max-h-44 overflow-auto rounded-xl bg-surface-muted p-3 font-mono text-[11px] text-ink-soft dark:bg-elevated">
                    {JSON.stringify(approval.details, null, 2)}
                  </pre>
                ) : null}

                {approval.comment ? (
                  <p className="mt-3 rounded-lg border border-line px-3 py-2 text-xs text-ink-soft">
                    <strong>Decision note:</strong> {approval.comment}
                  </p>
                ) : null}

                {approval.status === "pending" ? (
                  <ApprovalActions
                    disabled={!canDecide}
                    busy={busy}
                    reason={
                      canDecide
                        ? undefined
                        : rich
                          ? "Your role cannot approve this capability — an approver or admin must decide."
                          : "Loading your authority for this checkpoint…"
                    }
                    onDecide={(action, comment) => void decide(approval.id, action, comment)}
                  />
                ) : null}
              </Card>
            );
          })}
        </div>
      ) : null}

      {tab === "tools" ? (
        <div className="grid gap-4 xl:grid-cols-2">
          <Card padded={false}>
            <div className="px-5 pt-5">
              <CardTitle
                icon={<Wrench className="size-4" />}
                title="Tool execution history"
                subtitle="Every call carries an idempotency key so a replay cannot duplicate a side effect"
              />
            </div>
            {workflow.tool_calls.length ? (
              <div className="overflow-x-auto px-5 pb-5">
                <table className="w-full min-w-[520px] text-left text-[12px]">
                  <thead>
                    <tr className="border-b border-line text-[10px] tracking-wide text-ink-faint uppercase">
                      <th className="py-2 pr-2 font-semibold">Tool</th>
                      <th className="py-2 pr-2 font-semibold">Agent</th>
                      <th className="py-2 pr-2 font-semibold">Status</th>
                      <th className="py-2 pr-2 font-semibold">ms</th>
                      <th className="py-2 font-semibold">Idempotency key</th>
                    </tr>
                  </thead>
                  <tbody>
                    {workflow.tool_calls.map((call, index) => (
                      <tr key={`${call.idempotency_key}-${index}`} className="border-b border-line/60 last:border-0">
                        <td className="py-2 pr-2">
                          <span className="block text-ink">{call.tool_name}</span>
                          <span className="block text-[11px] text-ink-faint">{call.summary}</span>
                        </td>
                        <td className="py-2 pr-2 text-ink-soft">{titleCase(call.agent_name)}</td>
                        <td className="py-2 pr-2">
                          <Badge
                            className={
                              call.status === "completed"
                                ? "!bg-emerald-100 !text-emerald-800 dark:!bg-emerald-500/15 dark:!text-emerald-300"
                                : call.status === "failed"
                                  ? "!bg-red-100 !text-red-800 dark:!bg-red-500/15 dark:!text-red-300"
                                  : ""
                            }
                          >
                            {call.status}
                          </Badge>
                        </td>
                        <td className="py-2 pr-2 tabular-nums text-ink-faint">{call.duration_ms.toFixed(2)}</td>
                        <td className="py-2">
                          <Code>{call.idempotency_key}</Code>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="px-5 pb-5">
                <EmptyState title="No tool calls yet" description="The Execution Agent calls tools after permission checks." />
              </div>
            )}
          </Card>

          <Card>
            <CardTitle
              icon={<FileText className="size-4" />}
              title="Generated documents"
              subtitle="Produced by the Document Agent inside the sandbox workspace"
            />
            {workflow.documents.length ? (
              <ul className="space-y-2">
                {workflow.documents.map((doc) => (
                  <li key={doc.id} className="flex items-center justify-between gap-3 rounded-xl border border-line px-3 py-2.5">
                    <div className="min-w-0">
                      <p className="truncate text-[13px] font-medium text-ink">{doc.title}</p>
                      <p className="mt-0.5 text-[11px] text-ink-faint">
                        <Code>{doc.doc_type}</Code> · {(doc.file_size / 1024).toFixed(1)} KB · {formatDateTime(doc.created_at)}
                      </p>
                    </div>
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() =>
                        void api
                          .downloadDocument(workflow.id, doc.id, doc.title)
                          .catch((error) => toast.push(error instanceof ApiError ? error.detail : "Download failed.", "error"))
                      }
                    >
                      <Download className="size-3.5" /> Download
                    </Button>
                  </li>
                ))}
              </ul>
            ) : (
              <EmptyState title="No documents generated" description="Offer letters and onboarding packs appear here." />
            )}
          </Card>
        </div>
      ) : null}

      {tab === "audit" ? (
        <Card padded={false}>
          <div className="px-5 pt-5">
            <CardTitle
              icon={<ScrollText className="size-4" />}
              title={`Append-only audit trail (${audit.data?.length ?? workflow.audit_entries} entries)`}
              subtitle="Requests, agent decisions, tool calls, approval outcomes, failures and timestamps"
            />
          </div>
          <div className="px-5 pb-5">
            {audit.data?.length ? (
              <ol className="relative space-y-3 border-l border-line pl-4">
                {audit.data.map((entry) => (
                  <li key={entry.id} className="relative">
                    <span
                      className={clsx(
                        "absolute top-1.5 -left-[21px] size-2.5 rounded-full ring-4 ring-surface",
                        entry.severity === "error"
                          ? "bg-red-500"
                          : entry.severity === "warning"
                            ? "bg-amber-500"
                            : entry.severity === "success"
                              ? "bg-emerald-500"
                              : "bg-teal-500",
                      )}
                    />
                    <div className="flex flex-wrap items-center gap-2">
                      <span
                        className="rounded-md px-1.5 py-0.5 text-[10px] font-semibold"
                        style={{ background: `${agentColor(entry.agent_name)}1f`, color: agentColor(entry.agent_name) }}
                      >
                        {titleCase(entry.agent_name)}
                      </span>
                      <Code>{entry.event_type}</Code>
                      <span className="text-[11px] text-ink-faint">{formatDateTime(entry.created_at)}</span>
                    </div>
                    <p className="mt-1 text-[13px] text-ink">{entry.message}</p>
                    {entry.tool_name ? (
                      <p className="mt-0.5 text-[11px] text-ink-faint">
                        tool <Code>{entry.tool_name}</Code>
                        {entry.output_summary ? ` → ${entry.output_summary}` : ""}
                      </p>
                    ) : null}
                  </li>
                ))}
              </ol>
            ) : audit.error ? (
              <ErrorNotice message={audit.error} />
            ) : (
              <LoadingPanel label="Loading audit entries" />
            )}
          </div>
        </Card>
      ) : null}

      {tab === "report" ? (
        <div className="space-y-4">
          {!workflow.final_report ? (
            <Card>
              <Notice tone="info" title="The report is generated when the workflow settles">
                Completed tasks, approval history, tool executions, failures and timing are assembled once every branch
                reaches a terminal state.
              </Notice>
            </Card>
          ) : (
            <Card>
              <CardTitle
                icon={<FileText className="size-4" />}
                title="Final execution report"
                subtitle={workflow.final_report.headline}
                action={
                  <Button size="sm" onClick={() => void api.downloadReport(workflow.id)}>
                    <Download className="size-3.5" /> Download .md
                  </Button>
                }
              />
              <Notice tone="warn" title={workflow.final_report.simulation_notice || "Sandbox execution"} />
              <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                {[
                  ["Status", titleCase(workflow.final_report.status)],
                  ["Duration", formatDuration(workflow.final_report.duration_seconds)],
                  ["Completed tasks", String(workflow.final_report.completed_tasks)],
                  ["Failed tasks", String(workflow.final_report.failed_tasks)],
                  ["Approvals", String(workflow.final_report.approvals.length)],
                  ["Tool executions", String(workflow.final_report.tool_executions.length)],
                  ["Documents", String(workflow.final_report.documents.length)],
                  ["Audit entries", String(workflow.final_report.audit_entries)],
                ].map(([label, value]) => (
                  <div key={label} className="rounded-xl border border-line px-3 py-2">
                    <p className="text-[10px] tracking-wide text-ink-faint uppercase">{label}</p>
                    <p className="text-sm font-semibold text-ink">{value}</p>
                  </div>
                ))}
              </div>

              <div className="mt-4 grid gap-4 lg:grid-cols-2">
                <div>
                  <p className="mb-2 text-xs font-semibold tracking-wide text-ink-soft uppercase">Agents involved</p>
                  <div className="flex flex-wrap gap-2">
                    {workflow.final_report.agents_involved.map((agent) => (
                      <span
                        key={agent}
                        className="rounded-lg px-2 py-1 text-[11px] font-semibold"
                        style={{ background: `${agentColor(agent)}1f`, color: agentColor(agent) }}
                      >
                        {titleCase(agent)}
                      </span>
                    ))}
                  </div>
                  <p className="mt-4 mb-2 text-xs font-semibold tracking-wide text-ink-soft uppercase">Extracted entities</p>
                  <pre className="max-h-44 overflow-auto rounded-xl bg-surface-muted p-3 font-mono text-[11px] text-ink-soft dark:bg-elevated">
                    {JSON.stringify(workflow.final_report.entities, null, 2)}
                  </pre>
                </div>
                <div>
                  <p className="mb-2 text-xs font-semibold tracking-wide text-ink-soft uppercase">Approval history</p>
                  {workflow.final_report.approvals.length ? (
                    <ul className="space-y-2">
                      {workflow.final_report.approvals.map((row, index) => (
                        <li key={index} className="rounded-xl border border-line px-3 py-2 text-[12px]">
                          <div className="flex items-center justify-between gap-2">
                            <p className="truncate font-medium text-ink">{String(row.action ?? "")}</p>
                            <Badge
                              className={
                                row.status === "approved"
                                  ? "!bg-emerald-100 !text-emerald-800 dark:!bg-emerald-500/15 dark:!text-emerald-300"
                                  : "!bg-rose-100 !text-rose-800 dark:!bg-rose-500/15 dark:!text-rose-300"
                              }
                            >
                              {String(row.status ?? "")}
                            </Badge>
                          </div>
                          <p className="mt-0.5 text-[11px] text-ink-faint">
                            {String(row.decided_by ?? "")} · {String(row.comment ?? "no comment")}
                          </p>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <EmptyState title="No approvals were needed" />
                  )}
                </div>
              </div>
            </Card>
          )}

          <Card>
            <CardTitle
              icon={<CheckCircle2 className="size-4" />}
              title="Requester notification"
              subtitle="Completion events are delivered to the person who submitted the request"
            />
            <p className="text-[13px] text-ink-soft">
              Requester <strong className="text-ink">{workflow.requester}</strong> · submitted{" "}
              {formatDateTime(workflow.created_at)} · {settled ? "finalised" : "in progress"}{" "}
              {formatDateTime(workflow.finished_at || workflow.started_at)}.
            </p>
            <p className="mt-2 text-[11px] text-ink-faint">
              Open the bell in the header to see delivery state; escalations are additionally e-mailed to the configured
              administrator address when a task exhausts its retries.
            </p>
          </Card>
        </div>
      ) : null}
    </div>
  );
}

function ApprovalActions({
  onDecide,
  disabled,
  busy,
  reason,
}: {
  onDecide: (action: "approve" | "reject", comment: string) => void;
  disabled: boolean;
  busy: boolean;
  reason?: string;
}) {
  const [comment, setComment] = useState("");
  return (
    <div className="mt-4 rounded-xl border border-line bg-surface-muted p-3 dark:bg-elevated/60">
      {reason ? (
        <p className="mb-2 flex items-start gap-1.5 text-[11px] text-ink-faint">
          <AlertTriangle className="mt-0.5 size-3 shrink-0" /> {reason}
        </p>
      ) : null}
      <textarea
        value={comment}
        onChange={(event) => setComment(event.target.value)}
        placeholder="Optional justification recorded in the audit trail…"
        className="w-full rounded-lg border border-line bg-surface px-3 py-2 text-[13px] text-ink outline-none focus:border-teal-400 dark:bg-surface"
        rows={2}
        disabled={disabled}
      />
      <div className="mt-2 flex gap-2">
        <Button size="sm" variant="success" disabled={disabled || busy} onClick={() => onDecide("approve", comment)}>
          <CheckCircle2 className="size-3.5" /> Approve action
        </Button>
        <Button size="sm" variant="danger" disabled={disabled || busy} onClick={() => onDecide("reject", comment)}>
          <Ban className="size-3.5" /> Reject action
        </Button>
      </div>
    </div>
  );
}
