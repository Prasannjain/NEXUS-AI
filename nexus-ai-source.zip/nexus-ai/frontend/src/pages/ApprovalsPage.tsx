import { useEffect, useMemo, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { clsx } from "clsx";
import {
  AlertTriangle,
  Ban,
  CheckCircle2,
  Clock,
  History,
  RefreshCw,
  Search,
  ShieldCheck,
  Wrench,
} from "lucide-react";
import { api, ApiError } from "../api/client";
import type { ApprovalItem } from "../api/types";
import {
  Badge,
  Button,
  Card,
  CardTitle,
  Code,
  EmptyState,
  ErrorNotice,
  LoadingPanel,
  Notice,
  RiskBadge,
  inputClass,
} from "../components/ui";
import { usePoll } from "../lib/hooks";
import { agentColor, formatDateTime, relativeTime, titleCase } from "../lib/format";
import { useToast } from "../state/ToastContext";
import { useAuth } from "../state/AuthContext";

function detailFields(approval: ApprovalItem): [string, string][] {
  const details = approval.details as Record<string, unknown>;
  const rows: [string, string][] = [
    ["Tool", approval.tool || String(details.tool ?? "—")],
    ["Required capability", approval.required_permission || String(details.required_permission ?? "—")],
    ["Side effect", approval.side_effect || String(details.side_effect ?? "—")],
    ["Auto-retry allowed", approval.retry_safe === undefined ? "—" : approval.retry_safe ? "yes (idempotent)" : "no — financial or irreversible"],
  ];
  const argumentsValue = details.arguments ?? details.payload ?? approval.details;
  rows.push(["Arguments", JSON.stringify(argumentsValue, null, 2)]);
  return rows;
}

export default function ApprovalsPage() {
  const toast = useToast();
  const { can } = useAuth();
  const [params, setParams] = useSearchParams();
  const [selected, setSelected] = useState<string | null>(params.get("focus"));
  const [comment, setComment] = useState("");
  const [busy, setBusy] = useState(false);
  const [showHistory, setShowHistory] = useState(false);

  const pending = usePoll(() => api.approvals("pending"), 5000, []);
  const all = usePoll(() => api.approvals(), 12000, []);
  const history = usePoll(() => api.approvalHistory(), 15000, []);

  const items = pending.data?.items ?? [];
  const current = useMemo(
    () => items.find((item) => item.id === selected) ?? all.data?.items.find((item) => item.id === selected) ?? null,
    [items, all.data, selected],
  );

  useEffect(() => {
    if (!selected && items.length) setSelected(items[0].id);
  }, [selected, items]);

  useEffect(() => {
    if (selected) setParams({ focus: selected }, { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selected]);

  async function decide(approval: ApprovalItem, action: "approve" | "reject") {
    setBusy(true);
    try {
      await api.decide(approval.id, action, comment.trim());
      toast.push(
        action === "approve"
          ? `${approval.workflow_id} resumed — the Execution Agent will perform the action.`
          : `${approval.workflow_id} rejected — the action is blocked and the requester was notified.`,
        action === "approve" ? "success" : "info",
      );
      setComment("");
      pending.reload();
      all.reload();
      history.reload();
    } catch (error) {
      toast.push(error instanceof ApiError ? error.detail : "The decision could not be recorded.", "error");
    } finally {
      setBusy(false);
    }
  }

  const decided = (all.data?.items ?? []).filter((item) => item.status !== "pending");

  return (
    <div className="space-y-4">
      <div className="grid gap-4 lg:grid-cols-[minmax(0,380px)_minmax(0,1fr)]">
        <Card padded={false} className="lg:sticky lg:top-20 lg:self-start">
          <div className="px-5 pt-5">
            <CardTitle
              icon={<ShieldCheck className="size-4" />}
              title="Approval queue"
              subtitle={`${pending.data?.pending ?? 0} waiting · ${decided.length} decided`}
              action={
                <button
                  type="button"
                  onClick={() => pending.reload()}
                  className="rounded-lg p-1.5 text-ink-faint transition hover:bg-surface-muted hover:text-ink"
                  aria-label="Refresh queue"
                >
                  <RefreshCw className="size-3.5" />
                </button>
              }
            />
          </div>
          <div className="max-h-[calc(100vh-260px)] space-y-2 overflow-y-auto px-4 pb-4">
            {pending.error ? (
              <div className="px-1">
                <ErrorNotice message={pending.error} onRetry={pending.reload} />
              </div>
            ) : pending.data === null ? (
              <LoadingPanel label="Loading checkpoints" />
            ) : items.length === 0 ? (
              <EmptyState
                title="Nothing awaits a decision"
                description="Sensitive actions pause automatically here when a workflow reaches a high or critical-risk tool."
              />
            ) : (
              items.map((approval) => (
                <button
                  key={approval.id}
                  type="button"
                  onClick={() => setSelected(approval.id)}
                  className={clsx(
                    "w-full rounded-xl border px-3 py-2.5 text-left transition",
                    selected === approval.id
                      ? "border-teal-400 bg-teal-50 dark:bg-teal-500/10"
                      : "border-line hover:border-line-strong hover:bg-surface-muted",
                  )}
                >
                  <div className="flex items-start justify-between gap-2">
                    <p className="text-[13px] font-semibold text-ink">{approval.action}</p>
                    <RiskBadge level={approval.risk_level} />
                  </div>
                  <p className="mt-1 flex flex-wrap items-center gap-2 font-mono text-[11px] text-ink-faint">
                    {approval.workflow_id}
                    <span className="font-sans">{approval.task_id}</span>
                  </p>
                  <p className="mt-1 flex items-center gap-2 text-[11px] text-ink-soft">
                    <span
                      className="rounded px-1.5 py-0.5 text-[10px] font-semibold"
                      style={{ background: `${agentColor(approval.agent_name)}1f`, color: agentColor(approval.agent_name) }}
                    >
                      {titleCase(approval.agent_name)}
                    </span>
                    <span className="inline-flex items-center gap-1">
                      <Clock className="size-3" /> {relativeTime(approval.requested_at)}
                    </span>
                  </p>
                </button>
              ))
            )}
          </div>
        </Card>

        {current ? (
          <div className="space-y-4">
            <Card>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <h2 className="text-base font-semibold text-ink">{current.action}</h2>
                    <RiskBadge level={current.risk_level} />
                    <Badge
                      className={
                        current.status === "pending"
                          ? "!bg-amber-100 !text-amber-800 dark:!bg-amber-500/15 dark:!text-amber-300"
                          : current.status === "approved"
                            ? "!bg-emerald-100 !text-emerald-800 dark:!bg-emerald-500/15 dark:!text-emerald-300"
                            : "!bg-rose-100 !text-rose-800 dark:!bg-rose-500/15 dark:!text-rose-300"
                      }
                    >
                      {current.status}
                    </Badge>
                  </div>
                  <p className="mt-1.5 text-[13px] text-ink-soft">{current.policy_reason}</p>
                </div>
                <Link
                  to={`/workflows/${current.workflow_id}`}
                  className="inline-flex items-center gap-1.5 rounded-xl border border-line px-3 py-1.5 text-xs font-medium text-ink-soft transition hover:bg-surface-muted"
                >
                  Open workflow <Code>{current.workflow_id}</Code>
                </Link>
              </div>

              <div className="mt-4 rounded-xl border border-line bg-surface-muted p-3 dark:bg-elevated/60">
                <p className="text-[11px] font-semibold tracking-wide text-ink-faint uppercase">Original request</p>
                <p className="mt-1 text-[13px] text-ink">{current.request_text || current.workflow_title}</p>
                <p className="mt-1.5 text-[11px] text-ink-faint">
                  Requested by <strong className="text-ink-soft">{current.requester}</strong> · agent{" "}
                  <strong className="text-ink-soft">{titleCase(current.agent_name)}</strong> · submitted{" "}
                  {formatDateTime(current.requested_at)}
                </p>
              </div>

              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                {detailFields(current).map(([label, value]) => (
                  <div key={label} className={clsx("rounded-xl border border-line px-3 py-2", label === "Arguments" && "sm:col-span-2")}>
                    <p className="text-[10px] font-semibold tracking-wide text-ink-faint uppercase">{label}</p>
                    {label === "Arguments" ? (
                      <pre className="mt-1 max-h-40 overflow-auto font-mono text-[11px] text-ink-soft">{value}</pre>
                    ) : (
                      <p className="mt-0.5 font-mono text-[12px] break-words text-ink">{value}</p>
                    )}
                  </div>
                ))}
              </div>

              {current.status === "pending" ? (
                <div className="mt-4 rounded-xl border border-amber-200 bg-amber-50/70 p-3 dark:border-amber-400/25 dark:bg-amber-500/10">
                  <p className="flex items-center gap-1.5 text-xs font-semibold text-amber-900 dark:text-amber-200">
                    <AlertTriangle className="size-3.5" /> The workflow is paused at this checkpoint
                  </p>
                  <p className="mt-1 text-[11px] text-amber-900/80 dark:text-amber-200/80">
                    Agents cannot proceed until an authorised human records a decision here. Approving grants only this
                    task the elevated capability — it does not change your role.
                  </p>
                  <textarea
                    className={clsx(inputClass, "mt-3 bg-surface")}
                    rows={2}
                    placeholder="Comment for the audit trail (recommended)…"
                    value={comment}
                    onChange={(event) => setComment(event.target.value)}
                  />
                  <div className="mt-2 flex flex-wrap items-center gap-2">
                    <Button variant="success" disabled={busy || !current.can_decide} onClick={() => void decide(current, "approve")}>
                      <CheckCircle2 className="size-4" /> Approve
                    </Button>
                    <Button variant="danger" disabled={busy || !current.can_decide} onClick={() => void decide(current, "reject")}>
                      <Ban className="size-4" /> Reject
                    </Button>
                    {!current.can_decide ? (
                      <p className="text-[11px] text-ink-faint">
                        Your role lacks <Code>{current.required_permission || "approvals.decide"}</Code>; an approver or
                        admin must decide.
                      </p>
                    ) : null}
                  </div>
                </div>
              ) : (
                <div className="mt-4 rounded-xl border border-line px-3 py-2.5 text-[13px]">
                  <p className="font-medium text-ink">
                    {current.status === "approved" ? "Approved" : "Rejected"} by {current.decided_by || "—"} ·{" "}
                    {formatDateTime(current.decided_at)}
                  </p>
                  {current.comment ? <p className="mt-1 text-ink-soft">“{current.comment}”</p> : null}
                  {current.status === "rejected" ? (
                    <p className="mt-1 text-[11px] text-ink-faint">
                      Dependent tasks were skipped and the requester was notified. The workflow is reported as rejected.
                    </p>
                  ) : null}
                </div>
              )}
            </Card>

            <Card>
              <CardTitle
                icon={<Wrench className="size-4" />}
                title="Approval history for this workflow"
                action={
                  <button
                    type="button"
                    onClick={() => setShowHistory((value) => !value)}
                    className="text-xs font-medium text-teal-600 hover:underline"
                  >
                    {showHistory ? "Hide" : "Show"}
                  </button>
                }
              />
              {showHistory ? (
                (history.data ?? []).filter((row) => row.workflow_id === current.workflow_id).length ? (
                  <ul className="space-y-2">
                    {(history.data ?? [])
                      .filter((row) => row.workflow_id === current.workflow_id)
                      .map((row) => (
                        <li key={row.id} className="flex items-start gap-3 rounded-xl border border-line px-3 py-2">
                          <History className="mt-0.5 size-3.5 shrink-0 text-ink-faint" />
                          <div className="min-w-0 flex-1">
                            <p className="text-[13px] text-ink">{row.action}</p>
                            <p className="mt-0.5 text-[11px] text-ink-faint">
                              {row.status} by {row.decided_by || "—"} · {formatDateTime(row.decided_at)}
                              {row.comment ? ` · “${row.comment}”` : ""}
                            </p>
                          </div>
                          <RiskBadge level={row.risk_level} />
                        </li>
                      ))}
                  </ul>
                ) : (
                  <EmptyState title="No recorded decisions for this workflow" />
                )
              ) : (
                <p className="text-[13px] text-ink-soft">
                  Show the full decision history, including comments, to audit who authorised what and when.
                </p>
              )}
            </Card>
          </div>
        ) : (
          <Card>
            <EmptyState
              title={can("approvals.decide") ? "Select a checkpoint" : "Approval queue is empty"}
              description="Sensitive operations raised by the Approval Agent appear here for an authorised decision."
            />
          </Card>
        )}
      </div>

      <Card>
        <CardTitle
          icon={<Search className="size-4" />}
          title="All recorded decisions"
          subtitle="Every checkpoint ever raised on this platform"
        />
        {(all.data?.items ?? []).length === 0 ? (
          <EmptyState title="No approvals yet" description="Start a workflow with a sensitive action to raise one." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[860px] text-left text-[12.5px]">
              <thead>
                <tr className="border-b border-line text-[10px] tracking-wide text-ink-faint uppercase">
                  <th className="py-2 pr-3 font-semibold">Workflow</th>
                  <th className="py-2 pr-3 font-semibold">Action</th>
                  <th className="py-2 pr-3 font-semibold">Agent</th>
                  <th className="py-2 pr-3 font-semibold">Risk</th>
                  <th className="py-2 pr-3 font-semibold">Status</th>
                  <th className="py-2 pr-3 font-semibold">Decided by</th>
                  <th className="py-2 font-semibold">Comment</th>
                </tr>
              </thead>
              <tbody>
                {(all.data?.items ?? []).map((row) => (
                  <tr
                    key={row.id}
                    className="cursor-pointer border-b border-line/60 last:border-0 hover:bg-surface-muted dark:hover:bg-elevated"
                    onClick={() => setSelected(row.id)}
                  >
                    <td className="py-2.5 pr-3 font-mono text-[11px] text-ink-soft">{row.workflow_id}</td>
                    <td className="py-2.5 pr-3 text-ink">{row.action}</td>
                    <td className="py-2.5 pr-3">
                      <span
                        className="rounded px-1.5 py-0.5 text-[10px] font-semibold"
                        style={{ background: `${agentColor(row.agent_name)}1f`, color: agentColor(row.agent_name) }}
                      >
                        {titleCase(row.agent_name)}
                      </span>
                    </td>
                    <td className="py-2.5 pr-3">
                      <RiskBadge level={row.risk_level} />
                    </td>
                    <td className="py-2.5 pr-3">
                      <Badge
                        className={
                          row.status === "approved"
                            ? "!bg-emerald-100 !text-emerald-800 dark:!bg-emerald-500/15 dark:!text-emerald-300"
                            : row.status === "rejected"
                              ? "!bg-rose-100 !text-rose-800 dark:!bg-rose-500/15 dark:!text-rose-300"
                              : "!bg-amber-100 !text-amber-800 dark:!bg-amber-500/15 dark:!text-amber-300"
                        }
                      >
                        {row.status}
                      </Badge>
                    </td>
                    <td className="py-2.5 pr-3 text-[11px] text-ink-soft">{row.decided_by || "—"}</td>
                    <td className="max-w-[260px] truncate py-2.5 text-[11px] text-ink-faint">{row.comment || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {!can("approvals.decide") ? (
        <Notice tone="info" title="Read-only for your role">
          You can inspect every checkpoint and its history, but only an approver or administrator can record a decision.
          Workflows stay paused until someone with <Code>approvals.decide</Code> acts.
        </Notice>
      ) : null}
    </div>
  );
}
