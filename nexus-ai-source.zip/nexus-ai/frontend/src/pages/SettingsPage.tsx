import { useState } from "react";
import { clsx } from "clsx";
import {
  Boxes,
  CheckCircle2,
  Cpu,
  Database,
  FileLock2,
  GitBranch,
  KeyRound,
  RefreshCw,
  ScrollText,
  ServerCog,
  ShieldAlert,
  ShieldCheck,
  SlidersHorizontal,
  TriangleAlert,
  Users2,
  XCircle,
} from "lucide-react";
import { api, ApiError } from "../api/client";
import type { ProviderHealth } from "../api/types";
import { useAsync } from "../lib/hooks";
import { useAuth } from "../state/AuthContext";
import { useToast } from "../state/ToastContext";
import { titleCase } from "../lib/format";
import {
  Badge,
  Button,
  Card,
  CardTitle,
  Code,
  ErrorNotice,
  LoadingPanel,
  Notice,
  Spinner,
  StatTile,
} from "../components/ui";

export default function SettingsPage() {
  const { can, user } = useAuth();
  const toast = useToast();
  const settings = useAsync(() => api.settings(), []);
  const roles = useAsync(() => api.roles(), []);
  const health = useAsync(() => api.health(), []);
  const architecture = useAsync(() => api.architecture(), []);

  const [switching, setSwitching] = useState("");
  const [testing, setTesting] = useState("");
  const [testResults, setTestResults] = useState<Record<string, ProviderHealth>>({});
  const [actionError, setActionError] = useState("");

  const canManage = can("settings.manage");

  async function switchProvider(provider: string) {
    setSwitching(provider);
    setActionError("");
    try {
      const result = await api.switchProvider(provider);
      toast.push(`Planner now uses ${result.provider}.`, "success");
      settings.reload();
      health.reload();
    } catch (error) {
      setActionError(error instanceof ApiError ? error.detail : "The provider switch failed.");
    } finally {
      setSwitching("");
    }
  }

  async function testProvider(provider: string) {
    setTesting(provider);
    setActionError("");
    try {
      const result = await api.testProvider(provider);
      setTestResults((current) => ({ ...current, [provider]: result }));
    } catch (error) {
      setActionError(error instanceof ApiError ? error.detail : "The provider test failed.");
    } finally {
      setTesting("");
    }
  }

  if (settings.loading) return <LoadingPanel label="Loading platform settings" />;
  if (settings.error) return <ErrorNotice message={settings.error} onRetry={settings.reload} />;

  const data = settings.data;
  if (!data) return null;

  return (
    <div className="space-y-5">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatTile
          label="Planner provider"
          value={titleCase(data.llm.provider)}
          hint={data.llm.provider === "none" ? "deterministic rule engine" : "LLM-assisted planning"}
          icon={<Cpu className="size-4" />}
          tone={data.llm.provider === "none" ? "navy" : "teal"}
        />
        <StatTile
          label="Database"
          value={data.platform.database.dialect}
          hint={data.platform.database.postgres ? "PostgreSQL backend" : "file-backed, swap via DATABASE_URL"}
          icon={<Database className="size-4" />}
          tone="violet"
        />
        <StatTile
          label="Queue"
          value={data.platform.database.redis ? "Redis" : "In-process"}
          hint={data.platform.database.redis_note}
          icon={<ServerCog className="size-4" />}
          tone="amber"
        />
        <StatTile
          label="Signed-in role"
          value={user?.role.name ?? "—"}
          hint={user?.role.description ?? ""}
          icon={<Users2 className="size-4" />}
          tone="green"
        />
      </div>

      {actionError ? <ErrorNotice message={actionError} onRetry={() => setActionError("")} /> : null}

      <Card>
        <CardTitle
          title="LLM provider"
          subtitle="Keys are read from the process environment; this screen never accepts or displays a secret."
          icon={<KeyRound className="size-4" />}
          action={
            <Button variant="secondary" size="sm" onClick={settings.reload}>
              <RefreshCw className="size-3.5" /> Refresh
            </Button>
          }
        />
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          {data.llm.providers.map((provider) => {
            const result = testResults[provider.name];
            return (
              <div
                key={provider.name}
                className={clsx(
                  "flex flex-col gap-2 rounded-xl border p-3.5 transition",
                  provider.active
                    ? "border-teal-400 bg-teal-50/60 dark:bg-teal-500/10"
                    : "border-line bg-surface dark:bg-elevated",
                )}
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-sm font-semibold text-ink">{provider.label}</p>
                    <p className="font-mono text-[11px] text-ink-faint">{provider.model}</p>
                  </div>
                  {provider.active ? <Badge tone="teal">active</Badge> : null}
                </div>

                <p className="flex items-center gap-1.5 text-[11px]">
                  {provider.configured ? (
                    <span className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-300">
                      <CheckCircle2 className="size-3.5" /> credentials present
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-ink-faint">
                      <XCircle className="size-3.5" />
                      {provider.key_env ? `set ${provider.key_env}` : "no key required"}
                    </span>
                  )}
                </p>

                {result ? (
                  <p
                    className={clsx(
                      "rounded-lg px-2 py-1.5 text-[11px]",
                      result.status === "online"
                        ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-500/15 dark:text-emerald-200"
                        : result.status === "offline_fallback"
                          ? "bg-slate-100 text-slate-700 dark:bg-slate-500/15 dark:text-slate-300"
                          : "bg-red-100 text-red-800 dark:bg-red-500/15 dark:text-red-200",
                    )}
                  >
                    <span className="font-semibold">{result.status}</span> · {result.detail}
                  </p>
                ) : null}

                <div className="mt-auto flex gap-2">
                  <Button
                    variant="secondary"
                    size="sm"
                    className="flex-1"
                    onClick={() => void testProvider(provider.name)}
                    disabled={testing === provider.name}
                  >
                    {testing === provider.name ? <Spinner /> : <Cpu className="size-3.5" />} Test
                  </Button>
                  <Button
                    size="sm"
                    className="flex-1"
                    onClick={() => void switchProvider(provider.name)}
                    disabled={!canManage || provider.active || switching === provider.name || (!provider.configured && provider.name !== "none")}
                    title={
                      !canManage
                        ? "Administrator role required"
                        : !provider.configured && provider.name !== "none"
                          ? `Set ${provider.key_env || "the provider key"} first`
                          : undefined
                    }
                  >
                    {switching === provider.name ? <Spinner /> : null}
                    {provider.active ? "In use" : "Use"}
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
        <p className="mt-3 text-[11px] text-ink-faint">{data.llm.note}</p>
        {!canManage ? (
          <div className="mt-3">
            <Notice title="Read-only view" tone="info">
              Your role ({user?.role.name}) cannot switch providers. Sign in as an administrator, or set
              <Code>LLM_PROVIDER</Code> in the environment before starting the API.
            </Notice>
          </div>
        ) : null}
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardTitle title="Orchestration" subtitle="Graph engine, retry budget and escalation target" icon={<GitBranch className="size-4" />} />
          <dl className="space-y-2 text-[13px]">
            <Row label="Engine" value={data.platform.orchestration.engine} />
            <Row label="Checkpoint store" value={<Code>{data.platform.orchestration.checkpoint_store}</Code>} />
            <Row label="Max attempts per task" value={String(data.platform.orchestration.max_task_attempts)} />
            <Row label="Retry base delay" value={`${data.platform.orchestration.retry_base_delay_seconds}s`} />
            <Row label="Backoff factor" value={`×${data.platform.orchestration.retry_backoff_factor} per attempt`} />
            <Row label="Escalation mailbox" value={<Code>{data.platform.orchestration.escalation_email}</Code>} />
          </dl>
          <p className="mt-3 text-[11px] text-ink-faint">
            Delays follow base × factor<sup>attempt</sup>; a task that exhausts its budget is escalated instead of
            silently retried.
          </p>
        </Card>

        <Card>
          <CardTitle title="Approval policy" subtitle="What forces a human checkpoint" icon={<ShieldAlert className="size-4" />} />
          <p className="mb-3 text-[13px] text-ink-soft">{data.platform.approval_policy.rule}</p>
          <Grouped title="Gated tools" items={data.platform.approval_policy.gated_tools} tone="amber" />
          <Grouped title="Never auto-retried" items={data.platform.approval_policy.never_auto_retried} tone="red" />
          <Grouped title="Irreversible (no rollback handler)" items={data.platform.approval_policy.irreversible} tone="red" />
        </Card>

        <Card>
          <CardTitle title="Security" subtitle="Authentication, secrets and audit posture" icon={<ShieldCheck className="size-4" />} />
          <dl className="space-y-2 text-[13px]">
            <Row label="Token type" value={data.platform.security.token_type} />
            <Row label="Token lifetime" value={`${data.platform.security.token_expiry_minutes} minutes`} />
            <Row label="Password hashing" value={data.platform.security.password_hash} />
            <Row label="Secrets source" value={data.platform.security.secrets_source} />
            <Row
              label="Audit trail"
              value={
                data.platform.security.audit_append_only ? (
                  <span className="inline-flex items-center gap-1.5 text-emerald-700 dark:text-emerald-300">
                    <FileLock2 className="size-3.5" /> append-only, no update or delete route
                  </span>
                ) : (
                  "mutable"
                )
              }
            />
            <Row label="Roles" value={data.platform.security.roles.map((role) => titleCase(role)).join(", ")} />
          </dl>
        </Card>

        <Card>
          <CardTitle title="Runtime health" subtitle="Live values from the API process" icon={<Boxes className="size-4" />} />
          {health.error ? (
            <ErrorNotice message={health.error} onRetry={health.reload} />
          ) : health.data ? (
            <dl className="space-y-2 text-[13px]">
              <Row
                label="Status"
                value={
                  <span className="inline-flex items-center gap-1.5">
                    <span
                      className={clsx(
                        "size-2 rounded-full",
                        health.data.status === "ok" ? "bg-emerald-500" : "bg-amber-400",
                      )}
                    />
                    {health.data.status} · v{health.data.version}
                  </span>
                }
              />
              <Row label="Environment" value={health.data.environment} />
              <Row label="Database" value={`${health.data.database} (${health.data.database_dialect})`} />
              <Row label="Planner provider" value={titleCase(health.data.llm_provider)} />
              <Row label="Orchestrator" value={health.data.orchestrator} />
              <Row label="Active runs" value={String(health.data.active_workflow_runs)} />
              <Row
                label="Integrations"
                value={
                  health.data.simulated_integrations ? (
                    <span className="inline-flex items-center gap-1.5 text-amber-700 dark:text-amber-300">
                      <TriangleAlert className="size-3.5" /> sandbox simulations only
                    </span>
                  ) : (
                    "live endpoints"
                  )
                }
              />
            </dl>
          ) : (
            <LoadingPanel label="Reading health" />
          )}
        </Card>
      </div>

      <Card>
        <CardTitle
          title="Role and permission matrix"
          subtitle="Tool-level authorisation: a tool runs only when the requester holds its required permission or an approver elevates it for that task."
          icon={<SlidersHorizontal className="size-4" />}
        />
        {roles.error ? (
          <ErrorNotice message={roles.error} onRetry={roles.reload} />
        ) : roles.loading ? (
          <LoadingPanel label="Loading roles" />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-[13px]">
              <thead className="bg-surface-muted text-[11px] tracking-wide text-ink-faint uppercase">
                <tr>
                  <th className="px-3 py-2 font-semibold">Role</th>
                  <th className="px-3 py-2 font-semibold">Users</th>
                  <th className="px-3 py-2 font-semibold">Capabilities</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {(roles.data ?? []).map((role) => (
                  <tr key={role.name} className="bg-surface align-top dark:bg-transparent">
                    <td className="px-3 py-3">
                      <p className="font-semibold text-ink">{titleCase(role.name)}</p>
                      <p className="mt-0.5 max-w-56 text-[11px] text-ink-soft">{role.description}</p>
                    </td>
                    <td className="px-3 py-3 text-ink-soft tabular-nums">{role.user_count}</td>
                    <td className="px-3 py-3">
                      <div className="flex max-w-3xl flex-wrap gap-1">
                        {role.permissions.map((permission) => (
                          <Code key={permission}>{permission}</Code>
                        ))}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Card>
        <CardTitle
          title="Orchestration pipeline reference"
          subtitle="The twelve stages every workflow moves through, in order"
          icon={<ScrollText className="size-4" />}
        />
        {architecture.error ? (
          <ErrorNotice message={architecture.error} onRetry={architecture.reload} />
        ) : (
          <ol className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
            {(architecture.data?.stages ?? []).map((stage, index) => (
              <li key={stage.key} className="flex gap-2.5 rounded-xl border border-line px-3 py-2">
                <span className="grid size-6 shrink-0 place-items-center rounded-lg bg-navy-900 text-[11px] font-semibold text-teal-100">
                  {index + 1}
                </span>
                <div className="min-w-0">
                  <p className="text-[13px] font-medium text-ink">{stage.label}</p>
                  <p className="text-[11px] text-ink-soft">{stage.description}</p>
                </div>
              </li>
            ))}
          </ol>
        )}
      </Card>

      <Notice title="Data and secrets" tone="warn">
        Counts on this page come from the live database: {data.counts.agents} agents, {data.counts.registered_tools}{" "}
        registered tools, {data.counts.workflows} workflows and {data.counts.pending_approvals} pending approvals.
        Switching to PostgreSQL and Redis is a configuration change only — set <Code>DATABASE_URL</Code> and{" "}
        <Code>REDIS_URL</Code> in the environment and restart the API.
      </Notice>
    </div>
  );
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-2 border-b border-dashed border-line pb-2 last:border-0">
      <dt className="text-[11px] tracking-wide text-ink-faint uppercase">{label}</dt>
      <dd className="text-right text-[13px] font-medium text-ink">{value}</dd>
    </div>
  );
}

function Grouped({ title, items, tone }: { title: string; items: string[]; tone: "amber" | "red" }) {
  return (
    <div className="mt-3">
      <p className="mb-1.5 text-[11px] tracking-wide text-ink-faint uppercase">{title}</p>
      <div className="flex flex-wrap gap-1.5">
        {items.length ? (
          items.map((item) => (
            <Badge key={item} tone={tone}>
              {item}
            </Badge>
          ))
        ) : (
          <span className="text-[11px] text-ink-faint">none</span>
        )}
      </div>
    </div>
  );
}
