import { useMemo, useState } from "react";
import { clsx } from "clsx";
import { Link } from "react-router-dom";
import {
  BarChart3,
  CheckCircle2,
  Clock3,
  Download,
  Eye,
  FileText,
  GaugeCircle,
  PieChart,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import { api, ApiError } from "../api/client";
import type { ReportItem } from "../api/types";
import { useAsync } from "../lib/hooks";
import { formatDateTime, formatDuration, formatNumber, titleCase } from "../lib/format";
import {
  Badge,
  Button,
  Card,
  CardTitle,
  EmptyState,
  ErrorNotice,
  LoadingPanel,
  Modal,
  Notice,
  Spinner,
  StatTile,
  StatusBadge,
  inputClass,
} from "../components/ui";
import { HorizontalBars, MultiColorBars, StatusDonut, VerticalBars } from "../components/charts";

export default function ReportsPage() {
  const [days, setDays] = useState(30);
  const [category, setCategory] = useState("");
  const [status, setStatus] = useState("");
  const [preview, setPreview] = useState<{ id: string; markdown: string } | null>(null);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [previewError, setPreviewError] = useState("");
  const [downloading, setDownloading] = useState("");

  const categories = useAsync(() => api.categories(), []);
  const reports = useAsync(
    () => api.reports({ days, category: category || undefined, status: status || undefined }),
    [days, category, status],
  );
  const analytics = useAsync(() => api.platformAnalytics(days), [days]);

  const totals = analytics.data?.totals;

  const toolLoad = useMemo(
    () => (analytics.data?.tool_load ?? []).slice().sort((a, b) => b.value - a.value).slice(0, 12),
    [analytics.data],
  );

  async function openPreview(item: ReportItem) {
    setPreviewLoading(true);
    setPreviewError("");
    setPreview(null);
    try {
      const markdown = await api.reportMarkdown(item.workflow_id);
      setPreview({ id: item.workflow_id, markdown });
    } catch (error) {
      setPreviewError(error instanceof ApiError ? error.detail : "The report could not be rendered.");
    } finally {
      setPreviewLoading(false);
    }
  }

  async function download(item: ReportItem) {
    setDownloading(item.workflow_id);
    try {
      await api.downloadReport(item.workflow_id);
    } catch (error) {
      setPreviewError(error instanceof ApiError ? error.detail : "The download failed.");
    } finally {
      setDownloading("");
    }
  }

  return (
    <div className="space-y-5">
      <Notice title="Every figure is derived from recorded runs">
        Reports are generated from the workflow, task, tool-call, approval and audit rows in this database. All
        underlying enterprise data is synthetic sandbox data, so no real customer, employee or financial record is
        summarised here.
      </Notice>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        <StatTile
          label="Reports"
          value={formatNumber(reports.data?.summary.reports)}
          hint={`last ${days} days`}
          icon={<FileText className="size-4" />}
          tone="navy"
        />
        <StatTile
          label="Success rate"
          value={`${reports.data?.summary.success_rate ?? 0}%`}
          hint={`${reports.data?.summary.completed ?? 0} clean runs`}
          icon={<GaugeCircle className="size-4" />}
          tone="green"
        />
        <StatTile
          label="Avg duration"
          value={formatDuration(reports.data?.summary.avg_duration_seconds)}
          hint="request to final report"
          icon={<Clock3 className="size-4" />}
          tone="teal"
        />
        <StatTile
          label="Approvals decided"
          value={formatNumber(reports.data?.summary.approvals_decided)}
          hint={`${reports.data?.summary.approvals_rejected ?? 0} rejected`}
          icon={<ShieldCheck className="size-4" />}
          tone="amber"
        />
        <StatTile
          label="Tool calls"
          value={formatNumber(totals?.tool_calls)}
          hint={`${formatNumber(totals?.agent_steps)} agent steps`}
          icon={<Sparkles className="size-4" />}
          tone="violet"
        />
      </div>

      <div className="flex flex-wrap items-end gap-3">
        <div className="flex gap-1.5">
          {[7, 30, 90].map((value) => (
            <button
              key={value}
              type="button"
              onClick={() => setDays(value)}
              className={clsx(
                "rounded-xl border px-3 py-1.5 text-xs font-medium transition",
                days === value
                  ? "border-teal-400 bg-teal-50 text-teal-800 dark:bg-teal-500/15 dark:text-teal-200"
                  : "border-line bg-surface text-ink-soft hover:bg-surface-muted dark:hover:bg-elevated",
              )}
            >
              {value} days
            </button>
          ))}
        </div>
        <select className={clsx(inputClass, "w-auto")} value={category} onChange={(event) => setCategory(event.target.value)} aria-label="Filter category">
          <option value="">All categories</option>
          {(categories.data?.categories ?? []).map((item) => (
            <option key={item.key} value={item.key}>
              {item.label}
            </option>
          ))}
        </select>
        <select className={clsx(inputClass, "w-auto")} value={status} onChange={(event) => setStatus(event.target.value)} aria-label="Filter status">
          <option value="">Any outcome</option>
          <option value="completed">Completed</option>
          <option value="completed_with_exceptions">Completed with exceptions</option>
          <option value="rejected">Rejected</option>
          <option value="failed">Failed</option>
        </select>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardTitle title="Run outcomes" subtitle="Workflow status distribution for the selected window" icon={<PieChart className="size-4" />} />
          {reports.data?.summary.by_status.length ? (
            <StatusDonut data={reports.data.summary.by_status} />
          ) : (
            <EmptyState title="No reports in this window" icon={<PieChart className="size-6" />} />
          )}
        </Card>
        <Card>
          <CardTitle title="Volume by category" subtitle="Which enterprise process is being automated" icon={<BarChart3 className="size-4" />} />
          {reports.data?.summary.by_category.length ? (
            <MultiColorBars data={reports.data.summary.by_category} />
          ) : (
            <EmptyState title="No category data yet" icon={<BarChart3 className="size-6" />} />
          )}
        </Card>
      </div>

      <div className="grid gap-4 xl:grid-cols-3">
        <Card>
          <CardTitle title="Task outcomes" subtitle="All planned steps across every workflow" icon={<CheckCircle2 className="size-4" />} />
          {analytics.data ? <StatusDonut data={analytics.data.task_status} height={200} /> : <LoadingPanel label="Loading analytics" />}
        </Card>
        <Card>
          <CardTitle title="Agent workload" subtitle="Reasoning steps recorded per agent" icon={<BarChart3 className="size-4" />} />
          {analytics.data ? <HorizontalBars data={analytics.data.agent_load} height={200} /> : <LoadingPanel />}
        </Card>
        <Card>
          <CardTitle title="Risk exposure" subtitle="Planned tasks grouped by risk classification" icon={<ShieldCheck className="size-4" />} />
          {analytics.data ? <VerticalBars data={analytics.data.risk_load} height={200} color="#f59e0b" name="Tasks" /> : <LoadingPanel />}
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardTitle title="Most-used tools" subtitle="Top sandbox calls in the selected window" icon={<Sparkles className="size-4" />} />
          {toolLoad.length ? <HorizontalBars data={toolLoad} height={280} color="#0d9488" /> : <EmptyState title="No tool calls recorded" />}
        </Card>
        <Card>
          <CardTitle title="Audit severity" subtitle="Signals available to compliance" icon={<ShieldCheck className="size-4" />} />
          {analytics.data ? <StatusDonut data={analytics.data.audit_severity} height={200} /> : <LoadingPanel />}
          <dl className="mt-3 grid grid-cols-2 gap-2 text-xs">
            <Metric label="Documents" value={formatNumber(totals?.documents)} />
            <Metric label="Approvals" value={formatNumber(totals?.approvals)} />
            <Metric label="Tasks" value={formatNumber(totals?.tasks)} />
            <Metric label="Audit entries" value={formatNumber(totals?.audit_entries)} />
          </dl>
        </Card>
      </div>

      <Card padded={false}>
        <div className="border-b border-line px-4 py-3">
          <CardTitle
            className="!mb-0"
            title="Downloadable final reports"
            subtitle="One report per finished workflow: plan, decisions, approvals, artefacts and exceptions"
            icon={<FileText className="size-4" />}
          />
        </div>
        {reports.loading ? (
          <LoadingPanel label="Loading reports" />
        ) : reports.error ? (
          <div className="p-4">
            <ErrorNotice message={reports.error} onRetry={reports.reload} />
          </div>
        ) : (reports.data?.items.length ?? 0) === 0 ? (
          <div className="p-6">
            <EmptyState
              title="No finished workflow to report on"
              description="Run a workflow from the Create Workflow page — a report is generated as soon as the graph reaches a terminal stage."
              action={
                <Link to="/workflows/new" className="text-xs font-medium text-teal-700 hover:underline dark:text-teal-300">
                  Create a workflow
                </Link>
              }
            />
          </div>
        ) : (
          <ul className="divide-y divide-line">
            {(reports.data?.items ?? []).map((item) => (
              <li key={item.workflow_id} className="flex flex-wrap items-start gap-3 px-4 py-3">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <Link
                      to={`/workflows/${item.workflow_id}`}
                      className="truncate text-sm font-semibold text-ink hover:text-teal-700 dark:hover:text-teal-300"
                    >
                      {item.title}
                    </Link>
                    <StatusBadge status={item.status} />
                    <Badge tone="navy">{titleCase(item.category)}</Badge>
                  </div>
                  <p className="mt-1 line-clamp-2 text-[13px] text-ink-soft">{item.headline}</p>
                  <p className="mt-1 flex flex-wrap gap-x-3 gap-y-1 text-[11px] text-ink-faint">
                    <span className="font-mono">{item.workflow_id}</span>
                    <span>{item.requester}</span>
                    <span>{formatDateTime(item.finished_at)}</span>
                    <span>{formatDuration(item.duration_seconds)}</span>
                  </p>
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  <Metric label="Tasks" value={`${item.tasks_completed}/${item.tasks_total}`} />
                  <Metric label="Tools" value={String(item.tool_calls)} />
                  <Metric label="Docs" value={String(item.documents)} />
                </div>
                <div className="flex w-full shrink-0 justify-end gap-2 sm:w-auto">
                  <Button variant="secondary" size="sm" onClick={() => void openPreview(item)} disabled={previewLoading}>
                    {previewLoading ? <Spinner /> : <Eye className="size-3.5" />} View
                  </Button>
                  <Button variant="secondary" size="sm" onClick={() => void download(item)} disabled={downloading === item.workflow_id}>
                    {downloading === item.workflow_id ? <Spinner /> : <Download className="size-3.5" />} Markdown
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Card>

      {previewError ? <ErrorNotice message={previewError} onRetry={() => setPreviewError("")} /> : null}

      <Modal
        open={preview !== null}
        onClose={() => setPreview(null)}
        title="Final report"
        subtitle={preview?.id ?? ""}
        width="max-w-3xl"
        footer={
          preview ? (
            <Button
              onClick={() =>
                void api
                  .downloadReport(preview.id)
                  .catch((error: unknown) => setPreviewError(error instanceof ApiError ? error.detail : "Download failed."))
              }
            >
              <Download className="size-4" /> Download .md
            </Button>
          ) : null
        }
      >
        <pre className="max-h-[60vh] overflow-auto rounded-xl border border-line bg-surface-muted p-3 text-[11px] leading-relaxed whitespace-pre-wrap text-ink-soft dark:bg-elevated">
          {preview?.markdown}
        </pre>
      </Modal>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-line px-2.5 py-1.5 text-center">
      <p className="text-[10px] tracking-wide text-ink-faint uppercase">{label}</p>
      <p className="text-[13px] font-semibold text-ink tabular-nums">{value}</p>
    </div>
  );
}
