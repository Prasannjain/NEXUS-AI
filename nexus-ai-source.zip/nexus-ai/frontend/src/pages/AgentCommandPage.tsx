import { useState } from "react";
import { clsx } from "clsx";
import { Activity, ArrowRight, CheckCircle2, Clock, ShieldAlert, Wrench } from "lucide-react";
import { api } from "../api/client";
import type { AgentDetail, AgentSummary } from "../api/types";
import {
  Badge,
  Button,
  Card,
  CardTitle,
  Code,
  EmptyState,
  ErrorNotice,
  LoadingPanel,
  Modal,
  RiskBadge,
} from "../components/ui";
import { useAsync } from "../lib/hooks";
import { agentColor, formatMs, relativeTime, titleCase } from "../lib/format";
import { agentIcon } from "../lib/icons";

const ROLE_NOTE: Record<string, string> = {
  planner: "Decomposes the request. Owns no business tools.",
  approval: "Evaluates policy and pauses the graph at sensitive actions.",
  execution: "Only agent that may invoke a registry tool for real.",
  audit: "Writes the append-only trail; read-only everywhere else.",
};

function AgentCard({ agent, onOpen }: { agent: AgentSummary; onOpen: () => void }) {
  const Icon = agentIcon(agent.icon);
  const color = agentColor(agent.color);
  const working = agent.status === "working";
  return (
    <Card
      className={clsx(
        "relative overflow-hidden",
        working && "ring-1 ring-teal-400/60",
        agent.status === "awaiting_approval" && "ring-1 ring-amber-400/60",
      )}
    >
      <span
        className="absolute inset-x-0 top-0 h-0.5"
        style={{ background: `linear-gradient(90deg, ${color}, transparent)` }}
      />
      <div className="flex items-start gap-3">
        <span
          className="grid size-11 shrink-0 place-items-center rounded-xl"
          style={{ background: `${color}1f`, color }}
          aria-hidden
        >
          <Icon className="size-5" />
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex items-center justify-between gap-2">
            <h3 className="truncate text-sm font-semibold text-ink">{agent.display_name}</h3>
            <Badge
              className={
                working
                  ? "!bg-teal-100 !text-teal-800 dark:!bg-teal-500/15 dark:!text-teal-300"
                  : agent.status === "awaiting_approval"
                    ? "!bg-amber-100 !text-amber-800 dark:!bg-amber-500/15 dark:!text-amber-300"
                    : agent.status === "failed"
                      ? "!bg-red-100 !text-red-800 dark:!bg-red-500/15 dark:!text-red-300"
                      : ""
              }
            >
              {working ? <span className="size-1.5 animate-pulse rounded-full bg-teal-500" /> : null}
              {titleCase(agent.status)}
            </Badge>
          </div>
          <p className="mt-1 text-xs leading-relaxed text-ink-soft">{agent.description}</p>
          {ROLE_NOTE[agent.name] ? (
            <p className="mt-1.5 text-[11px] text-ink-faint italic">{ROLE_NOTE[agent.name]}</p>
          ) : null}
        </div>
      </div>

      <div className="mt-3 flex flex-wrap gap-1.5">
        {agent.capabilities.map((capability) => (
          <span
            key={capability}
            className="rounded-md border border-line px-1.5 py-0.5 text-[10px] text-ink-soft"
          >
            {capability}
          </span>
        ))}
      </div>

      <div className="mt-3 grid grid-cols-3 gap-2 text-center">
        <div className="rounded-lg bg-surface-muted py-2 dark:bg-elevated">
          <p className="text-sm font-semibold tabular-nums text-ink">{agent.tasks_owned}</p>
          <p className="text-[10px] tracking-wide text-ink-faint uppercase">tasks</p>
        </div>
        <div className="rounded-lg bg-surface-muted py-2 dark:bg-elevated">
          <p className="text-sm font-semibold tabular-nums text-emerald-600 dark:text-emerald-400">
            {agent.tasks_completed}
          </p>
          <p className="text-[10px] tracking-wide text-ink-faint uppercase">done</p>
        </div>
        <div className="rounded-lg bg-surface-muted py-2 dark:bg-elevated">
          <p className="text-sm font-semibold tabular-nums text-red-600 dark:text-red-400">{agent.tasks_failed}</p>
          <p className="text-[10px] tracking-wide text-ink-faint uppercase">failed</p>
        </div>
      </div>

      <div className="mt-3 flex items-center justify-between border-t border-line pt-3">
        <p className="flex items-center gap-1.5 text-[11px] text-ink-faint">
          <Wrench className="size-3" /> {agent.allowed_tools.length} scoped tools
        </p>
        <Button size="sm" variant="ghost" onClick={onOpen}>
          Inspect <ArrowRight className="size-3.5" />
        </Button>
      </div>
    </Card>
  );
}

export default function AgentCommandPage() {
  const agents = useAsync(() => api.agents(), []);
  const [selected, setSelected] = useState<string | null>(null);
  const detail = useAsync<AgentDetail | null>(
    () => (selected ? api.agent(selected) : Promise.resolve(null)),
    [selected],
  );

  if (agents.error) return <ErrorNotice message={agents.error} onRetry={agents.reload} />;
  if (agents.loading || !agents.data) return <LoadingPanel label="Loading the agent roster" />;

  const orchestration = agents.data.filter((agent) => ["planner", "approval", "execution", "audit"].includes(agent.name));
  const workers = agents.data.filter((agent) => !orchestration.includes(agent));

  return (
    <div className="space-y-5">
      <Card>
        <CardTitle
          icon={<Activity className="size-4" />}
          title="Orchestration agents"
          subtitle="These four never touch enterprise data directly — they plan, gate, execute and record."
        />
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          {orchestration.map((agent) => (
            <AgentCard key={agent.name} agent={agent} onOpen={() => setSelected(agent.name)} />
          ))}
        </div>
      </Card>

      <Card>
        <CardTitle
          icon={<ShieldAlert className="size-4" />}
          title="Working agents"
          subtitle="Each agent receives only the tools and permissions its assigned tasks require."
        />
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {workers.map((agent) => (
            <AgentCard key={agent.name} agent={agent} onOpen={() => setSelected(agent.name)} />
          ))}
        </div>
      </Card>

      <Modal
        open={Boolean(selected)}
        onClose={() => setSelected(null)}
        title={detail.data?.display_name ?? selected ?? ""}
        subtitle={detail.data?.description}
        width="max-w-3xl"
      >
        {detail.loading ? (
          <LoadingPanel label="Loading agent detail" />
        ) : detail.error ? (
          <ErrorNotice message={detail.error} onRetry={detail.reload} />
        ) : detail.data ? (
          <div className="space-y-5">
            <div className="grid gap-3 sm:grid-cols-4">
              {[
                ["Executions", detail.data.executions],
                ["Tasks owned", detail.data.tasks_owned],
                ["Completed", detail.data.tasks_completed],
                ["Success rate", detail.data.success_rate === null ? "—" : `${detail.data.success_rate.toFixed(0)}%`],
              ].map(([label, value]) => (
                <div key={String(label)} className="rounded-xl border border-line px-3 py-2">
                  <p className="text-[10px] tracking-wide text-ink-faint uppercase">{label}</p>
                  <p className="text-lg font-semibold tabular-nums text-ink">{value}</p>
                </div>
              ))}
            </div>

            <div>
              <p className="mb-2 text-xs font-semibold tracking-wide text-ink-soft uppercase">
                Authorised tools ({detail.data.tools.length})
              </p>
              <div className="max-h-60 space-y-1.5 overflow-y-auto pr-1">
                {detail.data.tools.map((tool) => (
                  <div
                    key={tool.name}
                    className="flex items-center justify-between gap-3 rounded-lg border border-line px-3 py-2"
                  >
                    <div className="min-w-0">
                      <p className="truncate text-[13px] text-ink">{tool.display_name}</p>
                      <Code>{tool.name}</Code>
                    </div>
                    <div className="flex shrink-0 items-center gap-2">
                      <Badge tone="neutral">{tool.required_permission}</Badge>
                      <RiskBadge level={tool.risk_level} />
                      {tool.requires_approval ? <Badge tone="amber">approval</Badge> : null}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <p className="mb-2 text-xs font-semibold tracking-wide text-ink-soft uppercase">Recent decisions</p>
              {detail.data.recent_executions.length ? (
                <ul className="max-h-56 space-y-2 overflow-y-auto pr-1">
                  {detail.data.recent_executions.map((row) => (
                    <li key={row.id} className="rounded-lg bg-surface-muted px-3 py-2 dark:bg-elevated">
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-mono text-[11px] text-ink-faint">{row.workflow_id}</span>
                        <span className="flex items-center gap-1 text-[11px] text-ink-faint">
                          <Clock className="size-3" />
                          {formatMs(row.duration_ms)} · {relativeTime(row.created_at)}
                        </span>
                      </div>
                      <p className="mt-1 text-xs text-ink-soft">{row.decision || row.node}</p>
                      {row.status !== "completed" ? (
                        <p className="mt-1 flex items-center gap-1 text-[11px] text-red-600 dark:text-red-400">
                          <CheckCircle2 className="size-3" /> {row.status}
                        </p>
                      ) : null}
                    </li>
                  ))}
                </ul>
              ) : (
                <EmptyState title="No recorded decisions" description="This agent has not acted in any workflow yet." />
              )}
            </div>
          </div>
        ) : null}
      </Modal>
    </div>
  );
}
