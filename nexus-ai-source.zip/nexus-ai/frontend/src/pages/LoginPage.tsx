import { useEffect, useState, type FormEvent } from "react";
import { Bot, Eye, EyeOff, LogIn, ShieldCheck, Sparkles, Workflow } from "lucide-react";
import { api } from "../api/client";
import type { DemoAccounts } from "../api/types";
import { Button, ErrorNotice, Field, inputClass } from "../components/ui";
import { useAuth } from "../state/AuthContext";
import { useToast } from "../state/ToastContext";

export default function LoginPage() {
  const { signIn } = useAuth();
  const toast = useToast();
  const [email, setEmail] = useState("admin@nexus-ai.example");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [demo, setDemo] = useState<DemoAccounts | null>(null);

  useEffect(() => {
    api.demoAccounts().then(setDemo).catch(() => setDemo(null));
  }, []);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const person = await signIn(email.trim(), password);
      toast.push(`Signed in as ${person.full_name} (${person.role.name}).`, "success");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Sign-in failed.");
      setBusy(false);
    }
  }

  return (
    <div className="grid min-h-screen bg-canvas lg:grid-cols-[1.05fr_1fr]">
      <aside className="gradient-brand relative hidden flex-col justify-between overflow-hidden p-10 lg:flex">
        <div className="pointer-events-none absolute -top-24 -right-24 size-96 rounded-full bg-teal-400/20 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-32 -left-16 size-96 rounded-full bg-blue-400/20 blur-3xl" />
        <div className="relative">
          <div className="flex items-center gap-3">
            <span className="grid size-11 place-items-center rounded-2xl bg-white/15 text-white ring-1 ring-white/25">
              <Bot className="size-6" />
            </span>
            <div>
              <p className="text-lg leading-tight font-bold text-white">NEXUS AI</p>
              <p className="text-xs text-teal-100/80">Autonomous AI Agents for Enterprise Operations</p>
            </div>
          </div>
          <h2 className="mt-12 max-w-lg text-3xl leading-tight font-bold text-white">
            Multi-agent workflows that stop for a human before anything sensitive happens.
          </h2>
          <p className="mt-4 max-w-md text-sm text-teal-50/80">
            A LangGraph orchestrator delegates work to specialised agents, gates every high-risk operation behind an
            approval checkpoint, and writes the entire decision trail to an append-only audit log.
          </p>
        </div>
        <ul className="relative mt-10 grid gap-3 text-sm text-teal-50/90">
          <li className="flex items-center gap-2.5">
            <Sparkles className="size-4 text-teal-200" /> Planner Agent decomposes natural-language requests into
            dependency-ordered tasks
          </li>
          <li className="flex items-center gap-2.5">
            <Workflow className="size-4 text-teal-200" /> Live 12-stage monitor with retry, backoff and rollback
          </li>
          <li className="flex items-center gap-2.5">
            <ShieldCheck className="size-4 text-teal-200" /> Role-based approvals the agents cannot bypass
          </li>
        </ul>
        <p className="relative mt-10 text-[11px] text-teal-100/60">
          Sandbox platform — all enterprise integrations are simulated adapters. No live HR, finance or CRM system is
          touched.
        </p>
      </aside>

      <main className="flex items-center justify-center px-5 py-12">
        <div className="w-full max-w-md">
          <div className="mb-8 flex items-center gap-3 lg:hidden">
            <span className="gradient-brand grid size-10 place-items-center rounded-xl text-white">
              <Bot className="size-5" />
            </span>
            <div>
              <p className="text-base font-bold text-ink">NEXUS AI</p>
              <p className="text-[11px] text-ink-faint">Autonomous Enterprise Operations</p>
            </div>
          </div>

          <h1 className="text-2xl font-bold tracking-tight text-ink">Sign in</h1>
          <p className="mt-1.5 text-sm text-ink-soft">
            Use a demo identity to see how permissions change what an agent can do.
          </p>

          <form onSubmit={onSubmit} className="mt-7 space-y-4">
            <Field label="Work email" required>
              <input
                className={inputClass}
                type="email"
                autoComplete="username"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                placeholder="you@nexus-ai.example"
                required
              />
            </Field>
            <Field label="Password" required>
              <div className="relative">
                <input
                  className={`${inputClass} pr-10`}
                  type={showPassword ? "text" : "password"}
                  autoComplete="current-password"
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                  placeholder="••••••••••"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((value) => !value)}
                  className="absolute top-1/2 right-2 -translate-y-1/2 rounded-lg p-1.5 text-ink-faint hover:bg-surface-muted"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                </button>
              </div>
            </Field>

            {error ? <ErrorNotice message={error} /> : null}

            <Button type="submit" disabled={busy || password.length < 4} className="w-full">
              {busy ? <LogIn className="size-4 animate-pulse" /> : <LogIn className="size-4" />}
              {busy ? "Signing in…" : "Sign in to NEXUS"}
            </Button>
          </form>

          {demo ? (
            <div className="card-surface mt-8 p-4">
              <div className="flex items-center justify-between">
                <p className="text-xs font-semibold tracking-wide text-ink-soft uppercase">Demo identities</p>
                <code className="rounded-md bg-surface-muted px-1.5 py-0.5 font-mono text-[11px] text-teal-700 dark:bg-elevated dark:text-teal-300">
                  {demo.password}
                </code>
              </div>
              <div className="mt-3 grid gap-2 sm:grid-cols-2">
                {demo.accounts.map((account) => (
                  <button
                    key={account.email}
                    type="button"
                    onClick={() => {
                      setEmail(account.email);
                      setPassword(demo?.password ?? "");
                    }}
                    className="rounded-xl border border-line px-3 py-2 text-left transition hover:border-teal-300 hover:bg-teal-50/60 dark:hover:bg-teal-500/10"
                  >
                    <p className="text-xs font-semibold text-ink capitalize">{account.role}</p>
                    <p className="truncate text-[11px] text-ink-soft">{account.name}</p>
                    <p className="truncate text-[10px] text-ink-faint">{account.email}</p>
                  </button>
                ))}
              </div>
              <p className="mt-3 text-[11px] leading-snug text-ink-faint">
                Selecting an identity fills the form. Operators can start workflows but cannot clear their own approval
                checkpoints; approvers and admins can.
              </p>
            </div>
          ) : null}
        </div>
      </main>
    </div>
  );
}
