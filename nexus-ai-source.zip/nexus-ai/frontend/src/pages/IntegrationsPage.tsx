import { useMemo, useState } from "react";
import { clsx } from "clsx";
import {
  Activity,
  Banknote,
  Cable,
  CheckCircle2,
  FileText,
  Headphones,
  IdCard,
  Laptop,
  Link2,
  Mail,
  PlugZap,
  RefreshCw,
  Settings2,
  ShieldAlert,
  Users,
  Wrench,
  XCircle,
} from "lucide-react";
import { api, ApiError } from "../api/client";
import type { ConnectionStatus, IntegrationInfo, IntegrationTestResult } from "../api/types";
import { useAsync } from "../lib/hooks";
import { useAuth } from "../state/AuthContext";
import { useToast } from "../state/ToastContext";
import { formatDateTime, relativeTime, titleCase } from "../lib/format";
import {
  Badge,
  Button,
  Card,
  Code,
  ErrorNotice,
  Field,
  LoadingPanel,
  Modal,
  Notice,
  Spinner,
  Toggle,
  inputClass,
} from "../components/ui";

const STATUS_META: Record<ConnectionStatus, { label: string; dot: string; tone: string }> = {
  connected: { label: "Connected", dot: "bg-emerald-500", tone: "text-emerald-700 dark:text-emerald-300" },
  degraded: { label: "Degraded", dot: "bg-amber-400", tone: "text-amber-700 dark:text-amber-300" },
  disabled: { label: "Disabled", dot: "bg-slate-400", tone: "text-slate-600 dark:text-slate-300" },
  disconnected: { label: "Disconnected", dot: "bg-red-500", tone: "text-red-700 dark:text-red-300" },
};

const SYSTEM_ICON: Record<string, typeof Users> = {
  human_resources: Users,
  documents: FileText,
  it: Laptop,
  finance: Banknote,
  crm: Headphones,
  notifications: Mail,
};

export default function IntegrationsPage() {
  const { data, error, loading, reload } = useAsync(() => api.integrations(), []);
  const { can } = useAuth();
  const toast = useToast();

  const [detail, setDetail] = useState<IntegrationInfo | null>(null);
  const [configure, setConfigure] = useState<IntegrationInfo | null>(null);
  const [testing, setTesting] = useState("");
  const [testResult, setTestResult] = useState<IntegrationTestResult | null>(null);
  const [busyTool, setBusyTool] = useState("");

  const summary = useMemo(() => {
    const items = data ?? [];
    return {
      total: items.length,
      connected: items.filter((item) => item.connection_status === "connected").length,
      tools: items.reduce((sum, item) => sum + item.tool_count, 0),
      enabled: items.reduce((sum, item) => sum + item.enabled_tools, 0),
    };
  }, [data]);

  async function runTest(integration: IntegrationInfo) {
    setTesting(integration.key);
    setTestResult(null);
    try {
      const result = await api.testIntegration(integration.key);
      setTestResult(result);
      toast.push(`${integration.name}: sandbox connectivity check finished`, "success");
    } catch (err) {
      toast.push(err instanceof ApiError ? err.detail : "Connection test failed.", "error");
    } finally {
      setTesting("");
    }
  }

  async function toggleTool(name: string, enabled: boolean) {
    setBusyTool(name);
    try {
      await api.updateTool(name, { enabled });
      toast.push(`${name} ${enabled ? "enabled" : "disabled"}`, "success");
      setDetail((current) =>
        current
          ? { ...current, tools: current.tools.map((tool) => (tool.name === name ? { ...tool, enabled } : tool)) }
          : current,
      );
      reload();
    } catch (err) {
      toast.push(err instanceof ApiError ? err.detail : "Could not update the tool.", "error");
    } finally {
      setBusyTool("");
    }
  }

  if (loading) return <LoadingPanel label="Loading enterprise applications" />;
  if (error) return <ErrorNotice message={error} onRetry={reload} />;

  const items = data ?? [];

  return (
    <div className="space-y-5">
      <Notice title="Simulated sandbox integrations" tone="warn">
        Every application below is a synthetic sandbox with fabricated data. NEXUS AI never contacts a production
        ERP, HR, ITSM, finance or CRM system, and no result shown here was written to a real enterprise application.
      </Notice>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Stat icon={<Cable className="size-4" />} label="Applications" value={summary.total} hint="registered endpoints" />
        <Stat
          icon={<Activity className="size-4" />}
          label="Connected"
          value={`${summary.connected}/${summary.total}`}
          hint="sandbox endpoints reachable"
        />
        <Stat icon={<Wrench className="size-4" />} label="Tools" value={summary.tools} hint="across all systems" />
        <Stat icon={<CheckCircle2 className="size-4" />} label="Enabled" value={summary.enabled} hint="available to agents" />
      </div>

      <div className="grid gap-4 md:grid-cols-2 2xl:grid-cols-3">
        {items.map((integration) => (
          <ApplicationCard
            key={integration.key}
            integration={integration}
            onOpen={() => setDetail(integration)}
            onConfigure={() => {
              setConfigure(integration);
              setTestResult(null);
            }}
            onTest={() => runTest(integration)}
            testing={testing === integration.key}
            canManage={can("integrations.manage")}
          />
        ))}
      </div>

      <DetailModal
        integration={detail}
        onClose={() => setDetail(null)}
        canManage={can("tools.manage")}
        busyTool={busyTool}
        onToggleTool={toggleTool}
      />

      {configure ? (
        <ConfigureModal
          key={configure.key}
          integration={configure}
          onClose={() => setConfigure(null)}
          result={testResult?.integration === configure.key ? testResult : null}
          onSaved={() => {
            setConfigure(null);
            reload();
          }}
        />
      ) : null}
    </div>
  );
}

function Stat({ icon, label, value, hint }: { icon: React.ReactNode; label: string; value: React.ReactNode; hint: string }) {
  return (
    <Card className="!p-4">
      <div className="flex items-center gap-3">
        <span className="grid size-9 place-items-center rounded-xl bg-navy-50 text-navy-700 dark:bg-navy-500/15 dark:text-navy-200">
          {icon}
        </span>
        <div className="min-w-0">
          <p className="text-[11px] font-semibold tracking-[0.08em] text-ink-faint uppercase">{label}</p>
          <p className="text-lg font-semibold text-ink tabular-nums">{value}</p>
          <p className="truncate text-[11px] text-ink-soft">{hint}</p>
        </div>
      </div>
    </Card>
  );
}

function ApplicationCard({
  integration,
  onOpen,
  onConfigure,
  onTest,
  testing,
  canManage,
}: {
  integration: IntegrationInfo;
  onOpen: () => void;
  onConfigure: () => void;
  onTest: () => void;
  testing: boolean;
  canManage: boolean;
}) {
  const status = STATUS_META[integration.connection_status] ?? STATUS_META.disconnected;
  const Icon = SYSTEM_ICON[integration.system_type] ?? PlugZap;
  return (
    <Card className="flex flex-col gap-3">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <span className="grid size-10 place-items-center rounded-xl bg-gradient-to-br from-navy-800 to-teal-600 text-white shadow-sm">
            <Icon className="size-5" />
          </span>
          <div>
            <h3 className="text-[15px] font-semibold text-ink">{integration.name}</h3>
            <p className="text-xs text-ink-soft">{titleCase(integration.system_type)}</p>
          </div>
        </div>
        <span className={clsx("flex items-center gap-1.5 text-xs font-medium", status.tone)}>
          <span className={clsx("size-2 rounded-full", status.dot)} />
          {status.label}
        </span>
      </div>

      <p className="text-[13px] text-ink-soft">{integration.description}</p>

      <div className="flex items-center gap-1.5 text-[11px] text-ink-faint">
        <Link2 className="size-3.5 shrink-0" />
        <span className="truncate font-mono">{integration.base_url}</span>
      </div>

      <div className="flex flex-wrap gap-1.5">
        {integration.available_operations.map((operation) => (
          <Badge key={operation} tone="neutral">
            {operation}
          </Badge>
        ))}
      </div>

      <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
        {integration.required_permissions.map((permission) => (
          <Code key={permission}>{permission}</Code>
        ))}
      </div>

      <dl className="grid grid-cols-2 gap-2 rounded-xl bg-surface-muted p-3 text-xs dark:bg-elevated">
        <div>
          <dt className="text-ink-faint">Tools enabled</dt>
          <dd className="font-semibold text-ink tabular-nums">
            {integration.enabled_tools} / {integration.tool_count}
          </dd>
        </div>
        <div>
          <dt className="text-ink-faint">Last activity</dt>
          <dd className="font-semibold text-ink">{relativeTime(integration.last_activity_at)}</dd>
        </div>
      </dl>

      <div className="mt-auto flex flex-wrap gap-2 border-t border-line pt-3">
        <Button variant="secondary" size="sm" onClick={onOpen}>
          Inspect
        </Button>
        <Button variant="secondary" size="sm" onClick={onTest} disabled={testing}>
          {testing ? <Spinner /> : <RefreshCw className="size-3.5" />} Test connection
        </Button>
        <Button variant="ghost" size="sm" onClick={onConfigure} disabled={!canManage} title={canManage ? "" : "Administrator only"}>
          <Settings2 className="size-3.5" /> Configure
        </Button>
      </div>
    </Card>
  );
}

function DetailModal({
  integration,
  onClose,
  canManage,
  busyTool,
  onToggleTool,
}: {
  integration: IntegrationInfo | null;
  onClose: () => void;
  canManage: boolean;
  busyTool: string;
  onToggleTool: (name: string, enabled: boolean) => void;
}) {
  if (!integration) return null;
  return (
    <Modal
      open
      onClose={onClose}
      title={integration.name}
      subtitle={`Sandbox endpoint ${integration.base_url}`}
      width="max-w-3xl"
    >
      <div className="space-y-4">
        <div className="grid gap-3 sm:grid-cols-3">
          <Info label="System type" value={titleCase(integration.system_type)} />
          <Info label="Connection" value={integration.connection_status} />
          <Info label="Last activity" value={formatDateTime(integration.last_activity_at)} />
        </div>

        <div>
          <p className="mb-2 text-xs font-semibold tracking-wide text-ink-soft uppercase">
            Authorised tools ({integration.tools.length})
          </p>
          <div className="overflow-hidden rounded-xl border border-line">
            <table className="w-full text-left text-[13px]">
              <thead className="bg-surface-muted text-[11px] tracking-wide text-ink-faint uppercase">
                <tr>
                  <th className="px-3 py-2 font-semibold">Tool</th>
                  <th className="px-3 py-2 font-semibold">Side effect</th>
                  <th className="px-3 py-2 font-semibold">Risk</th>
                  <th className="px-3 py-2 font-semibold">Approval</th>
                  <th className="px-3 py-2 text-right font-semibold">Enabled</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {integration.tools.map((tool) => (
                  <tr key={tool.name} className="bg-surface dark:bg-elevated">
                    <td className="px-3 py-2">
                      <p className="font-medium text-ink">{tool.display_name}</p>
                      <p className="font-mono text-[11px] text-ink-faint">{tool.name}</p>
                    </td>
                    <td className="px-3 py-2">
                      <Badge tone={tool.side_effect === "financial" ? "red" : tool.side_effect === "write" ? "amber" : "neutral"}>
                        {tool.side_effect}
                      </Badge>
                    </td>
                    <td className="px-3 py-2">
                      <Badge
                        tone={
                          tool.risk_level === "critical"
                            ? "red"
                            : tool.risk_level === "high"
                              ? "amber"
                              : tool.risk_level === "medium"
                                ? "navy"
                                : "green"
                        }
                      >
                        {tool.risk_level}
                      </Badge>
                    </td>
                    <td className="px-3 py-2">
                      {tool.requires_approval ? (
                        <span className="inline-flex items-center gap-1 text-amber-700 dark:text-amber-300">
                          <ShieldAlert className="size-3.5" /> required
                        </span>
                      ) : (
                        <span className="text-ink-faint">auto</span>
                      )}
                    </td>
                    <td className="px-3 py-2 text-right">
                      <div className="inline-flex items-center gap-2">
                        {busyTool === tool.name ? <Spinner className="text-ink-faint" /> : null}
                        <Toggle
                          checked={tool.enabled}
                          disabled={!canManage || busyTool === tool.name}
                          label={`Toggle ${tool.name}`}
                          onChange={(value) => onToggleTool(tool.name, value)}
                        />
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {!canManage ? (
            <p className="mt-2 text-[11px] text-ink-faint">
              Sign in as an administrator to enable or disable tools for this application.
            </p>
          ) : null}
        </div>
      </div>
    </Modal>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-line px-3 py-2">
      <p className="text-[11px] tracking-wide text-ink-faint uppercase">{label}</p>
      <p className="text-sm font-medium text-ink">{value}</p>
    </div>
  );
}

function ConfigureModal({
  integration,
  onClose,
  onSaved,
  result,
}: {
  integration: IntegrationInfo;
  onClose: () => void;
  onSaved: () => void;
  result: IntegrationTestResult | null;
}) {
  const toast = useToast();
  const [status, setStatus] = useState<ConnectionStatus>(integration.connection_status);
  const [config, setConfig] = useState(() => JSON.stringify(integration.config ?? {}, null, 2));
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState("");

  async function save() {
    let parsed: Record<string, unknown>;
    try {
      parsed = config.trim() ? (JSON.parse(config) as Record<string, unknown>) : {};
    } catch {
      setFormError("Configuration must be valid JSON, for example { \"region\": \"eu-central-1\" }.");
      return;
    }
    setFormError("");
    setSaving(true);
    try {
      await api.updateIntegration(integration.key, { connection_status: status, config: parsed });
      toast.push(`${integration.name} reconfigured`, "success");
      onSaved();
    } catch (err) {
      setFormError(err instanceof ApiError ? err.detail : "Could not save the configuration.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal
      open
      onClose={onClose}
      title={`Configure ${integration.name}`}
      subtitle="Changes are recorded in the append-only audit trail"
      width="max-w-2xl"
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={save} disabled={saving}>
            {saving ? <Spinner /> : <CheckCircle2 className="size-4" />} Save configuration
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        {formError ? <ErrorNotice message={formError} /> : null}

        <Field label="Connection status">
          <select
            className={inputClass}
            value={status}
            onChange={(event) => setStatus(event.target.value as ConnectionStatus)}
          >
            <option value="connected">Connected — tools may execute in the sandbox</option>
            <option value="degraded">Degraded — retries and escalations are expected</option>
            <option value="disabled">Disabled — agents cannot call this application</option>
          </select>
        </Field>

        <Field label="Configuration (JSON)" hint="Endpoint overrides, timeouts, sandbox credentials placeholders.">
          <textarea
            className={clsx(inputClass, "min-h-32 font-mono text-xs")}
            value={config}
            onChange={(event) => setConfig(event.target.value)}
            spellCheck={false}
          />
        </Field>

        <div className="rounded-xl border border-line p-3">
          <p className="mb-2 flex items-center gap-2 text-xs font-semibold text-ink">
            <IdCard className="size-3.5 text-teal-600" /> Connection test
          </p>
          {result ? (
            <div className="space-y-2">
              <p className="text-[11px] text-ink-soft">{result.note}</p>
              <div className="grid gap-1.5 sm:grid-cols-2">
                {result.tools.map((tool) => (
                  <div
                    key={tool.tool}
                    className="flex items-center justify-between gap-2 rounded-lg bg-surface-muted px-2.5 py-1.5 text-[11px] dark:bg-elevated"
                  >
                    <span className="truncate font-mono text-ink-soft">{tool.tool}</span>
                    <span className="flex items-center gap-1.5">
                      {tool.adapter_available ? (
                        <span className="text-emerald-600 dark:text-emerald-400">
                          <CheckCircle2 className="size-3.5" />
                        </span>
                      ) : (
                        <span className="text-red-500">
                          <XCircle className="size-3.5" />
                        </span>
                      )}
                      <Badge tone={tool.enabled ? "teal" : "neutral"}>{tool.enabled ? "enabled" : "off"}</Badge>
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <p className="text-[11px] text-ink-soft">
              Use “Test connection” on the application card to ping the sandbox adapter for every tool.
            </p>
          )}
        </div>
      </div>
    </Modal>
  );
}
