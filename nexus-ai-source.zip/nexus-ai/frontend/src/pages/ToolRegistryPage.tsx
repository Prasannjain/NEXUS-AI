import { useMemo, useState } from "react";
import { clsx } from "clsx";
import {
  ArrowDownUp,
  Check,
  FileJson2,
  Plus,
  RefreshCw,
  Search,
  ShieldAlert,
  ShieldCheck,
  Wrench,
  Zap,
} from "lucide-react";
import { api, ApiError } from "../api/client";
import type { IntegrationInfo, ToolInfo, ToolValidation } from "../api/types";
import { useAsync, useDebounced } from "../lib/hooks";
import { useAuth } from "../state/AuthContext";
import { useToast } from "../state/ToastContext";
import { relativeTime, titleCase } from "../lib/format";
import {
  Badge,
  Button,
  Card,
  Code,
  EmptyState,
  ErrorNotice,
  Field,
  LoadingPanel,
  Modal,
  Notice,
  RiskBadge,
  Spinner,
  StatTile,
  Toggle,
  inputClass,
} from "../components/ui";

type SortKey = "name" | "risk" | "integration";

const RISK_ORDER = { low: 0, medium: 1, high: 2, critical: 3 } as const;

const DEFAULT_SCHEMA = `{
  "type": "object",
  "required": ["reference_id"],
  "properties": {
    "reference_id": { "type": "string" },
    "note": { "type": "string" }
  },
  "additionalProperties": true
}`;

export default function ToolRegistryPage() {
  const { can } = useAuth();
  const toast = useToast();
  const tools = useAsync(() => api.tools(), []);
  const integrations = useAsync(() => api.integrations(), []);

  const [search, setSearch] = useState("");
  const query = useDebounced(search, 220);
  const [integrationFilter, setIntegrationFilter] = useState("all");
  const [riskFilter, setRiskFilter] = useState("all");
  const [stateFilter, setStateFilter] = useState("all");
  const [sort, setSort] = useState<SortKey>("name");
  const [selected, setSelected] = useState<ToolInfo | null>(null);
  const [validation, setValidation] = useState<ToolValidation | null>(null);
  const [validating, setValidating] = useState(false);
  const [registerOpen, setRegisterOpen] = useState(false);
  const [busy, setBusy] = useState("");
  const [syncing, setSyncing] = useState(false);

  const canManage = can("tools.manage");

  const integrationNames = useMemo(() => {
    const map = new Map<string, string>();
    for (const item of integrations.data ?? []) map.set(item.key, item.name);
    return map;
  }, [integrations.data]);

  function integrationLabel(key: string): string {
    return integrationNames.get(key) ?? titleCase(key);
  }

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    const list = (tools.data ?? []).filter((tool) => {
      if (integrationFilter !== "all" && tool.integration !== integrationFilter) return false;
      if (riskFilter !== "all" && tool.risk_level !== riskFilter) return false;
      if (stateFilter === "enabled" && !tool.enabled) return false;
      if (stateFilter === "disabled" && tool.enabled) return false;
      if (stateFilter === "approval" && !tool.requires_approval) return false;
      if (stateFilter === "financial" && tool.side_effect !== "financial") return false;
      if (!needle) return true;
      return (
        tool.name.toLowerCase().includes(needle) ||
        tool.display_name.toLowerCase().includes(needle) ||
        tool.description.toLowerCase().includes(needle) ||
        tool.required_permission.toLowerCase().includes(needle) ||
        tool.agent_scope.some((agent) => agent.includes(needle))
      );
    });
    return [...list].sort((a, b) => {
      if (sort === "risk") return RISK_ORDER[b.risk_level] - RISK_ORDER[a.risk_level] || a.name.localeCompare(b.name);
      if (sort === "integration") return a.integration.localeCompare(b.integration) || a.name.localeCompare(b.name);
      return a.name.localeCompare(b.name);
    });
  }, [tools.data, query, integrationFilter, riskFilter, stateFilter, sort]);

  const counts = useMemo(() => {
    const list = tools.data ?? [];
    return {
      total: list.length,
      enabled: list.filter((tool) => tool.enabled).length,
      gated: list.filter((tool) => tool.requires_approval || tool.risk_level === "high" || tool.risk_level === "critical").length,
      adapters: list.filter((tool) => tool.has_adapter).length,
    };
  }, [tools.data]);

  async function toggle(tool: ToolInfo, enabled: boolean) {
    setBusy(tool.name);
    try {
      const updated = await api.updateTool(tool.name, { enabled });
      toast.push(`${tool.name} ${enabled ? "enabled" : "disabled"} — the change is recorded in the audit trail.`, "success");
      tools.reload();
      setSelected((current) => (current && current.name === tool.name ? updated : current));
    } catch (error) {
      toast.push(error instanceof ApiError ? error.detail : "The registry update failed.", "error");
    } finally {
      setBusy("");
    }
  }

  async function toggleApproval(tool: ToolInfo, requiresApproval: boolean) {
    setBusy(tool.name);
    try {
      await api.updateTool(tool.name, { requires_approval: requiresApproval });
      toast.push(
        requiresApproval
          ? `${tool.name} now requires a human checkpoint before execution.`
          : `${tool.name} no longer raises a checkpoint.`,
        "info",
      );
      tools.reload();
      setSelected((current) => (current && current.name === tool.name ? { ...current, requires_approval: requiresApproval } : current));
    } catch (error) {
      toast.push(error instanceof ApiError ? error.detail : "The registry update failed.", "error");
    } finally {
      setBusy("");
    }
  }

  async function validate(tool: ToolInfo) {
    setValidating(true);
    setValidation(null);
    try {
      setValidation(await api.validateTool(tool.name));
    } catch (error) {
      toast.push(error instanceof ApiError ? error.detail : "Validation failed.", "error");
    } finally {
      setValidating(false);
    }
  }

  async function resync() {
    setSyncing(true);
    try {
      const result = await api.syncTools();
      toast.push(`Registry resynchronised: ${result.tools} tools across ${result.integrations} applications.`, "success");
      tools.reload();
      integrations.reload();
    } catch (error) {
      toast.push(error instanceof ApiError ? error.detail : "Resynchronisation failed.", "error");
    } finally {
      setSyncing(false);
    }
  }

  if (tools.loading) return <LoadingPanel label="Loading the tool registry" />;
  if (tools.error) return <ErrorNotice message={tools.error} onRetry={tools.reload} />;

  return (
    <div className="space-y-5">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatTile label="Registered tools" value={counts.total} hint="schemas stored in the database" icon={<Wrench className="size-4" />} tone="navy" />
        <StatTile label="Enabled" value={counts.enabled} hint="callable by the Execution Agent" icon={<Check className="size-4" />} tone="green" />
        <StatTile label="Approval-gated" value={counts.gated} hint="high risk or explicit checkpoint" icon={<ShieldAlert className="size-4" />} tone="amber" />
        <StatTile label="With sandbox adapter" value={counts.adapters} hint="rest execute against simulated data" icon={<Zap className="size-4" />} tone="teal" />
      </div>

      <Notice title="How the registry gates agents">
        A tool only runs when it is enabled, the calling agent is inside its <Code>agent_scope</Code>, the requester
        (or the approved elevation) holds its <Code>required_permission</Code>, and its arguments validate against the
        stored JSON schema. Tools marked <Code>requires_approval</Code> always pause the graph for a human decision.
      </Notice>

      <Card padded={false}>
        <div className="flex flex-wrap items-center gap-3 border-b border-line px-4 py-3">
          <div className="relative min-w-56 flex-1">
            <Search className="pointer-events-none absolute top-2.5 left-3 size-4 text-ink-faint" />
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search name, capability, permission or agent scope…"
              className={clsx(inputClass, "pl-9")}
              aria-label="Search tools"
            />
          </div>

          <select
            value={integrationFilter}
            onChange={(event) => setIntegrationFilter(event.target.value)}
            className={clsx(inputClass, "w-auto")}
            aria-label="Filter by application"
          >
            <option value="all">All applications</option>
            {(integrations.data ?? []).map((item: IntegrationInfo) => (
              <option key={item.key} value={item.key}>
                {item.name}
              </option>
            ))}
          </select>

          <select
            value={riskFilter}
            onChange={(event) => setRiskFilter(event.target.value)}
            className={clsx(inputClass, "w-auto")}
            aria-label="Filter by risk"
          >
            <option value="all">Any risk</option>
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
            <option value="critical">Critical</option>
          </select>

          <select
            value={stateFilter}
            onChange={(event) => setStateFilter(event.target.value)}
            className={clsx(inputClass, "w-auto")}
            aria-label="Filter by state"
          >
            <option value="all">Any state</option>
            <option value="enabled">Enabled only</option>
            <option value="disabled">Disabled only</option>
            <option value="approval">Requires approval</option>
            <option value="financial">Financial side effect</option>
          </select>

          <div className="flex items-center gap-1.5">
            <ArrowDownUp className="size-3.5 text-ink-faint" />
            <select
              value={sort}
              onChange={(event) => setSort(event.target.value as SortKey)}
              className={clsx(inputClass, "w-auto")}
              aria-label="Sort tools"
            >
              <option value="name">Sort A–Z</option>
              <option value="risk">Highest risk first</option>
              <option value="integration">By application</option>
            </select>
          </div>

          <div className="ml-auto flex flex-wrap gap-2">
            <Button variant="secondary" size="sm" onClick={resync} disabled={syncing || !canManage} title={canManage ? "" : "Administrator only"}>
              {syncing ? <Spinner /> : <RefreshCw className="size-3.5" />} Resynchronise
            </Button>
            <Button size="sm" onClick={() => setRegisterOpen(true)} disabled={!canManage} title={canManage ? "" : "Administrator only"}>
              <Plus className="size-3.5" /> Register tool
            </Button>
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="p-6">
            <EmptyState
              title="No tool matches these filters"
              description="Clear the search box or widen the application and risk filters to see the rest of the registry."
              icon={<Wrench className="size-6" />}
            />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-[13px]">
              <thead className="bg-surface-muted text-[11px] tracking-wide text-ink-faint uppercase">
                <tr>
                  <th className="px-4 py-2.5 font-semibold">Tool</th>
                  <th className="px-3 py-2.5 font-semibold">Application</th>
                  <th className="px-3 py-2.5 font-semibold">Agent scope</th>
                  <th className="px-3 py-2.5 font-semibold">Permission</th>
                  <th className="px-3 py-2.5 font-semibold">Effect</th>
                  <th className="px-3 py-2.5 font-semibold">Risk</th>
                  <th className="px-3 py-2.5 font-semibold">Approval</th>
                  <th className="px-3 py-2.5 font-semibold">Retry</th>
                  <th className="px-3 py-2.5 font-semibold">Last used</th>
                  <th className="px-4 py-2.5 text-right font-semibold">Enabled</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {filtered.map((tool) => (
                  <tr
                    key={tool.name}
                    className="cursor-pointer bg-surface transition hover:bg-surface-muted dark:bg-transparent dark:hover:bg-elevated"
                    onClick={() => {
                      setSelected(tool);
                      setValidation(null);
                      void validate(tool);
                    }}
                  >
                    <td className="px-4 py-2.5">
                      <p className="font-medium text-ink">{tool.display_name}</p>
                      <p className="font-mono text-[11px] text-ink-faint">{tool.name}</p>
                    </td>
                    <td className="px-3 py-2.5 text-ink-soft">{integrationLabel(tool.integration)}</td>
                    <td className="px-3 py-2.5">
                      <div className="flex flex-wrap gap-1">
                        {tool.agent_scope.map((agent) => (
                          <Badge key={agent} tone="navy">
                            {agent}
                          </Badge>
                        ))}
                      </div>
                    </td>
                    <td className="px-3 py-2.5">
                      <Code>{tool.required_permission}</Code>
                    </td>
                    <td className="px-3 py-2.5">
                      <Badge tone={tool.side_effect === "financial" ? "red" : tool.side_effect === "write" ? "amber" : "neutral"}>
                        {tool.side_effect}
                      </Badge>
                    </td>
                    <td className="px-3 py-2.5">
                      <RiskBadge level={tool.risk_level} />
                    </td>
                    <td className="px-3 py-2.5">
                      {tool.requires_approval ? (
                        <span className="inline-flex items-center gap-1 text-[12px] font-medium text-amber-700 dark:text-amber-300">
                          <ShieldAlert className="size-3.5" /> gate
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[12px] text-ink-faint">
                          <ShieldCheck className="size-3.5" /> auto
                        </span>
                      )}
                    </td>
                    <td className="px-3 py-2.5 text-[12px]">
                      {tool.retry_safe ? (
                        <span className="text-emerald-700 dark:text-emerald-300">safe</span>
                      ) : (
                        <span className="font-medium text-red-600 dark:text-red-300">never auto</span>
                      )}
                    </td>
                    <td className="px-3 py-2.5 text-[12px] text-ink-soft">{relativeTime(tool.last_used_at)}</td>
                    <td className="px-4 py-2.5 text-right" onClick={(event) => event.stopPropagation()}>
                      <span className="inline-flex items-center gap-2">
                        {busy === tool.name ? <Spinner className="text-ink-faint" /> : null}
                        <Toggle
                          checked={tool.enabled}
                          disabled={!canManage || busy === tool.name}
                          label={`Toggle ${tool.name}`}
                          onChange={(value) => void toggle(tool, value)}
                        />
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <p className="border-t border-line px-4 py-2 text-[11px] text-ink-faint">
          Showing {filtered.length} of {(tools.data ?? []).length} registered tools. Select a row to inspect its schema and run
          validation against a sample payload.
        </p>
      </Card>

      <Modal
        open={selected !== null}
        onClose={() => setSelected(null)}
        title={selected ? selected.display_name : ""}
        subtitle={selected ? selected.name : ""}
        width="max-w-3xl"
      >
        {selected ? (
          <div className="space-y-4">
            <p className="text-[13px] text-ink-soft">{selected.description}</p>

            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
              <Cell label="Application" value={integrationLabel(selected.integration)} />
              <Cell label="Connection" value={selected.connection_status} />
              <Cell label="Required permission" value={selected.required_permission} />
              <Cell label="Side effect" value={selected.side_effect} />
              <Cell label="Risk level" value={selected.risk_level} />
              <Cell label="Reversible" value={selected.reversible ? "yes — rollback handler exists" : "no — manual remediation"} />
              <Cell label="Auto-retry allowed" value={selected.retry_safe ? "yes (exponential backoff)" : "no — idempotency gated"} />
              <Cell label="Produces documents" value={selected.produces_documents ? "yes" : "no"} />
              <Cell label="Sandbox adapter" value={selected.has_adapter ? "registered" : "not implemented"} />
            </div>

            <div className="flex flex-wrap items-center gap-3 rounded-xl border border-line px-3 py-2.5">
              <span className="flex items-center gap-2 text-xs text-ink-soft">
                <Toggle
                  checked={selected.enabled}
                  disabled={!canManage || busy === selected.name}
                  label={`Enable ${selected.name}`}
                  onChange={(value) => {
                    void toggle(selected, value);
                    setSelected((current) => (current ? { ...current, enabled: value } : current));
                  }}
                />
                Enabled
              </span>
              <span className="flex items-center gap-2 text-xs text-ink-soft">
                <Toggle
                  checked={selected.requires_approval}
                  disabled={!canManage || busy === selected.name}
                  label={`Approval for ${selected.name}`}
                  onChange={(value) => void toggleApproval(selected, value)}
                />
                Requires human approval
              </span>
              {!canManage ? <span className="text-[11px] text-ink-faint">Administrator role required to edit.</span> : null}
            </div>

            <div>
              <p className="mb-1.5 flex items-center gap-2 text-xs font-semibold tracking-wide text-ink-soft uppercase">
                <FileJson2 className="size-3.5" /> Input schema
              </p>
              <pre className="max-h-64 overflow-auto rounded-xl bg-navy-950 p-3 font-mono text-[11px] leading-relaxed text-teal-100">
                {JSON.stringify(selected.input_schema, null, 2)}
              </pre>
            </div>

            <div>
              <div className="mb-2 flex items-center justify-between gap-2">
                <p className="text-xs font-semibold tracking-wide text-ink-soft uppercase">Schema validation</p>
                <Button variant="secondary" size="sm" onClick={() => void validate(selected)} disabled={validating}>
                  {validating ? <Spinner /> : <Check className="size-3.5" />} Validate sample payload
                </Button>
              </div>
              {validation ? (
                <div className="space-y-2">
                  {validation.schema_valid ? (
                    <Notice title="Sample payload validates against the schema" tone="success">
                      Catalog definition: {validation.catalog_definition ? "known" : "operator-registered"} · adapter:{" "}
                      {validation.adapter_available ? "available" : "not implemented"} · required fields:{" "}
                      {validation.required_fields.length ? validation.required_fields.join(", ") : "none"}
                    </Notice>
                  ) : (
                    <div className="space-y-1">
                      {validation.errors.map((message) => (
                        <ErrorNotice key={message} message={message} />
                      ))}
                    </div>
                  )}
                  <pre className="overflow-auto rounded-xl border border-line p-2.5 font-mono text-[11px] text-ink-soft">
                    {JSON.stringify(validation.sample_payload, null, 2)}
                  </pre>
                </div>
              ) : (
                <p className="text-[11px] text-ink-faint">
                  Validation builds a synthetic payload from the schema’s required fields — no enterprise record is read or
                  written.
                </p>
              )}
            </div>

            <div>
              <p className="mb-1.5 text-xs font-semibold tracking-wide text-ink-soft uppercase">Agents authorised to call this tool</p>
              <div className="flex flex-wrap gap-1.5">
                {selected.agent_scope.length ? (
                  selected.agent_scope.map((agent) => (
                    <Badge key={agent} tone="teal">
                      {titleCase(agent)} Agent
                    </Badge>
                  ))
                ) : (
                  <span className="text-[11px] text-ink-faint">No agent scope — the planner will never assign this tool.</span>
                )}
              </div>
            </div>
          </div>
        ) : null}
      </Modal>

      <RegisterModal
        open={registerOpen}
        onClose={() => setRegisterOpen(false)}
        integrations={integrations.data ?? []}
        onCreated={() => {
          setRegisterOpen(false);
          tools.reload();
        }}
      />
    </div>
  );
}

function Cell({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-line px-3 py-2">
      <p className="text-[11px] tracking-wide text-ink-faint uppercase">{label}</p>
      <p className="text-[13px] font-medium text-ink">{value}</p>
    </div>
  );
}

function RegisterModal({
  open,
  onClose,
  integrations,
  onCreated,
}: {
  open: boolean;
  onClose: () => void;
  integrations: IntegrationInfo[];
  onCreated: () => void;
}) {
  const toast = useToast();
  const [form, setForm] = useState({
    name: "",
    display_name: "",
    description: "",
    integration_key: integrations[0]?.key ?? "",
    required_permission: "tools.execute",
    risk_level: "low",
    side_effect: "read",
    enabled: false,
    requires_approval: false,
    retry_safe: true,
    reversible: true,
    agent_scope: "",
    input_schema: DEFAULT_SCHEMA,
  });
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState("");

  function set<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  async function submit() {
    let schema: Record<string, unknown>;
    try {
      schema = JSON.parse(form.input_schema) as Record<string, unknown>;
    } catch {
      setFormError("The input schema must be valid JSON Schema.");
      return;
    }
    if (!form.name.trim() || !form.display_name.trim()) {
      setFormError("Tool name and display name are required.");
      return;
    }
    setFormError("");
    setSaving(true);
    try {
      await api.registerTool({
        name: form.name.trim(),
        display_name: form.display_name.trim(),
        description: form.description.trim(),
        integration_key: form.integration_key || integrations[0]?.key || "",
        required_permission: form.required_permission.trim() || "tools.execute",
        input_schema: schema,
        enabled: form.enabled,
        risk_level: form.risk_level,
        side_effect: form.side_effect,
        requires_approval: form.requires_approval,
        retry_safe: form.retry_safe,
        reversible: form.reversible,
        agent_scope: form.agent_scope
          .split(",")
          .map((value) => value.trim())
          .filter(Boolean),
      });
      toast.push(`${form.name} registered in the catalog.`, "success");
      onCreated();
    } catch (error) {
      setFormError(error instanceof ApiError ? error.detail : "Registration failed.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Register a new tool"
      subtitle="New tools are disabled until you enable them; a financial or high-risk tool must keep approval on."
      width="max-w-3xl"
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={submit} disabled={saving}>
            {saving ? <Spinner /> : <Plus className="size-4" />} Register tool
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        {formError ? <ErrorNotice message={formError} /> : null}

        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Technical name" required hint="lowercase, dots allowed — e.g. warehouse.sync_inventory">
            <input className={inputClass} value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="crm.close_ticket" />
          </Field>
          <Field label="Display name" required>
            <input className={inputClass} value={form.display_name} onChange={(e) => set("display_name", e.target.value)} placeholder="Close support ticket" />
          </Field>
        </div>

        <Field label="Description">
          <input className={inputClass} value={form.description} onChange={(e) => set("description", e.target.value)} placeholder="What the tool does in the sandbox" />
        </Field>

        <div className="grid gap-3 sm:grid-cols-3">
          <Field label="Application">
            <select
              className={inputClass}
              value={form.integration_key || integrations[0]?.key || ""}
              onChange={(e) => set("integration_key", e.target.value)}
            >
              {integrations.map((item) => (
                <option key={item.key} value={item.key}>
                  {item.name}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Required permission">
            <input className={inputClass} value={form.required_permission} onChange={(e) => set("required_permission", e.target.value)} />
          </Field>
          <Field label="Agent scope" hint="comma separated: hr, it, finance">
            <input className={inputClass} value={form.agent_scope} onChange={(e) => set("agent_scope", e.target.value)} placeholder="support" />
          </Field>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Risk level">
            <select className={inputClass} value={form.risk_level} onChange={(e) => set("risk_level", e.target.value)}>
              <option value="low">low</option>
              <option value="medium">medium</option>
              <option value="high">high</option>
              <option value="critical">critical</option>
            </select>
          </Field>
          <Field label="Side effect">
            <select className={inputClass} value={form.side_effect} onChange={(e) => set("side_effect", e.target.value)}>
              <option value="read">read</option>
              <option value="write">write</option>
              <option value="financial">financial</option>
            </select>
          </Field>
        </div>

        <Field label="Input schema (JSON Schema)" required hint="Validated with Draft 2020-12 before the tool is stored.">
          <textarea
            className={clsx(inputClass, "min-h-40 font-mono text-[11px]")}
            value={form.input_schema}
            onChange={(e) => set("input_schema", e.target.value)}
            spellCheck={false}
          />
        </Field>

        <div className="flex flex-wrap gap-4 rounded-xl bg-surface-muted px-3 py-2.5 dark:bg-elevated">
          <FlagToggle label="Enabled" checked={form.enabled} onChange={(value) => set("enabled", value)} />
          <FlagToggle label="Requires approval" checked={form.requires_approval} onChange={(value) => set("requires_approval", value)} />
          <FlagToggle label="Safe to auto-retry" checked={form.retry_safe} onChange={(value) => set("retry_safe", value)} />
          <FlagToggle label="Reversible" checked={form.reversible} onChange={(value) => set("reversible", value)} />
        </div>

        {form.side_effect === "financial" && form.retry_safe ? (
          <Notice title="Financial side effect with auto-retry enabled" tone="warn">
            Set “Safe to auto-retry” to off for payments. NEXUS AI replays an idempotency key, but an unverified financial
            write must never be retried automatically.
          </Notice>
        ) : null}
      </div>
    </Modal>
  );
}

function FlagToggle({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (value: boolean) => void;
}) {
  return (
    <span className="flex items-center gap-2 text-xs text-ink-soft">
      <Toggle checked={checked} onChange={onChange} label={label} />
      {label}
    </span>
  );
}
