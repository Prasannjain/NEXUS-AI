import { Link } from "react-router-dom";
import {
  Activity,
  ArrowRight,
  Bot,
  CheckCircle2,
  Clock,
  FileText,
  Gauge,
  Plus,
  ScrollText,
  ShieldCheck,
  Sparkles,
  XCircle,
} from "lucide-react";
import { api } from "../api/client";
import type { ApprovalItem, WorkflowSummary } from "../api/types";
import { Badge, Card, CardTitle, EmptyState, ErrorNotice, LoadingPanel, Progress, StatTile, StatusBadge } from "../components/ui";
import { HorizontalBars, MultiColorBars, StatusDonut, TrendAreaChart } from "../components/charts";
import { useAsync, usePoll } from "../lib/hooks";
import { formatDuration, formatNumber, relativeTime, titleCase } from "../lib/format";

function short(value: string, size = 64): string {
  return value.length > size ? `${value.slice(0, size - 1)}…` : value;
}

function WorkflowRow({ workflow }: { workflow: WorkflowSummary }) {
  const done = workflow.task_counts.completed ?? 0;
  const total = workflow.task_counts.total ?? 0;
  return (
    <Link
      to={`/workflows/${workflow.id}`}
      className="grid grid-cols-[1fr_auto] items-center gap-3 border-b border-line px-1 py-3 transition last:border-0 hover:bg-surface-muted sm:grid-cols-[minmax(0,2.2fr)_minmax(0,1.1fr)_auto_auto] dark:hover:bg-elevated"
    >
      <div className="min-w-0">
        <p className="truncate text-[13px] font-medium text-ink">{short(workflow.title, 84)}</p>
        <p className="mt-0.5 flex items-center gap-2 text-[11px] text-ink-faint">
          <span className="font-mono">{workflow.id}</span>
          <span aria-hidden>·</span>
          <span>{relativeTime(workflow.created_at)}</span>
        </p>
      </div>
      <div className="hidden min-w-0 sm:block">
        <p className="truncate text-xs text-ink-soft">{workflow.current_stage || "Queued"}</p>
        <p className="mt-1 text-[11px] text-ink-faint">
          {done}/{total} tasks
          {workflow.active_agent ? ` · ${titleCase(workflow.active_agent)}` : ""}
        </p>
      </div>
      <div className="hidden w-28 sm:block">
        <Progress value={workflow.progress} tone={workflow.status === "failed" ? "red" : "teal"} />
        <p className="mt-1 text-right text-[10px] text-ink-faint">{workflow.progress.toFixed(0)}%</p>
      </div>
      <StatusBadge status={workflow.status} />
    </Link>
  );
}

export default function OverviewPage() {
  const stats = useAsync(() => api.dashboard(), []);
  const pending = usePoll(() => api.approvals("pending"), 10000, []);
  const recent = usePoll(() => api.workflows({ limit: 8 }), 8000, []);

  if (stats.error) return <ErrorNotice message={stats.error} onRetry={stats.reload} />;
  if (stats.loading || !stats.data) return <LoadingPanel label="Loading the platform overview" />;

  const counters = stats.data.counters;
  const approvals = pending.data?.items ?? [];

  return (
    <div className="space-y-5">
      <div className="gradient-brand relative overflow-hidden rounded-2xl px-5 py-5 text-white shadow-lg sm:px-7">
        <div className="pointer-events-none absolute -top-16 -right-10 size-64 rounded-full bg-teal-400/20 blur-3xl" />
        <div className="relative flex flex-wrap items-center justify-between gap-4">
          <div className="min-w-0">
            <p className="text-[11px] font-semibold tracking-[0.18em] text-teal-200/80 uppercase">
              NEXUS AI control plane
            </p>
            <h2 className="mt-1 text-xl font-bold sm:text-2xl">
              {counters.active_workflows > 0
                ? `${counters.active_workflows} workflow${counters.active_workflows > 1 ? "s" : ""} running right now`
                : "Autonomous agents standing by"}
            </h2>
            <p className="mt-1.5 max-w-2xl text-[13px] text-teal-50/80">
              {counters.total_workflows} workflow{counters.total_workflows === 1 ? "" : "s"} orchestrated ·{" "}
              {counters.audit_entries} audit entries · {counters.generated_documents} documents generated. Sensitive
              actions pause for a human and run only against simulated enterprise systems.
            </p>
          </div>
          <Link
            to="/workflows/new"
            className="inline-flex shrink-0 items-center gap-2 rounded-xl bg-white px-4 py-2.5 text-sm font-semibold text-navy-900 shadow-md transition hover:bg-teal-50"
          >
            <Plus className="size-4" />
            Create New Workflow
          </Link>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-6">
        <StatTile
          label="Total workflows"
          value={formatNumber(counters.total_workflows)}
          hint={`${counters.completed_workflows} completed`}
          icon={<Activity className="size-5" />}
          tone="navy"
        />
        <StatTile
          label="Active now"
          value={formatNumber(counters.active_workflows)}
          hint={counters.active_workflows ? "LangGraph nodes executing" : "No live runs"}
          icon={<Sparkles className="size-5" />}
          tone="teal"
        />
        <StatTile
          label="Completed"
          value={formatNumber(counters.completed_workflows)}
          hint={`${counters.generated_documents} artefacts produced`}
          icon={<CheckCircle2 className="size-5" />}
          tone="green"
        />
        <StatTile
          label="Failed / rejected"
          value={formatNumber(counters.failed_workflows + counters.rejected_workflows)}
          hint={`${counters.failed_workflows} failed · ${counters.rejected_workflows} rejected`}
          icon={<XCircle className="size-5" />}
          tone="red"
        />
        <StatTile
          label="Pending approvals"
          value={formatNumber(counters.pending_approvals)}
          hint={counters.pending_approvals ? "Paused at a checkpoint" : "Queue is clear"}
          icon={<ShieldCheck className="size-5" />}
          tone="amber"
        />
        <StatTile
          label="Agents online"
          value={`${counters.active_agents}/${counters.total_agents}`}
          hint={`${counters.enabled_tools}/${counters.total_tools} tools enabled`}
          icon={<Bot className="size-5" />}
          tone="violet"
        />
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.6fr_1fr]">
        <Card>
          <CardTitle
            icon={<Gauge className="size-4" />}
            title="Workflow volume"
            subtitle="Requests submitted per day"
            action={
              <div className="flex items-center gap-2">
                <Badge tone="teal">success {counters.success_rate.toFixed(0)}%</Badge>
                <Badge tone="neutral">
                  <Clock className="size-3" /> avg {formatDuration(counters.avg_duration_seconds)}
                </Badge>
              </div>
            }
          />
          <TrendAreaChart data={stats.data.daily_trend} />
        </Card>

        <Card>
          <CardTitle title="Status mix" subtitle="Every workflow the platform has orchestrated" />
          {stats.data.status_breakdown.length ? (
            <StatusDonut data={stats.data.status_breakdown} />
          ) : (
            <EmptyState title="No workflows yet" description="Create the first workflow to populate the dashboard." />
          )}
        </Card>
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        <Card>
          <CardTitle
            icon={<Bot className="size-4" />}
            title="Agent activity"
            subtitle="Decisions recorded per agent"
            action={
              <Link to="/agents" className="inline-flex items-center gap-1 text-xs font-medium text-teal-600 hover:underline">
                Command center <ArrowRight className="size-3" />
              </Link>
            }
          />
          {stats.data.agent_activity.length ? (
            <MultiColorBars
              data={stats.data.agent_activity.map((entry) => ({ name: entry.name, value: entry.steps }))}
            />
          ) : (
            <EmptyState title="Agents have not acted yet" description="Run a workflow to see per-agent activity." />
          )}
        </Card>

        <Card>
          <CardTitle
            icon={<FileText className="size-4" />}
            title="Tool usage"
            subtitle="Registry calls, most-used first"
            action={
              <Link to="/tools" className="inline-flex items-center gap-1 text-xs font-medium text-teal-600 hover:underline">
                Registry <ArrowRight className="size-3" />
              </Link>
            }
          />
          {stats.data.tool_usage.length ? (
            <HorizontalBars data={stats.data.tool_usage} color="#2c57a3" />
          ) : (
            <EmptyState title="No tool calls recorded" description="Executed tasks appear here." />
          )}
        </Card>
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.35fr_1fr]">
        <Card>
          <CardTitle
            title="Recent executions"
            subtitle="Live view of the last workflows through the pipeline"
            action={
              <Link to="/workflows" className="inline-flex items-center gap-1 text-xs font-medium text-teal-600 hover:underline">
                All workflows <ArrowRight className="size-3" />
              </Link>
            }
          />
          {(recent.data?.items ?? []).length ? (
            <div>
              {(recent.data?.items ?? []).map((workflow) => (
                <WorkflowRow key={workflow.id} workflow={workflow} />
              ))}
            </div>
          ) : recent.error ? (
            <ErrorNotice message={recent.error} />
          ) : (
            <EmptyState
              title="No workflows yet"
              description="Submit a natural-language request and the Planner Agent will decompose it."
              action={
                <Link
                  to="/workflows/new"
                  className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-navy-800 to-teal-600 px-3.5 py-2 text-xs font-semibold text-white"
                >
                  <Plus className="size-3.5" /> Create workflow
                </Link>
              }
            />
          )}
        </Card>

        <div className="space-y-4">
          <Card>
            <CardTitle
              icon={<ShieldCheck className="size-4" />}
              title="Awaiting a human decision"
              subtitle="Workflows are paused until an authorised approver acts"
              action={
                <Link to="/approvals" className="text-xs font-medium text-teal-600 hover:underline">
                  Open portal
                </Link>
              }
            />
            {approvals.length ? (
              <div className="space-y-2">
                {approvals.slice(0, 4).map((approval: ApprovalItem) => (
                  <Link
                    key={approval.id}
                    to={`/approvals?focus=${approval.id}`}
                    className="block rounded-xl border border-amber-200 bg-amber-50/70 px-3 py-2.5 transition hover:border-amber-300 dark:border-amber-400/25 dark:bg-amber-500/10"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <p className="truncate text-xs font-semibold text-ink">{short(approval.action, 46)}</p>
                      <Badge
                        className={
                          approval.risk_level === "critical"
                            ? "!bg-red-100 !text-red-800 dark:!bg-red-500/20 dark:!text-red-200"
                            : "!bg-amber-100 !text-amber-800 dark:!bg-amber-500/20 dark:!text-amber-200"
                        }
                      >
                        {approval.risk_level}
                      </Badge>
                    </div>
                    <p className="mt-0.5 font-mono text-[11px] text-ink-faint">{approval.workflow_id}</p>
                  </Link>
                ))}
              </div>
            ) : (
              <EmptyState title="Approval queue is clear" description="Nothing is paused right now." />
            )}
          </Card>

          <Card>
            <CardTitle
              icon={<ScrollText className="size-4" />}
              title="Latest audit events"
              subtitle="Append-only decision trail"
              action={
                <Link to="/audit" className="text-xs font-medium text-teal-600 hover:underline">
                  Full log
                </Link>
              }
            />
            {stats.data.recent_audit.length ? (
              <ul className="space-y-2.5">
                {stats.data.recent_audit.slice(0, 7).map((entry) => (
                  <li key={entry.id} className="flex items-start gap-2.5">
                    <span
                      className={`mt-1.5 size-1.5 shrink-0 rounded-full ${
                        entry.severity === "error"
                          ? "bg-red-500"
                          : entry.severity === "warning"
                            ? "bg-amber-500"
                            : "bg-teal-500"
                      }`}
                    />
                    <div className="min-w-0">
                      <p className="truncate text-xs text-ink">{short(entry.message, 78)}</p>
                      <p className="mt-0.5 text-[11px] text-ink-faint">
                        <span className="font-mono">{entry.agent_name}</span> · {entry.event_type} ·{" "}
                        {relativeTime(entry.created_at)}
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <EmptyState title="Audit trail is empty" description="Events appear as soon as a workflow runs." />
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
