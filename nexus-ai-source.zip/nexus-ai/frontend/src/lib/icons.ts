import {
  Brain,
  ClipboardList,
  Database,
  FileText,
  Headphones,
  Monitor,
  Settings,
  ShieldCheck,
  Users,
  Wrench,
  Bot,
  type LucideIcon,
} from "lucide-react";

const ICONS: Record<string, LucideIcon> = {
  brain: Brain,
  users: Users,
  "file-text": FileText,
  monitor: Monitor,
  database: Database,
  headphones: Headphones,
  "shield-check": ShieldCheck,
  settings: Settings,
  "clipboard-list": ClipboardList,
  wrench: Wrench,
  bot: Bot,
};

export function agentIcon(name?: string | null): LucideIcon {
  if (name && ICONS[name]) return ICONS[name];
  return Bot;
}
