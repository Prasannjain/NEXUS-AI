import type { RiskLevel, StageStatus, TaskStatus, WorkflowStatus } from "../api/types";

export const WORKFLOW_STATUS_LABEL: Record<WorkflowStatus, string> = {
  queued: "Queued",
  planning: "Planning",
  running: "Running",
  awaiting_approval: "Awaiting approval",
  completed: "Completed",
  completed_with_exceptions: "Completed with exceptions",
  rejected: "Rejected",
  failed: "Failed",
  cancelled: "Cancelled",
};

export const TASK_STATUS_LABEL: Record<TaskStatus, string> = {
  pending: "Pending",
  running: "Running",
  awaiting_approval: "Waiting for approval",
  retrying: "Retrying",
  completed: "Completed",
  failed: "Failed",
  rejected: "Rejected",
  skipped: "Skipped",
};

/** Tailwind class pairs kept literal so the compiler can see every variant. */
export const WORKFLOW_STATUS_CLASS: Record<WorkflowStatus, string> = {
  queued: "bg-slate-100 text-slate-700 dark:bg-slate-500/15 dark:text-slate-300",
  planning: "bg-sky-100 text-sky-800 dark:bg-sky-500/15 dark:text-sky-300",
  running: "bg-blue-100 text-blue-800 dark:bg-blue-500/15 dark:text-blue-300",
  awaiting_approval: "bg-amber-100 text-amber-800 dark:bg-amber-500/15 dark:text-amber-300",
  completed: "bg-emerald-100 text-emerald-800 dark:bg-emerald-500/15 dark:text-emerald-300",
  completed_with_exceptions: "bg-teal-100 text-teal-800 dark:bg-teal-500/15 dark:text-teal-300",
  rejected: "bg-rose-100 text-rose-800 dark:bg-rose-500/15 dark:text-rose-300",
  failed: "bg-red-100 text-red-800 dark:bg-red-500/15 dark:text-red-300",
  cancelled: "bg-slate-100 text-slate-600 dark:bg-slate-500/15 dark:text-slate-300",
};

export const TASK_STATUS_CLASS: Record<TaskStatus, string> = {
  pending: "bg-slate-100 text-slate-600 dark:bg-slate-500/15 dark:text-slate-300",
  running: "bg-blue-100 text-blue-800 dark:bg-blue-500/15 dark:text-blue-300",
  awaiting_approval: "bg-amber-100 text-amber-800 dark:bg-amber-500/15 dark:text-amber-300",
  retrying: "bg-violet-100 text-violet-800 dark:bg-violet-500/15 dark:text-violet-300",
  completed: "bg-emerald-100 text-emerald-800 dark:bg-emerald-500/15 dark:text-emerald-300",
  failed: "bg-red-100 text-red-800 dark:bg-red-500/15 dark:text-red-300",
  rejected: "bg-rose-100 text-rose-800 dark:bg-rose-500/15 dark:text-rose-300",
  skipped: "bg-slate-100 text-slate-500 dark:bg-slate-500/15 dark:text-slate-300",
};

export const RISK_CLASS: Record<RiskLevel, string> = {
  low: "bg-emerald-100 text-emerald-800 dark:bg-emerald-500/15 dark:text-emerald-300",
  medium: "bg-sky-100 text-sky-800 dark:bg-sky-500/15 dark:text-sky-300",
  high: "bg-amber-100 text-amber-900 dark:bg-amber-500/15 dark:text-amber-300",
  critical: "bg-red-100 text-red-800 dark:bg-red-500/15 dark:text-red-300",
};

export const STAGE_DOT_CLASS: Record<StageStatus, string> = {
  pending: "bg-slate-300 dark:bg-slate-600",
  waiting: "bg-amber-400",
  running: "bg-blue-500",
  completed: "bg-emerald-500",
  failed: "bg-red-500",
  skipped: "bg-slate-300 dark:bg-slate-600",
};

export const AGENT_COLOR: Record<string, string> = {
  amber: "#f59e0b",
  rose: "#f43f5e",
  emerald: "#10b981",
  orange: "#fb923c",
  violet: "#8b5cf6",
  teal: "#14b8a6",
  blue: "#3b82f6",
  slate: "#64748b",
  cyan: "#06b6d4",
  indigo: "#6366f1",
};

export const CHART_COLORS = [
  "#0d9488",
  "#2c57a3",
  "#7c3aed",
  "#f59e0b",
  "#10b981",
  "#ef4444",
  "#06b6d4",
  "#8b5cf6",
  "#fb923c",
  "#64748b",
];

export function agentColor(color?: string | null): string {
  if (!color) return AGENT_COLOR.slate;
  return AGENT_COLOR[color] ?? color;
}

export function formatDateTime(value?: string | null): string {
  if (!value) return "—";
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return value;
  return parsed.toLocaleString(undefined, {
    month: "short",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

export function formatTime(value?: string | null): string {
  if (!value) return "—";
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return value;
  return parsed.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

export function relativeTime(value?: string | null): string {
  if (!value) return "never";
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return value;
  const seconds = Math.round((Date.now() - parsed.getTime()) / 1000);
  if (seconds < 5) return "just now";
  if (seconds < 60) return `${seconds}s ago`;
  const minutes = Math.round(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.round(hours / 24)}d ago`;
}

export function formatDuration(seconds?: number | null): string {
  if (seconds === null || seconds === undefined) return "—";
  if (seconds < 1) return `${Math.round(seconds * 1000)} ms`;
  if (seconds < 60) return `${seconds.toFixed(seconds < 10 ? 2 : 1)} s`;
  const minutes = Math.floor(seconds / 60);
  const rest = Math.round(seconds % 60);
  if (minutes < 60) return `${minutes}m ${rest}s`;
  return `${Math.floor(minutes / 60)}h ${minutes % 60}m`;
}

export function formatMs(ms?: number | null): string {
  if (ms === null || ms === undefined) return "—";
  if (ms < 1000) return `${ms.toFixed(ms < 10 ? 2 : 0)} ms`;
  return `${(ms / 1000).toFixed(2)} s`;
}

export function formatNumber(value?: number | null): string {
  if (value === null || value === undefined) return "—";
  return value.toLocaleString();
}

export function titleCase(value: string): string {
  return value
    .split(/[_\-\s]+/)
    .filter(Boolean)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}

export function bytes(size?: number | null): string {
  if (!size) return "0 B";
  if (size < 1024) return `${size} B`;
  return `${(size / 1024).toFixed(1)} KB`;
}

export function taskDuration(startedAt?: string | null, finishedAt?: string | null): string {
  if (!startedAt || !finishedAt) return "—";
  const ms = new Date(finishedAt).getTime() - new Date(startedAt).getTime();
  if (Number.isNaN(ms)) return "—";
  return formatMs(ms);
}
