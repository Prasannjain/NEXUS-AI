import { useCallback, useEffect, useRef, useState } from "react";
import { ApiError } from "../api/client";

interface AsyncState<T> {
  data: T | null;
  error: string;
  loading: boolean;
  refreshing: boolean;
}

/** Runs an async loader on mount and whenever `deps` change. */
export function useAsync<T>(loader: () => Promise<T>, deps: unknown[]): AsyncState<T> & { reload: () => void } {
  const [state, setState] = useState<AsyncState<T>>({ data: null, error: "", loading: true, refreshing: false });
  const [nonce, setNonce] = useState(0);
  const mounted = useRef(true);
  const loaderRef = useRef(loader);
  loaderRef.current = loader;

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);

  useEffect(() => {
    let cancelled = false;
    setState((prev) => ({
      data: prev.data,
      error: "",
      loading: prev.data === null,
      refreshing: prev.data !== null,
    }));
    loaderRef
      .current()
      .then((data) => {
        if (!cancelled) setState({ data, error: "", loading: false, refreshing: false });
      })
      .catch((error: unknown) => {
        if (cancelled) return;
        const message = error instanceof ApiError ? error.detail : "Unexpected error loading data.";
        setState({ data: null, error: message, loading: false, refreshing: false });
      });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, nonce]);

  const reload = useCallback(() => setNonce((value) => value + 1), []);
  return { ...state, reload };
}

/**
 * Polls a loader on an interval while `enabled`. The interval pauses while the
 * tab is hidden so a long-running workflow does not keep hammering the API.
 */
export function usePoll<T>(loader: () => Promise<T>, intervalMs: number, deps: unknown[], enabled = true) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState("");
  const [nonce, setNonce] = useState(0);
  const timer = useRef<number | null>(null);
  const loaderRef = useRef(loader);
  loaderRef.current = loader;

  useEffect(() => {
    let cancelled = false;
    const tick = async () => {
      try {
        const value = await loaderRef.current();
        if (!cancelled) {
          setData(value);
          setError("");
        }
      } catch (err) {
        if (!cancelled) setError(err instanceof ApiError ? err.detail : "Polling failed.");
      }
    };
    void tick();
    if (!enabled) return () => void (cancelled = true);

    const schedule = () => {
      if (timer.current) window.clearInterval(timer.current);
      timer.current = window.setInterval(() => {
        if (document.visibilityState === "hidden") return;
        void tick();
      }, intervalMs);
    };
    schedule();
    return () => {
      cancelled = true;
      if (timer.current) window.clearInterval(timer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [intervalMs, enabled, ...deps, nonce]);

  const reload = useCallback(() => setNonce((value) => value + 1), []);
  return { data, error, reload };
}

export function useDebounced(value: string, delay = 300): string {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const handle = window.setTimeout(() => setDebounced(value), delay);
    return () => window.clearTimeout(handle);
  }, [value, delay]);
  return debounced;
}
