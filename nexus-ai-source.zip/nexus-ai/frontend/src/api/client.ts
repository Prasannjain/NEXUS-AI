import type {
  AgentDetail,
  AgentSummary,
  ApprovalItem,
  ApprovalListResponse,
  ArchitectureResponse,
  AuditEntry,
  AuditFacets,
  AuditPage,
  AuditQuery,
  CategoriesResponse,
  DemoAccounts,
  FinalReport,
  DashboardStats,
  HealthPayload,
  IntegrationInfo,
  IntegrationTestResult,
  LoginResponse,
  NotificationsPage,
  PlanPreview,
  PlatformAnalytics,
  ProviderHealth,
  ProviderInfo,
  ReportsResponse,
  RoleInfo,
  SettingsPayload,
  ToolInfo,
  ToolValidation,
  User,
  WorkflowDetail,
  WorkflowEvents,
  WorkflowListResponse,
  WorkflowSummary,
} from "./types";

const TOKEN_KEY = "nexus.token";
const USER_KEY = "nexus.user";

export class ApiError extends Error {
  status: number;
  detail: string;

  constructor(status: number, detail: string) {
    super(detail);
    this.status = status;
    this.detail = detail;
    this.name = "ApiError";
  }
}

export const auth = {
  token(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  },
  user(): User | null {
    const raw = localStorage.getItem(USER_KEY);
    if (!raw) return null;
    try {
      return JSON.parse(raw) as User;
    } catch {
      return null;
    }
  },
  store(token: string, user: User) {
    localStorage.setItem(TOKEN_KEY, token);
    localStorage.setItem(USER_KEY, JSON.stringify(user));
  },
  setUser(user: User) {
    localStorage.setItem(USER_KEY, JSON.stringify(user));
  },
  clear() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
  },
};

const BASE_URL = import.meta.env.VITE_API_BASE_URL ?? "";

interface RequestOptions {
  method?: "GET" | "POST" | "PUT" | "PATCH" | "DELETE";
  body?: unknown;
  query?: object;
  signal?: AbortSignal;
}

function queryString(query?: object): string {
  if (!query) return "";
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(query)) {
    if (value === undefined || value === null || value === "") continue;
    params.set(key, String(value));
  }
  const encoded = params.toString();
  return encoded ? `?${encoded}` : "";
}

function describe(payload: unknown, fallback: string): string {
  if (typeof payload === "string") return payload;
  if (payload && typeof payload === "object") {
    const record = payload as Record<string, unknown>;
    const detail = record.detail ?? record.message ?? record.error;
    if (typeof detail === "string") return detail;
    if (Array.isArray(detail)) {
      return detail
        .map((item) => {
          if (typeof item === "object" && item) {
            const entry = item as Record<string, unknown>;
            const loc = Array.isArray(entry.loc) ? entry.loc.join(" › ") : "";
            return `${loc ? `${loc}: ` : ""}${String(entry.msg ?? "")}`;
          }
          return String(item);
        })
        .filter(Boolean)
        .join(" · ");
    }
  }
  return fallback;
}

async function request<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const token = auth.token();
  const headers: Record<string, string> = { Accept: "application/json" };
  if (token) headers.Authorization = `Bearer ${token}`;
  if (options.body !== undefined) headers["Content-Type"] = "application/json";

  let response: Response;
  try {
    response = await fetch(`${BASE_URL}${path}${queryString(options.query)}`, {
      method: options.method ?? "GET",
      headers,
      body: options.body === undefined ? undefined : JSON.stringify(options.body),
      signal: options.signal,
    });
  } catch (error) {
    if ((error as Error).name === "AbortError") throw error;
    throw new ApiError(0, "Cannot reach the NEXUS API. Confirm the backend is running and retry.");
  }

  if (response.status === 401 && !path.startsWith("/api/auth/login")) {
    auth.clear();
    if (!window.location.pathname.startsWith("/login")) {
      window.location.assign("/login");
    }
    throw new ApiError(401, describe(await safeBody(response), "Your session expired. Sign in again."));
  }

  if (!response.ok) {
    throw new ApiError(response.status, describe(await safeBody(response), `Request failed (${response.status})`));
  }
  if (response.status === 204) return undefined as T;
  return (await response.json()) as T;
}

async function safeBody(response: Response): Promise<unknown> {
  const text = await response.text();
  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}

async function downloadFile(path: string, filename: string, query?: RequestOptions["query"]): Promise<void> {
  const token = auth.token();
  const response = await fetch(`${BASE_URL}${path}${queryString(query)}`, {
    headers: token ? { Authorization: `Bearer ${token}` } : {},
  });
  if (!response.ok) {
    throw new ApiError(response.status, describe(await safeBody(response), "Download failed"));
  }
  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}

async function fetchText(path: string, query?: RequestOptions["query"]): Promise<string> {
  const token = auth.token();
  const response = await fetch(`${BASE_URL}${path}${queryString(query)}`, {
    headers: {
      Accept: "text/plain",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
  });
  if (!response.ok) {
    throw new ApiError(response.status, describe(await safeBody(response), "Request failed"));
  }
  return response.text();
}

export const api = {
  health: () => request<HealthPayload>("/api/health"),
  architecture: () => request<ArchitectureResponse>("/api/architecture"),

  login: (email: string, password: string) =>
    request<LoginResponse>("/api/auth/login", { method: "POST", body: { email, password } }),
  me: () => request<User>("/api/auth/me"),
  demoAccounts: () => request<DemoAccounts>("/api/auth/demo-accounts"),

  dashboard: () => request<DashboardStats>("/api/dashboard/stats"),

  categories: () => request<CategoriesResponse>("/api/workflows/categories"),
  previewPlan: (request_text: string, category: string) =>
    request<PlanPreview>("/api/workflows/preview-plan", {
      method: "POST",
      body: { request_text, category },
    }),
  createWorkflow: (request_text: string, category: string) =>
    request<WorkflowSummary>("/api/workflows", { method: "POST", body: { request_text, category } }),
  workflows: (query?: { status?: string; category?: string; search?: string; limit?: number; offset?: number }) =>
    request<WorkflowListResponse>("/api/workflows", { query }),
  workflow: (id: string) => request<WorkflowDetail>(`/api/workflows/${id}`),
  workflowEvents: (id: string) => request<WorkflowEvents>(`/api/workflows/${id}/events`),
  cancelWorkflow: (id: string) => request<{ status: string }>(`/api/workflows/${id}/cancel`, { method: "POST" }),
  resumeWorkflow: (id: string) => request<{ status: string }>(`/api/workflows/${id}/resume`, { method: "POST" }),
  workflowReport: (id: string) => request<FinalReport>(`/api/workflows/${id}/report`),
  downloadReport: (id: string) => downloadFile(`/api/workflows/${id}/report.md`, `${id}-report.md`),
  downloadDocument: (workflowId: string, documentId: string, title: string) =>
    downloadFile(
      `/api/workflows/${workflowId}/documents/${documentId}`,
      `${documentId}-${title.replace(/[^\w.-]+/g, "_").slice(0, 60)}.md`,
    ),

  approvals: (status?: string) => request<ApprovalListResponse>("/api/approvals", { query: { status } }),
  approvalHistory: (workflowId?: string) =>
    request<ApprovalItem[]>("/api/approvals/history", { query: { workflow_id: workflowId } }),
  approval: (id: string) => request<ApprovalItem>(`/api/approvals/${id}`),
  decide: (id: string, action: "approve" | "reject", comment: string) =>
    request<ApprovalItem>(`/api/approvals/${id}/decide`, { method: "POST", body: { action, comment } }),

  agents: () => request<AgentSummary[]>("/api/agents"),
  agent: (name: string) => request<AgentDetail>(`/api/agents/${name}`),

  tools: () => request<ToolInfo[]>("/api/tools"),
  registerTool: (payload: Record<string, unknown>) =>
    request<ToolInfo>("/api/tools", { method: "POST", body: payload }),
  updateTool: (name: string, payload: Record<string, unknown>) =>
    request<ToolInfo>(`/api/tools/${name}`, { method: "PATCH", body: payload }),
  validateTool: (name: string) => request<ToolValidation>(`/api/tools/${name}/validate`, { method: "POST" }),
  syncTools: () => request<{ integrations: number; tools: number }>("/api/tools/sync", { method: "POST" }),

  integrations: () => request<IntegrationInfo[]>("/api/integrations"),
  updateIntegration: (key: string, payload: { connection_status: string; config?: Record<string, unknown> }) =>
    request<IntegrationInfo>(`/api/integrations/${key}`, { method: "PATCH", body: payload }),
  testIntegration: (key: string) =>
    request<IntegrationTestResult>(`/api/integrations/${key}/test`, { method: "POST" }),

  audit: (query?: AuditQuery) => request<AuditPage>("/api/audit", { query }),
  auditFacets: () => request<AuditFacets>("/api/audit/facets"),
  exportAudit: (query?: AuditQuery) => downloadFile("/api/audit/export.csv", "nexus-audit.csv", query),
  workflowAudit: (id: string) => request<AuditEntry[]>(`/api/audit/workflow/${id}`),

  reports: (query?: { category?: string; status?: string; days?: number }) =>
    request<ReportsResponse>("/api/reports", { query }),
  platformAnalytics: (days = 30) => request<PlatformAnalytics>("/api/reports/platform", { query: { days } }),
  reportMarkdown: (id: string) => fetchText(`/api/reports/${id}.md`),

  settings: () => request<SettingsPayload>("/api/settings"),
  roles: () => request<RoleInfo[]>("/api/settings/roles"),
  switchProvider: (provider: string) =>
    request<{ provider: string; providers: ProviderInfo[] }>("/api/settings/llm/provider", {
      method: "PUT",
      body: { provider },
    }),
  testProvider: (provider: string) =>
    request<ProviderHealth>("/api/settings/llm/test", { method: "POST", body: { provider } }),

  notifications: (unreadOnly = false) =>
    request<NotificationsPage>("/api/notifications", { query: { unread_only: unreadOnly } }),
  markNotificationRead: (id: number) => request<{ id: number; read: boolean }>(`/api/notifications/${id}/read`, { method: "POST" }),
  markAllNotificationsRead: () => request<{ marked: number }>("/api/notifications/read-all", { method: "POST" }),
};
