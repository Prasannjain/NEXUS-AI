export type RiskLevel = "low" | "medium" | "high" | "critical";
export type ConnectionStatus = "connected" | "degraded" | "disabled" | "disconnected";

export type WorkflowStatus =
  | "queued"
  | "planning"
  | "running"
  | "awaiting_approval"
  | "completed"
  | "completed_with_exceptions"
  | "rejected"
  | "failed"
  | "cancelled";

export type TaskStatus =
  | "pending"
  | "running"
  | "awaiting_approval"
  | "completed"
  | "failed"
  | "rejected"
  | "skipped"
  | "retrying";

export type StageStatus = "pending" | "running" | "completed" | "failed" | "waiting" | "skipped";

export interface RoleSummary {
  name: string;
  description: string;
  permissions: string[];
}

export interface User {
  id: number;
  email: string;
  full_name: string;
  department: string;
  role: RoleSummary;
}

export interface LoginResponse {
  access_token: string;
  token_type: string;
  expires_in_minutes: number;
  user: User;
}

export interface DemoAccounts {
  password: string;
  accounts: { email: string; name: string; role: string }[];
}

export interface NamedCount {
  name: string;
  value: number;
}

export interface AgentActivity {
  agent: string;
  name: string;
  steps: number;
}

export interface TrendPoint {
  date: string;
  workflows: number;
}

export interface DashboardCounters {
  total_workflows: number;
  active_workflows: number;
  completed_workflows: number;
  failed_workflows: number;
  rejected_workflows: number;
  pending_approvals: number;
  total_agents: number;
  active_agents: number;
  enabled_tools: number;
  total_tools: number;
  success_rate: number;
  avg_duration_seconds: number;
  audit_entries: number;
  generated_documents: number;
}

export interface DashboardStats {
  counters: DashboardCounters;
  status_breakdown: NamedCount[];
  category_breakdown: NamedCount[];
  daily_trend: TrendPoint[];
  agent_activity: AgentActivity[];
  tool_usage: NamedCount[];
  risk_distribution: NamedCount[];
  recent_workflows: WorkflowSummary[];
  recent_audit: AuditEntry[];
}

export interface WorkflowSummary {
  id: string;
  title: string;
  request_text: string;
  category: string;
  status: WorkflowStatus;
  current_stage: string;
  active_agent: string;
  progress: number;
  requester: string;
  created_at: string;
  started_at: string | null;
  finished_at: string | null;
  duration_seconds: number | null;
  result_summary: string;
  error_message: string;
  pending_approvals: number;
  task_counts: Record<string, number>;
  llm_provider: string;
}

export interface WorkflowTask {
  task_id: string;
  seq: number;
  description: string;
  agent_name: string;
  tool_name: string;
  arguments: Record<string, unknown>;
  depends_on: string[];
  requires_approval: boolean;
  risk_level: RiskLevel;
  status: TaskStatus;
  output_summary: string;
  result: Record<string, unknown> | null;
  error: string;
  attempts: number;
  started_at: string | null;
  finished_at: string | null;
}

export interface StageEntry {
  key: string;
  label: string;
  description: string;
  status: StageStatus;
  is_current: boolean;
  detail: string;
}

export interface ApprovalSummary {
  id: string;
  workflow_id: string;
  task_id: string;
  agent_name: string;
  action: string;
  details: Record<string, unknown>;
  risk_level: RiskLevel;
  policy_reason: string;
  status: "pending" | "approved" | "rejected";
  requested_at: string;
  decided_at: string | null;
  decided_by: string;
  comment: string;
}

export interface ApprovalItem extends ApprovalSummary {
  workflow_title: string;
  request_text: string;
  requester: string;
  tool: string;
  required_permission: string;
  side_effect: string;
  retry_safe: boolean;
  can_decide: boolean;
}

export interface AgentExecution {
  id: number;
  agent_name: string;
  task_id: string;
  node: string;
  status: string;
  decision: string;
  input_summary: string;
  output_summary: string;
  error: string;
  duration_ms: number;
  created_at: string;
}

export interface ExecutionRow {
  id: number;
  workflow_id: string;
  task_id: string;
  node: string;
  status: string;
  decision: string;
  duration_ms: number;
  created_at: string;
}

export interface ToolCallRecord {
  tool_name: string;
  task_id: string;
  agent_name: string;
  status: string;
  idempotency_key: string;
  duration_ms: number;
  summary: string;
  created_at: string;
}

export interface DocumentRecord {
  id: string;
  title: string;
  doc_type: string;
  storage_path: string;
  file_size: number;
  created_at: string;
}

export interface AuditEntry {
  id: number;
  workflow_id: string | null;
  task_id: string;
  agent_name: string;
  event_type: string;
  actor: string;
  message: string;
  tool_name: string;
  input_summary: string;
  output_summary: string;
  severity: string;
  payload: Record<string, unknown>;
  created_at: string;
}

export interface AuditPage {
  total: number;
  limit: number;
  offset: number;
  items: AuditEntry[];
}

export interface AuditQuery {
  q?: string;
  workflow_id?: string;
  agent_name?: string;
  event_type?: string;
  severity?: string;
  date_from?: string;
  date_to?: string;
  limit?: number;
  offset?: number;
}

export interface Checkpoint {
  exists: boolean;
  current_node: string;
  next_nodes: string[];
  interrupts: { id: string; value: Record<string, unknown> }[];
  progress: number;
}

export interface FinalReport {
  workflow_id: string;
  title: string;
  original_request: string;
  category: string;
  category_label: string;
  status: string;
  headline: string;
  created_at: string;
  started_at: string | null;
  finished_at: string | null;
  duration_seconds: number | null;
  llm_provider: string;
  requester: string;
  entities: Record<string, unknown>;
  plan_rationale: string;
  tasks: Record<string, unknown>[];
  approvals: Record<string, unknown>[];
  tool_executions: Record<string, unknown>[];
  documents: Record<string, unknown>[];
  agents_involved: string[];
  audit_entries: number;
  completed_tasks: number;
  failed_tasks: number;
  rejected_tasks: number;
  skipped_tasks: number;
  pending_tasks: number;
  simulation_notice: string;
}

export interface WorkflowDetail extends WorkflowSummary {
  plan: PlanPreview | null;
  tasks: WorkflowTask[];
  approvals: ApprovalSummary[];
  executions: AgentExecution[];
  documents: DocumentRecord[];
  tool_calls: ToolCallRecord[];
  timeline: StageEntry[];
  checkpoint: Checkpoint;
  audit_entries: number;
  final_report: FinalReport | null;
  running: boolean;
}

export interface WorkflowEventTask {
  task_id: string;
  description: string;
  agent_name: string;
  tool_name: string;
  status: TaskStatus;
  attempts: number;
  risk_level: RiskLevel;
  requires_approval: boolean;
  output_summary: string;
  error: string;
}

export interface WorkflowEvents {
  id: string;
  status: WorkflowStatus;
  stage: string;
  active_agent: string;
  progress: number;
  duration_seconds: number | null;
  tasks: WorkflowEventTask[];
  timeline: StageEntry[];
  running: boolean;
}

export interface PlanTask {
  task_id: string;
  seq?: number;
  description: string;
  agent: string;
  tool: string;
  arguments: Record<string, unknown>;
  depends_on: string[];
  requires_approval: boolean;
  risk_level: RiskLevel;
  reversible: boolean;
  retry_safe: boolean;
  side_effect: string;
}

export interface PlanPreview {
  category: string;
  category_label: string;
  objective: string;
  entities: Record<string, unknown>;
  rationale: string;
  source: string;
  provider: string;
  model: string;
  task_count: number;
  approval_checkpoints: string[];
  agents: string[];
  tasks: PlanTask[];
}

export interface CategoryOption {
  key: string;
  label: string;
  examples: string[];
}

export interface CategoriesResponse {
  categories: CategoryOption[];
}

export interface AgentSummary {
  name: string;
  display_name: string;
  description: string;
  capabilities: string[];
  allowed_tools: string[];
  icon: string;
  color: string;
  status: "idle" | "working" | "awaiting_approval" | "failed";
  tasks_owned: number;
  tasks_completed: number;
  tasks_failed: number;
  executions: number;
  success_rate: number | null;
  last_activity: string | null;
}

export interface AgentToolSummary {
  name: string;
  display_name: string;
  risk_level: RiskLevel;
  required_permission: string;
  requires_approval: boolean;
}

export interface AgentDetail extends AgentSummary {
  tools: AgentToolSummary[];
  recent_executions: ExecutionRow[];
}

export interface ToolInfo {
  id: number;
  name: string;
  display_name: string;
  description: string;
  integration: string;
  integration_id: number;
  agent_scope: string[];
  required_permission: string;
  input_schema: Record<string, unknown>;
  side_effect: string;
  risk_level: RiskLevel;
  requires_approval: boolean;
  retry_safe: boolean;
  reversible: boolean;
  produces_documents: boolean;
  enabled: boolean;
  connection_status: ConnectionStatus;
  has_adapter: boolean;
  last_used_at: string | null;
  created_at: string;
}

export interface IntegrationToolSummary {
  name: string;
  display_name: string;
  enabled: boolean;
  risk_level: RiskLevel;
  side_effect: string;
  requires_approval: boolean;
}

export interface IntegrationInfo {
  id: number;
  key: string;
  name: string;
  description: string;
  system_type: string;
  connection_status: ConnectionStatus;
  available_operations: string[];
  required_permissions: string[];
  base_url: string;
  is_simulated: boolean;
  config: Record<string, unknown>;
  last_activity_at: string | null;
  tool_count: number;
  enabled_tools: number;
  tools: IntegrationToolSummary[];
}

export interface IntegrationTestResult {
  integration: string;
  status: string;
  simulated: boolean;
  note: string;
  tools: {
    tool: string;
    enabled: boolean;
    adapter_available: boolean;
    schema_declared: boolean;
    reachable: boolean;
    simulated: boolean;
  }[];
}

export interface ToolValidation {
  tool: string;
  schema_valid: boolean;
  errors: string[];
  catalog_definition: boolean;
  adapter_available: boolean;
  sample_payload: Record<string, unknown>;
  required_fields: string[];
}

export interface AuditFacets {
  agents: NamedCount[];
  event_types: NamedCount[];
  known_event_types: string[];
  severities: string[];
  total_entries: number;
  append_only: boolean;
}

export interface ReportItem {
  workflow_id: string;
  title: string;
  category: string;
  status: string;
  requester: string;
  finished_at: string | null;
  duration_seconds: number | null;
  headline: string;
  tasks_completed: number;
  tasks_total: number;
  tool_calls: number;
  documents: number;
}

export interface ReportsResponse {
  summary: {
    reports: number;
    completed: number;
    with_exceptions: number;
    rejected: number;
    failed: number;
    success_rate: number;
    avg_duration_seconds: number;
    approvals_decided: number;
    approvals_rejected: number;
    by_category: NamedCount[];
    by_status: NamedCount[];
  };
  items: ReportItem[];
}

export interface PlatformAnalytics {
  window_days: number;
  task_status: NamedCount[];
  agent_load: NamedCount[];
  tool_load: NamedCount[];
  risk_load: NamedCount[];
  audit_severity: NamedCount[];
  totals: {
    tasks: number;
    agent_steps: number;
    tool_calls: number;
    documents: number;
    approvals: number;
    audit_entries: number;
  };
}

export interface ProviderInfo {
  name: string;
  label: string;
  model: string;
  configured: boolean;
  key_env: string;
  active: boolean;
}

export interface SettingsPayload {
  llm: { provider: string; providers: ProviderInfo[]; note: string };
  platform: {
    app_name: string;
    environment: string;
    database: { dialect: string; postgres: boolean; redis: boolean; redis_note: string };
    orchestration: {
      engine: string;
      checkpoint_store: string;
      max_task_attempts: number;
      retry_base_delay_seconds: number;
      retry_backoff_factor: number;
      escalation_email: string;
    };
    approval_policy: {
      rule: string;
      gated_tools: string[];
      never_auto_retried: string[];
      irreversible: string[];
    };
    security: {
      token_type: string;
      token_expiry_minutes: number;
      password_hash: string;
      secrets_source: string;
      audit_append_only: boolean;
      roles: string[];
    };
  };
  counts: {
    agents: number;
    tools: number;
    registered_tools: number;
    workflows: number;
    pending_approvals: number;
  };
}

export interface RoleInfo {
  name: string;
  description: string;
  permissions: string[];
  user_count: number;
}

export interface NotificationItem {
  id: number;
  title: string;
  message: string;
  level: string;
  workflow_id: string | null;
  read: boolean;
  created_at: string;
}

export interface NotificationsPage {
  total: number;
  unread: number;
  items: NotificationItem[];
}

export interface ArchitectureStage {
  key: string;
  label: string;
  description: string;
}

export interface ArchitectureResponse {
  stages: ArchitectureStage[];
}

export interface HealthPayload {
  status: string;
  version: string;
  environment: string;
  database: string;
  database_dialect: string;
  llm_provider: string;
  orchestrator: string;
  active_workflow_runs: number;
  simulated_integrations: boolean;
}

export interface ProviderHealth {
  provider: string;
  status: string;
  detail: string;
}

export interface WorkflowListResponse {
  total: number;
  items: WorkflowSummary[];
}

export interface ApprovalListResponse {
  total: number;
  pending: number;
  items: ApprovalItem[];
}
