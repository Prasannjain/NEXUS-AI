import { Navigate, Route, Routes } from "react-router-dom";
import { Layout } from "./components/Layout";
import { LoadingPanel } from "./components/ui";
import { useAuth } from "./state/AuthContext";
import LoginPage from "./pages/LoginPage";
import OverviewPage from "./pages/OverviewPage";
import CreateWorkflowPage from "./pages/CreateWorkflowPage";
import AgentCommandPage from "./pages/AgentCommandPage";
import WorkflowMonitorPage from "./pages/WorkflowMonitorPage";
import WorkflowDetailPage from "./pages/WorkflowDetailPage";
import ApprovalsPage from "./pages/ApprovalsPage";
import IntegrationsPage from "./pages/IntegrationsPage";
import ToolRegistryPage from "./pages/ToolRegistryPage";
import AuditLogsPage from "./pages/AuditLogsPage";
import ReportsPage from "./pages/ReportsPage";
import SettingsPage from "./pages/SettingsPage";
import { EmptyState } from "./components/ui";

function RequireAuth({ children }: { children: React.ReactNode }) {
  const { user, ready } = useAuth();
  if (!ready) return <LoadingPanel label="Restoring your session" />;
  if (!user) return <Navigate to="/login" replace />;
  return <>{children}</>;
}

export default function App() {
  const { user, ready } = useAuth();

  return (
    <Routes>
      <Route path="/login" element={ready && user ? <Navigate to="/" replace /> : <LoginPage />} />
      <Route
        element={
          <RequireAuth>
            <Layout />
          </RequireAuth>
        }
      >
        <Route index element={<OverviewPage />} />
        <Route path="workflows" element={<WorkflowMonitorPage />} />
        <Route path="workflows/new" element={<CreateWorkflowPage />} />
        <Route path="workflows/:workflowId" element={<WorkflowDetailPage />} />
        <Route path="agents" element={<AgentCommandPage />} />
        <Route path="approvals" element={<ApprovalsPage />} />
        <Route path="integrations" element={<IntegrationsPage />} />
        <Route path="tools" element={<ToolRegistryPage />} />
        <Route path="audit" element={<AuditLogsPage />} />
        <Route path="reports" element={<ReportsPage />} />
        <Route path="settings" element={<SettingsPage />} />
        <Route
          path="*"
          element={
            <EmptyState
              title="Page not found"
              description="That route is not part of the NEXUS console. Use the sidebar to navigate."
            />
          }
        />
      </Route>
    </Routes>
  );
}
