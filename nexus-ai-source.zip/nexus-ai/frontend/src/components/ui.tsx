import { clsx } from "clsx";
import type { ReactNode } from "react";
import { AlertTriangle, Inbox, Loader2, X } from "lucide-react";
import type { RiskLevel, TaskStatus, WorkflowStatus } from "../api/types";
import {
  RISK_CLASS,
  TASK_STATUS_CLASS,
  TASK_STATUS_LABEL,
  WORKFLOW_STATUS_CLASS,
  WORKFLOW_STATUS_LABEL,
} from "../lib/format";

export function Card({
  className,
  children,
  padded = true,
}: {
  className?: string;
  children: ReactNode;
  padded?: boolean;
}) {
  return (
    <section className={clsx("card-surface animate-rise", padded && "p-5", className)}>{children}</section>
  );
}

export function CardTitle({
  icon,
  title,
  subtitle,
  action,
  className,
}: {
  icon?: ReactNode;
  title: string;
  subtitle?: string;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <header className={clsx("mb-4 flex items-start justify-between gap-3", className)}>
      <div className="flex items-start gap-3">
        {icon ? <span className="mt-0.5 text-teal-600 dark:text-teal-300">{icon}</span> : null}
        <div>
          <h2 className="text-[15px] font-semibold tracking-tight text-ink">{title}</h2>
          {subtitle ? <p className="mt-0.5 text-xs text-ink-soft">{subtitle}</p> : null}
        </div>
      </div>
      {action}
    </header>
  );
}

export function Badge({
  children,
  className,
  tone = "neutral",
}: {
  children: ReactNode;
  className?: string;
  tone?: "neutral" | "teal" | "navy" | "amber" | "red" | "green";
}) {
  const tones: Record<string, string> = {
    neutral: "bg-slate-100 text-slate-700 dark:bg-slate-500/15 dark:text-slate-300",
    teal: "bg-teal-100 text-teal-800 dark:bg-teal-500/15 dark:text-teal-300",
    navy: "bg-navy-100 text-navy-700 dark:bg-navy-500/25 dark:text-navy-200",
    amber: "bg-amber-100 text-amber-800 dark:bg-amber-500/15 dark:text-amber-300",
    red: "bg-red-100 text-red-800 dark:bg-red-500/15 dark:text-red-300",
    green: "bg-emerald-100 text-emerald-800 dark:bg-emerald-500/15 dark:text-emerald-300",
  };
  return (
    <span
      className={clsx(
        "inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[11px] font-medium whitespace-nowrap",
        tones[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}

export function StatusBadge({ status }: { status: WorkflowStatus | string }) {
  const known = status as WorkflowStatus;
  return (
    <Badge className={clsx("!px-2.5", WORKFLOW_STATUS_CLASS[known] ?? "bg-slate-100 text-slate-700")}>
      {WORKFLOW_STATUS_LABEL[known] ?? String(status).replace(/_/g, " ")}
    </Badge>
  );
}

export function TaskBadge({ status }: { status: TaskStatus | string }) {
  const known = status as TaskStatus;
  return (
    <Badge className={TASK_STATUS_CLASS[known] ?? "bg-slate-100 text-slate-700"}>
      {TASK_STATUS_LABEL[known] ?? String(status).replace(/_/g, " ")}
    </Badge>
  );
}

export function RiskBadge({ level }: { level: RiskLevel | string }) {
  const known = level as RiskLevel;
  return <Badge className={RISK_CLASS[known] ?? RISK_CLASS.low}>{String(level)}</Badge>;
}

export function Progress({
  value,
  tone = "teal",
  className,
}: {
  value: number;
  tone?: "teal" | "navy" | "amber" | "red";
  className?: string;
}) {
  const tones: Record<string, string> = {
    teal: "bg-gradient-to-r from-teal-500 to-teal-400",
    navy: "bg-gradient-to-r from-navy-600 to-navy-400",
    amber: "bg-amber-400",
    red: "bg-red-500",
  };
  return (
    <div className={clsx("h-1.5 w-full overflow-hidden rounded-full bg-line", className)}>
      <div
        className={clsx("h-full rounded-full transition-[width] duration-500 ease-out", tones[tone])}
        style={{ width: `${Math.min(100, Math.max(0, value))}%` }}
      />
    </div>
  );
}

export function StatTile({
  label,
  value,
  hint,
  icon,
  tone = "navy",
}: {
  label: string;
  value: ReactNode;
  hint?: string;
  icon?: ReactNode;
  tone?: "navy" | "teal" | "amber" | "red" | "green" | "violet";
}) {
  const tones: Record<string, string> = {
    navy: "from-navy-900 to-navy-700 text-navy-100",
    teal: "from-teal-600 to-teal-500 text-teal-50",
    amber: "from-amber-500 to-amber-400 text-amber-50",
    red: "from-red-600 to-rose-500 text-red-50",
    green: "from-emerald-600 to-teal-500 text-emerald-50",
    violet: "from-violet-600 to-indigo-500 text-violet-50",
  };
  return (
    <div className="card-surface animate-rise overflow-hidden p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="truncate text-[11px] font-semibold tracking-[0.08em] text-ink-faint uppercase">{label}</p>
          <p className="mt-1.5 text-2xl font-semibold tabular-nums text-ink">{value}</p>
          {hint ? <p className="mt-1 truncate text-xs text-ink-soft">{hint}</p> : null}
        </div>
        {icon ? (
          <span
            className={clsx(
              "grid size-10 shrink-0 place-items-center rounded-xl bg-gradient-to-br text-white shadow-sm",
              tones[tone],
            )}
          >
            {icon}
          </span>
        ) : null}
      </div>
    </div>
  );
}

export function Spinner({ className }: { className?: string }) {
  return <Loader2 className={clsx("size-4 animate-spin", className)} />;
}

export function LoadingPanel({ label = "Loading" }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-2 py-14 text-sm text-ink-soft">
      <Spinner />
      {label}…
    </div>
  );
}

export function EmptyState({
  title,
  description,
  icon,
  action,
}: {
  title: string;
  description?: string;
  icon?: ReactNode;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-line px-6 py-12 text-center">
      <span className="text-ink-faint">{icon ?? <Inbox className="size-6" />}</span>
      <p className="text-sm font-semibold text-ink">{title}</p>
      {description ? <p className="max-w-md text-xs text-ink-soft">{description}</p> : null}
      {action ? <div className="mt-2">{action}</div> : null}
    </div>
  );
}

export function ErrorNotice({
  message,
  onRetry,
  className,
}: {
  message: string;
  onRetry?: () => void;
  className?: string;
}) {
  return (
    <div
      className={clsx(
        "flex items-start gap-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800 dark:border-red-500/30 dark:bg-red-500/10 dark:text-red-200",
        className,
      )}
    >
      <AlertTriangle className="mt-0.5 size-4 shrink-0" />
      <div className="flex-1">
        <p>{message}</p>
        {onRetry ? (
          <button
            type="button"
            onClick={onRetry}
            className="mt-2 rounded-lg border border-red-300 px-2.5 py-1 text-xs font-medium hover:bg-red-100 dark:border-red-500/40 dark:hover:bg-red-500/20"
          >
            Retry
          </button>
        ) : null}
      </div>
    </div>
  );
}

export function Notice({
  tone = "info",
  title,
  children,
}: {
  tone?: "info" | "warn" | "success";
  title: string;
  children?: ReactNode;
}) {
  const tones: Record<string, string> = {
    info: "border-navy-200 bg-navy-50 text-navy-800 dark:border-navy-400/30 dark:bg-navy-500/10 dark:text-navy-100",
    warn: "border-amber-200 bg-amber-50 text-amber-900 dark:border-amber-400/30 dark:bg-amber-500/10 dark:text-amber-200",
    success:
      "border-emerald-200 bg-emerald-50 text-emerald-900 dark:border-emerald-400/30 dark:bg-emerald-500/10 dark:text-emerald-200",
  };
  return (
    <div className={clsx("rounded-xl border px-4 py-3 text-sm", tones[tone])}>
      <p className="font-semibold">{title}</p>
      {children ? <div className="mt-1 text-[13px] opacity-90">{children}</div> : null}
    </div>
  );
}

export function Modal({
  open,
  onClose,
  title,
  subtitle,
  children,
  footer,
  width = "max-w-2xl",
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: ReactNode;
  footer?: ReactNode;
  width?: string;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-navy-900/40 p-4 backdrop-blur-sm animate-fade sm:items-center">
      <div className={clsx("card-surface w-full animate-rise bg-surface p-5", width)} role="dialog" aria-modal="true">
        <div className="mb-4 flex items-start justify-between gap-4">
          <div>
            <h3 className="text-base font-semibold text-ink">{title}</h3>
            {subtitle ? <p className="mt-0.5 text-xs text-ink-soft">{subtitle}</p> : null}
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close dialog"
            className="rounded-lg p-1.5 text-ink-faint transition hover:bg-surface-muted hover:text-ink"
          >
            <X className="size-4" />
          </button>
        </div>
        {children}
        {footer ? <div className="mt-5 flex flex-wrap justify-end gap-2">{footer}</div> : null}
      </div>
    </div>
  );
}

export function Toggle({
  checked,
  onChange,
  disabled,
  label,
}: {
  checked: boolean;
  onChange: (value: boolean) => void;
  disabled?: boolean;
  label: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={clsx(
        "relative inline-flex h-5 w-9 shrink-0 items-center rounded-full transition-colors",
        checked ? "bg-teal-500" : "bg-line-strong",
        disabled ? "cursor-not-allowed opacity-50" : "cursor-pointer",
      )}
    >
      <span
        className={clsx(
          "inline-block size-4 transform rounded-full bg-white shadow transition-transform",
          checked ? "translate-x-[18px]" : "translate-x-0.5",
        )}
      />
    </button>
  );
}

type ButtonProps = {
  children: ReactNode;
  onClick?: () => void;
  type?: "button" | "submit";
  variant?: "primary" | "secondary" | "ghost" | "danger" | "success";
  size?: "sm" | "md";
  disabled?: boolean;
  className?: string;
  title?: string;
};

export function Button({
  children,
  onClick,
  type = "button",
  variant = "primary",
  size = "md",
  disabled,
  className,
  title,
}: ButtonProps) {
  const variants: Record<string, string> = {
    primary:
      "bg-gradient-to-r from-navy-800 to-teal-600 text-white shadow-sm hover:brightness-110 active:brightness-95",
    secondary:
      "border border-line bg-surface text-ink hover:border-line-strong hover:bg-surface-muted dark:hover:bg-elevated",
    ghost: "text-ink-soft hover:bg-surface-muted hover:text-ink",
    danger: "bg-red-600 text-white hover:bg-red-500",
    success: "bg-emerald-600 text-white hover:bg-emerald-500",
  };
  return (
    <button
      type={type}
      title={title}
      onClick={onClick}
      disabled={disabled}
      className={clsx(
        "inline-flex items-center justify-center gap-2 rounded-xl font-medium transition disabled:cursor-not-allowed disabled:opacity-50",
        size === "sm" ? "px-3 py-1.5 text-xs" : "px-4 py-2 text-sm",
        variants[variant],
        className,
      )}
    >
      {children}
    </button>
  );
}

export function Code({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <code
      className={clsx(
        "rounded-md bg-surface-muted px-1.5 py-0.5 font-mono text-[11px] text-ink-soft dark:bg-elevated",
        className,
      )}
    >
      {children}
    </code>
  );
}

export function Field({
  label,
  hint,
  children,
  required,
}: {
  label: string;
  hint?: string;
  children: ReactNode;
  required?: boolean;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-semibold tracking-wide text-ink-soft uppercase">
        {label}
        {required ? <span className="text-teal-600"> *</span> : null}
      </span>
      {children}
      {hint ? <span className="mt-1 block text-[11px] text-ink-faint">{hint}</span> : null}
    </label>
  );
}

export const inputClass =
  "w-full rounded-xl border border-line bg-surface px-3 py-2 text-sm text-ink outline-none transition placeholder:text-ink-faint focus:border-teal-400 dark:bg-elevated";
