import { Link, useLocation } from "react-router-dom";
import { clsx } from "clsx";
import {
  Activity,
  BarChart3,
  Bot,
  Boxes,
  ChevronLeft,
  LayoutDashboard,
  ScrollText,
  Settings2,
  ShieldCheck,
  Sparkles,
  Wrench,
  type LucideIcon,
} from "lucide-react";
import { useAuth } from "../state/AuthContext";

export interface NavItem {
  to: string;
  label: string;
  icon: LucideIcon;
  permission?: string;
  badgeKey?: "approvals" | "running";
  exact?: boolean;
  description: string;
}

export const NAV_ITEMS: NavItem[] = [
  { to: "/", label: "Overview", icon: LayoutDashboard, permission: "workflows.view", description: "Platform pulse" },
  {
    to: "/workflows/new",
    label: "Create Workflow",
    icon: Sparkles,
    permission: "workflows.create",
    exact: true,
    description: "Natural-language request",
  },
  { to: "/agents", label: "Agent Command Center", icon: Bot, permission: "agents.view", description: "Nine specialised agents" },
  { to: "/workflows", label: "Workflow Monitor", icon: Activity, permission: "workflows.view", description: "Live 12-stage pipeline" },
  { to: "/approvals", label: "Human Approvals", icon: ShieldCheck, permission: "approvals.view", badgeKey: "approvals", description: "Sensitive-action checkpoints" },
  { to: "/integrations", label: "Enterprise Applications", icon: Boxes, permission: "integrations.view", description: "Connected systems" },
  { to: "/tools", label: "Tool Registry", icon: Wrench, permission: "tools.view", description: "Authorised operations" },
  { to: "/audit", label: "Audit Logs", icon: ScrollText, permission: "audit.view", description: "Append-only trail" },
  { to: "/reports", label: "Reports & Analytics", icon: BarChart3, permission: "reports.view", description: "Outcomes and trends" },
  { to: "/settings", label: "Settings", icon: Settings2, permission: "agents.view", description: "Providers, policy, roles" },
];

export function Sidebar({
  collapsed,
  onToggleCollapse,
  pendingApprovals,
  onCloseMobile,
}: {
  collapsed: boolean;
  onToggleCollapse: () => void;
  pendingApprovals: number;
  onCloseMobile?: () => void;
}) {
  const { user, can } = useAuth();
  const location = useLocation();

  return (
    <aside
      className={clsx(
        "flex h-full flex-col border-r border-line bg-surface transition-[width] duration-200",
        collapsed ? "w-[72px]" : "w-[264px]",
      )}
    >
      <div className={clsx("flex items-center gap-2.5 px-4 py-4", collapsed && "justify-center px-0")}>
        <span className="gradient-brand grid size-9 shrink-0 place-items-center rounded-xl text-white shadow-sm">
          <Bot className="size-5" />
        </span>
        {!collapsed && (
          <div className="min-w-0 flex-1">
            <p className="truncate text-[15px] leading-tight font-bold tracking-tight text-ink">NEXUS AI</p>
            <p className="truncate text-[11px] text-ink-faint">Autonomous Operations</p>
          </div>
        )}
        {onCloseMobile && (
          <button
            type="button"
            onClick={onCloseMobile}
            className="rounded-lg p-1.5 text-ink-faint hover:bg-surface-muted lg:hidden"
            aria-label="Close navigation"
          >
            <ChevronLeft className="size-4" />
          </button>
        )}
      </div>

      <nav className="flex-1 space-y-0.5 overflow-y-auto px-2.5 pb-4">
        {NAV_ITEMS.filter((item) => !item.permission || can(item.permission) || user?.role.name === "admin").map(
          (item) => {
            const Icon = item.icon;
            const path = location.pathname;
            // A prefix item (Workflow Monitor) must not light up when a dedicated
            // exact route owns the whole path (Create Workflow).
            const claimedByExactRoute = NAV_ITEMS.some((other) => other.exact && other.to === path);
            const active =
              item.to === "/"
                ? path === "/"
                : item.exact
                  ? path === item.to
                  : !claimedByExactRoute && (path === item.to || path.startsWith(`${item.to}/`));
            return (
              <Link
                key={item.to}
                to={item.to}
                onClick={onCloseMobile}
                aria-current={active ? "page" : undefined}
                title={collapsed ? item.label : undefined}
                className={clsx(
                  "group relative flex items-center gap-3 rounded-xl px-3 py-2 text-[13px] font-medium transition",
                  collapsed && "justify-center px-0",
                  active
                    ? "bg-navy-900 text-white shadow-sm dark:bg-navy-100 dark:text-navy-900"
                    : "text-ink-soft hover:bg-surface-muted hover:text-ink",
                )}
              >
                <Icon className={clsx("size-4 shrink-0", active ? "text-teal-300 dark:text-teal-600" : "opacity-80")} />
                {!collapsed && <span className="flex-1 truncate">{item.label}</span>}
                {item.badgeKey === "approvals" && pendingApprovals > 0 && !collapsed ? (
                  <span className="rounded-full bg-amber-500 px-1.5 py-0.5 text-[10px] font-bold text-white">
                    {pendingApprovals}
                  </span>
                ) : null}
                {item.badgeKey === "approvals" && pendingApprovals > 0 && collapsed ? (
                  <span className="absolute top-1 right-1 size-2 rounded-full bg-amber-500" />
                ) : null}
              </Link>
            );
          },
        )}
      </nav>

      {!collapsed && (
        <div className="mx-3 mb-3 rounded-xl border border-teal-200 bg-teal-50 px-3 py-2.5 text-[11px] leading-snug text-teal-900 dark:border-teal-400/30 dark:bg-teal-500/10 dark:text-teal-200">
          <p className="font-semibold">Sandbox mode</p>
          <p className="mt-0.5 opacity-90">
            All enterprise actions run against simulated adapters. Nothing is written to a live HR, finance or CRM
            system.
          </p>
        </div>
      )}

      <button
        type="button"
        onClick={onToggleCollapse}
        className="hidden items-center gap-2 border-t border-line px-4 py-3 text-xs text-ink-faint transition hover:text-ink lg:flex"
      >
        <ChevronLeft className={clsx("size-4 transition-transform", collapsed && "rotate-180")} />
        {!collapsed && <span>Collapse</span>}
      </button>
    </aside>
  );
}
