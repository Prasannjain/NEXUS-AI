import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { clsx } from "clsx";
import { Bell, CheckCheck, ChevronDown, LogOut, Menu, Moon, Sun } from "lucide-react";
import { api } from "../api/client";
import type { HealthPayload, NotificationsPage } from "../api/types";
import { useAsync } from "../lib/hooks";
import { relativeTime } from "../lib/format";
import { useAuth } from "../state/AuthContext";
import { useTheme } from "../state/ThemeContext";

export function Topbar({ title, subtitle, onOpenMobile }: { title: string; subtitle: string; onOpenMobile: () => void }) {
  const { user, signOut } = useAuth();
  const { theme, toggle } = useTheme();
  const [bellOpen, setBellOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const wrapper = useRef<HTMLDivElement>(null);

  const notifications = useAsync<NotificationsPage>(() => api.notifications(), []);
  const health = useAsync<HealthPayload>(() => api.health(), []);

  useEffect(() => {
    const close = (event: MouseEvent) => {
      if (!wrapper.current?.contains(event.target as Node)) {
        setBellOpen(false);
        setMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, []);

  const unread = notifications.data?.unread ?? 0;

  return (
    <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-line bg-surface/85 px-4 py-3 backdrop-blur-md">
      <button
        type="button"
        onClick={onOpenMobile}
        className="rounded-lg p-2 text-ink-soft hover:bg-surface-muted lg:hidden"
        aria-label="Open navigation"
      >
        <Menu className="size-5" />
      </button>

      <div className="min-w-0 flex-1">
        <h1 className="truncate text-[15px] leading-tight font-semibold text-ink">{title}</h1>
        <p className="truncate text-xs text-ink-faint">{subtitle}</p>
      </div>

      <div className="hidden items-center gap-2 md:flex">
        <span
          className={clsx(
            "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-medium",
            health.data?.status === "ok"
              ? "border-emerald-200 bg-emerald-50 text-emerald-800 dark:border-emerald-400/30 dark:bg-emerald-500/10 dark:text-emerald-200"
              : "border-red-200 bg-red-50 text-red-800 dark:border-red-400/30 dark:bg-red-500/10 dark:text-red-200",
          )}
          title={health.error ? "API unreachable" : `LangGraph engine · ${health.data?.active_workflow_runs ?? 0} live run(s)`}
        >
          <span className={clsx("size-1.5 rounded-full", health.data?.status === "ok" ? "bg-emerald-500" : "bg-red-500")} />
          {health.data ? `API ${health.data.status}` : "connecting…"}
        </span>
        <span
          className="rounded-full border border-line bg-surface-muted px-2.5 py-1 text-[11px] font-medium text-ink-soft dark:bg-elevated"
          title="Provider used by the Planner Agent; without an API key the deterministic rule planner is used"
        >
          planner: {health.data ? (health.data.llm_provider === "none" ? "rule engine" : health.data.llm_provider) : "…"}
        </span>
      </div>

      <div className="relative flex items-center gap-1" ref={wrapper}>
        <button
          type="button"
          onClick={toggle}
          className="rounded-lg p-2 text-ink-soft transition hover:bg-surface-muted hover:text-ink"
          aria-label={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
        >
          {theme === "dark" ? <Sun className="size-4" /> : <Moon className="size-4" />}
        </button>

        <button
          type="button"
          onClick={() => {
            setBellOpen((open) => !open);
            setMenuOpen(false);
          }}
          className="relative rounded-lg p-2 text-ink-soft transition hover:bg-surface-muted hover:text-ink"
          aria-label="Notifications"
        >
          <Bell className="size-4" />
          {unread > 0 ? (
            <span className="absolute top-1 right-1 grid min-w-4 place-items-center rounded-full bg-amber-500 px-1 text-[10px] font-bold text-white">
              {unread}
            </span>
          ) : null}
        </button>

        {bellOpen ? (
          <div className="card-surface absolute top-11 right-2 z-40 w-[340px] animate-rise bg-surface p-2">
            <div className="flex items-center justify-between px-2 py-1">
              <p className="text-xs font-semibold text-ink">Notifications</p>
              {unread > 0 ? (
                <button
                  type="button"
                  className="inline-flex items-center gap-1 text-[11px] text-teal-600 hover:underline"
                  onClick={() =>
                    api.markAllNotificationsRead().then(() => {
                      void notifications.reload();
                    })
                  }
                >
                  <CheckCheck className="size-3" /> Mark all read
                </button>
              ) : null}
            </div>
            <div className="max-h-80 overflow-y-auto">
              {(notifications.data?.items ?? []).length === 0 ? (
                <p className="px-2 py-6 text-center text-xs text-ink-faint">Nothing yet — start a workflow.</p>
              ) : (
                (notifications.data?.items ?? []).map((item) => (
                  <div
                    key={item.id}
                    className={clsx(
                      "rounded-lg px-2 py-2 text-xs transition hover:bg-surface-muted",
                      !item.read && "bg-teal-50/70 dark:bg-teal-500/10",
                    )}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <p className="font-semibold text-ink">{item.title}</p>
                      <span className="shrink-0 text-[10px] text-ink-faint">{relativeTime(item.created_at)}</span>
                    </div>
                    <p className="mt-0.5 text-ink-soft">{item.message}</p>
                    {item.workflow_id ? (
                      <Link
                        to={`/workflows/${item.workflow_id}`}
                        className="mt-1 inline-block text-[11px] font-medium text-teal-600 hover:underline"
                        onClick={() => setBellOpen(false)}
                      >
                        Open {item.workflow_id}
                      </Link>
                    ) : null}
                  </div>
                ))
              )}
            </div>
          </div>
        ) : null}

        <button
          type="button"
          onClick={() => {
            setMenuOpen((open) => !open);
            setBellOpen(false);
          }}
          className="ml-1 flex items-center gap-2 rounded-xl border border-line px-2 py-1.5 text-left transition hover:bg-surface-muted"
        >
          <span className="grid size-7 place-items-center rounded-lg bg-navy-900 text-[11px] font-bold text-white dark:bg-navy-100 dark:text-navy-900">
            {(user?.full_name ?? "?")
              .split(" ")
              .map((part) => part[0])
              .slice(0, 2)
              .join("")}
          </span>
          <span className="hidden sm:block">
            <span className="block text-xs leading-tight font-semibold text-ink">{user?.full_name}</span>
            <span className="block text-[10px] text-ink-faint capitalize">{user?.role.name}</span>
          </span>
          <ChevronDown className="size-3.5 text-ink-faint" />
        </button>

        {menuOpen ? (
          <div className="card-surface absolute top-11 right-0 z-40 w-56 animate-rise bg-surface p-1.5">
            <div className="px-2.5 py-2">
              <p className="text-xs font-semibold text-ink">{user?.full_name}</p>
              <p className="truncate text-[11px] text-ink-faint">{user?.email}</p>
              <p className="mt-1 text-[11px] text-ink-soft">{user?.role.description}</p>
            </div>
            <button
              type="button"
              onClick={signOut}
              className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-xs font-medium text-red-700 hover:bg-red-50 dark:hover:bg-red-500/10"
            >
              <LogOut className="size-3.5" /> Sign out
            </button>
          </div>
        ) : null}
      </div>
    </header>
  );
}
