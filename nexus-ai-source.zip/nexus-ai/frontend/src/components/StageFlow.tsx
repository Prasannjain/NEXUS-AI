import { memo, useMemo } from "react";
import { Background, BackgroundVariant, Handle, MarkerType, Position, ReactFlow, type Edge, type Node, type NodeProps } from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import type { StageEntry } from "../api/types";
import { STAGE_DOT_CLASS } from "../lib/format";

const STATUS_HEX: Record<string, string> = {
  completed: "#10b981",
  running: "#3b82f6",
  waiting: "#f59e0b",
  failed: "#ef4444",
  pending: "#94a3b8",
  skipped: "#94a3b8",
};

type StageNodeData = {
  index: number;
  label: string;
  description: string;
  detail: string;
  status: string;
  is_current: boolean;
  onSelect: (key: string) => void;
};

const StageNode = memo(function StageNode({ data }: NodeProps) {
  const node = data as unknown as StageNodeData;
  const color = STATUS_HEX[node.status] ?? STATUS_HEX.pending;
  return (
    <div
      onClick={() => node.onSelect(`stage-${node.index}`)}
      className={`w-[190px] cursor-pointer rounded-xl border bg-surface px-3 py-2.5 text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-md ${
        node.is_current ? "border-teal-400 ring-2 ring-teal-400/40" : "border-line"
      }`}
      style={{ borderLeft: `3px solid ${color}` }}
    >
      <Handle type="target" position={Position.Left} className="!size-1.5 !border-0 !bg-line-strong" />
      <Handle type="source" position={Position.Right} className="!size-1.5 !border-0 !bg-line-strong" />
      <div className="flex items-center gap-2">
        <span className="grid size-5 place-items-center rounded-md bg-surface-muted font-mono text-[10px] font-bold text-ink-soft dark:bg-elevated">
          {node.index + 1}
        </span>
        <span className={`size-2 rounded-full ${STAGE_DOT_CLASS[node.status as keyof typeof STAGE_DOT_CLASS] ?? "bg-slate-300"} ${node.status === "running" ? "animate-pulse" : ""}`} />
        <p className="min-w-0 flex-1 truncate text-[11.5px] leading-tight font-semibold text-ink">{node.label}</p>
      </div>
      <p className="mt-1.5 line-clamp-2 text-[10.5px] leading-snug text-ink-faint">{node.detail || node.description}</p>
    </div>
  );
});

const COLUMN = 232;
const ROW = 118;

export function StageFlow({
  timeline,
  onSelect,
}: {
  timeline: StageEntry[];
  onSelect: (key: string) => void;
}) {
  const perRow = 6;

  const nodes: Node[] = useMemo(
    () =>
      timeline.map((stage, index) => {
        const row = Math.floor(index / perRow);
        const columnInRow = index % perRow;
        // Serpentine: the second row reads right-to-left so the flow stays connected.
        const column = row % 2 === 0 ? columnInRow : perRow - 1 - columnInRow;
        return {
          id: `stage-${index}`,
          type: "custom",
          position: { x: column * COLUMN, y: row * ROW * 1.9 },
          data: {
            index,
            label: stage.label,
            description: stage.description,
            detail: stage.detail,
            status: stage.status,
            is_current: stage.is_current,
            onSelect,
          } satisfies StageNodeData & Record<string, unknown>,
        };
      }),
    [timeline, onSelect],
  );

  const edges: Edge[] = useMemo(
    () =>
      Array.from({ length: Math.max(0, timeline.length - 1) }, (_, offset) => {
        const index = offset + 1;
        const previous = timeline[index - 1];
        const tone =
          previous.status === "completed" ? "#10b981" : previous.status === "failed" ? "#ef4444" : "#cbd6e4";
        return {
          id: `edge-${index}`,
          source: `stage-${index - 1}`,
          target: `stage-${index}`,
          animated: previous.status === "running",
          style: { stroke: tone, strokeWidth: 1.6 },
          markerEnd: { type: MarkerType.ArrowClosed, color: tone, width: 14, height: 14 },
        };
      }),
    [timeline],
  );

  return (
    <div className="h-[330px] w-full">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        nodeTypes={{ custom: StageNode }}
        fitView
        proOptions={{ hideAttribution: true }}
        nodesConnectable={false}
        elementsSelectable={false}
        minZoom={0.45}
        maxZoom={1.4}
      >
        <Background variant={BackgroundVariant.Dots} gap={18} size={1} color="var(--color-line-strong)" />
      </ReactFlow>
    </div>
  );
}
