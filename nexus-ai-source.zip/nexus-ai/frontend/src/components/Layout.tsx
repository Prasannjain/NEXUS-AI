import { useEffect, useState } from "react";
import { Outlet, useLocation } from "react-router-dom";
import { clsx } from "clsx";
import { api } from "../api/client";
import { NAV_ITEMS, Sidebar } from "./Sidebar";
import { Topbar } from "./Topbar";
import { usePoll } from "../lib/hooks";

const COLLAPSE_KEY = "nexus.sidebar.collapsed";

function titleFor(pathname: string): { title: string; subtitle: string } {
  if (pathname.startsWith("/workflows/new")) {
    const create = NAV_ITEMS.find((item) => item.to === "/workflows/new");
    return { title: "Create Workflow", subtitle: create?.description ?? "" };
  }
  if (pathname.startsWith("/workflows/")) {
    return { title: "Workflow Monitor", subtitle: "Live execution detail for one workflow" };
  }
  const match = NAV_ITEMS.filter((item) => item.to !== "/" && pathname.startsWith(item.to)).sort(
    (a, b) => b.to.length - a.to.length,
  )[0];
  if (match) return { title: match.label, subtitle: match.description };
  const home = NAV_ITEMS[0];
  return { title: "Overview Dashboard", subtitle: home.description };
}

export function Layout() {
  const location = useLocation();
  const [collapsed, setCollapsed] = useState(() => localStorage.getItem(COLLAPSE_KEY) === "1");
  const [mobileOpen, setMobileOpen] = useState(false);
  const pending = usePoll(() => api.approvals("pending"), 12000, []);

  useEffect(() => {
    localStorage.setItem(COLLAPSE_KEY, collapsed ? "1" : "0");
  }, [collapsed]);

  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname]);

  const { title, subtitle } = titleFor(location.pathname);

  return (
    <div className="flex h-screen overflow-hidden bg-canvas">
      <div className="hidden lg:block">
        <Sidebar
          collapsed={collapsed}
          onToggleCollapse={() => setCollapsed((value) => !value)}
          pendingApprovals={pending.data?.pending ?? 0}
        />
      </div>

      {mobileOpen ? (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-navy-900/50 backdrop-blur-sm" onClick={() => setMobileOpen(false)} />
          <div className="absolute inset-y-0 left-0 w-[264px] animate-fade shadow-2xl">
            <Sidebar
              collapsed={false}
              onToggleCollapse={() => setMobileOpen(false)}
              pendingApprovals={pending.data?.pending ?? 0}
              onCloseMobile={() => setMobileOpen(false)}
            />
          </div>
        </div>
      ) : null}

      <div className="flex min-w-0 flex-1 flex-col">
        <Topbar title={title} subtitle={subtitle} onOpenMobile={() => setMobileOpen(true)} />
        <main className={clsx("flex-1 overflow-y-auto")}>
          <div className="mx-auto w-full max-w-[1600px] px-4 py-5 sm:px-6">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}
