import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { api, auth } from "../api/client";
import type { User } from "../api/types";

interface AuthValue {
  user: User | null;
  ready: boolean;
  signIn: (email: string, password: string) => Promise<User>;
  signOut: () => void;
  can: (permission: string) => boolean;
}

const AuthContext = createContext<AuthValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => auth.user());
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (!auth.token()) {
      setReady(true);
      return;
    }
    api
      .me()
      .then((fresh) => {
        auth.setUser(fresh);
        setUser(fresh);
      })
      .catch(() => {
        auth.clear();
        setUser(null);
      })
      .finally(() => setReady(true));
  }, []);

  const signIn = useCallback(async (email: string, password: string) => {
    const response = await api.login(email, password);
    auth.store(response.access_token, response.user);
    setUser(response.user);
    return response.user;
  }, []);

  const signOut = useCallback(() => {
    auth.clear();
    setUser(null);
  }, []);

  const can = useCallback(
    (permission: string) => {
      if (!user) return false;
      const permissions = user.role?.permissions ?? [];
      return permissions.includes("*") || permissions.includes(permission);
    },
    [user],
  );

  const value = useMemo(() => ({ user, ready, signIn, signOut, can }), [user, ready, signIn, signOut, can]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthValue {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used inside AuthProvider");
  return context;
}
